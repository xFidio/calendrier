import base64,os,re
d=os.path.dirname(os.path.abspath(__file__))
a=d+'/src/'
def b64(p): return base64.b64encode(open(p,'rb').read()).decode()
f=d+'/polices/'
fonts=("@font-face{font-family:'Lilita One';font-weight:400;font-display:swap;src:url(data:font/woff2;base64,%s) format('woff2')}"
"@font-face{font-family:'Nunito';font-weight:200 1000;font-display:swap;src:url(data:font/woff2;base64,%s) format('woff2')}"
)%(b64(f+'lilita-one-latin-400-normal.woff2'),b64(f+'nunito-latin-wght-normal.woff2'))
t=open(a+'template.html').read()
app=open(a+'app.js').read()
marker='(async function init(){'
assert app.count(marker)==1
app=app.replace(marker,open(a+'game.js').read()+'\n'+marker)
out=t.replace('/*STYLE*/',fonts+open(a+'style.css').read()).replace('/*DATA*/',open(a+'data.js').read()+'\n'+open(a+'gamedata.js').read()).replace('/*APP*/',app)
open(d+'/calendrier-avent-table-des-enfants.html','w').write(out)
ts=d+'/test-site/'
os.makedirs(ts,exist_ok=True)
# version de test : pas d'envoi au formulaire, statistiques lues dans stats.csv
test=re.sub(r'pins:\{[^}]*\}','pins:{}',re.sub(r"formUrl:'[^']*'","formUrl:''",re.sub(r"statsCsvUrl:'[^']*'","statsCsvUrl:'stats.csv'",out)))
open(ts+'index.html','w').write(test)
print('ok',len(out),'octets')
