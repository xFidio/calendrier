# Outils du calendrier

- `python3 build.py` : assemble les fichiers de `src/` en un seul HTML (`calendrier-avent-table-des-enfants.html`, à publier) et une version de test (`test-site/index.html`).
- `node src/check.js` (depuis `src/`) : vérifie la cohérence des données (aperçus, tenues, musiques, quiz, liens, questions en double).
- `node src/test.js ../test-site/index.html` (depuis `src/`) : test complet dans un navigateur (nécessite Node et Playwright : `npm i playwright`).
- Pour changer une case : modifier `src/data.js`, puis le quiz (`GAMES`), l'aperçu de la veille (`TEASERS`), la phrase du bonhomme (`SNOW_DAILY`) et la tenue (`OUTFITS`) dans `src/gamedata.js`, la musique dans `TRACK_BY_DAY` (`src/app.js`). `check.js` signale ce qui manque.
- Mode test : ajouter `?scribe=2026-12-12` à l'adresse. `?effacer=1` remet le test à zéro.
