// Vérifie la cohérence des données du calendrier. Usage : node check.js
const fs=require('fs');
const load=(f,ret)=>new Function(fs.readFileSync(f,'utf8')+';return '+ret)();
const D=load('data.js','{DAYS,TYPES}');
const G=load('gamedata.js','{GAMES,TEASERS,OUTFITS,SNOW_DAILY,BONUS,SPECIAL_DAYS,FIRST_DAYS}');
const app=fs.readFileSync('app.js','utf8');
const tpl=fs.readFileSync('template.html','utf8');
const errs=[],warn=[];
const e=(m)=>errs.push(m),w=(m)=>warn.push(m);
const byDay={};
D.DAYS.forEach(d=>byDay[d.d]=d);
for(let n=1;n<=25;n++){
  const d=byDay[n];if(!d){e('case '+n+' absente');continue;}
  if(!d.title)e('case '+n+' : titre vide');
  if(!D.TYPES[d.type])e('case '+n+' : type inconnu '+d.type);
  if(!d.body||d.body.length<80)e('case '+n+' : texte trop court');
  if(n<25&&!(d.qs&&d.qs.length))e('case '+n+' : pas de question du jour');
  (d.qs||[]).forEach(q=>{if(!q.id||!q.text)e('case '+n+' : question incomplète');if(q.kind==='choice'&&!(q.options&&q.options.length>=2))e('case '+n+' : options manquantes');});
  (d.links||[]).forEach(([l,u])=>{if(!/^https:\/\//.test(u))e('case '+n+' : lien non https '+u);if(!l)e('case '+n+' : lien sans titre');});
  if(n<25&&!G.TEASERS[n-1])e('case '+n+' : pas d\'aperçu de la veille (TEASERS['+(n-1)+'])');
  if(n<=25&&!G.SNOW_DAILY[n-1])e('case '+n+' : pas de phrase du bonhomme (SNOW_DAILY)');
  if(n<25&&!G.OUTFITS[n])e('case '+n+' : pas de tenue (OUTFITS)');
  if(/Die Hard|trois boules/.test(d.body))e('case '+n+' : référence retirée');
}
// aperçus : l'aperçu du jour d décrit la case d+1, vérification manuelle des mots-clés
const ids=D.DAYS.flatMap(d=>(d.qs||[]).map(q=>q.id));
const dup=ids.filter((x,i)=>ids.indexOf(x)!==i);if(dup.length)e('ids de questions en double : '+dup);
// tenues
const cos=Object.values(G.OUTFITS).map(o=>o.c);
const dupc=cos.filter((x,i)=>cos.indexOf(x)!==i);if(dupc.length)e('même tenue sur deux jours : '+dupc);
cos.forEach(c=>{if(!tpl.includes('class="cos '+c+'"'))e('tenue '+c+' absente du dessin (template.html)');});
// musique
const tbd=(app.match(/const TRACK_BY_DAY=\{([^}]*)\}/)||[])[1]||'';
for(let n=1;n<=25;n++){const m=tbd.match(new RegExp('(?:^|,)'+n+":'([a-z0-9]+)'"));if(!m)e('case '+n+' : pas de musique (TRACK_BY_DAY)');else if(!new RegExp('\\b'+m[1]+':\\{').test(app))e('case '+n+' : piste inconnue '+m[1]);}
// quiz
G.FIRST_DAYS.forEach(n=>{const q=G.GAMES[n];if(!q)e('case '+n+' : FIRST_DAYS sans quiz');else{if(q.a<0||q.a>=q.o.length)e('case '+n+' : bonne réponse hors liste');if(q.o.length<3)w('case '+n+' : moins de 3 choix');}});
Object.keys(G.GAMES).forEach(n=>{if(!G.FIRST_DAYS.includes(+n))w('quiz inutilisé pour la case '+n);});
G.SPECIAL_DAYS.forEach(n=>{if(G.FIRST_DAYS.includes(n))e('case '+n+' : spéciale et quiz en même temps');});
// répartition
const rep={};D.DAYS.forEach(d=>(rep[d.type]=rep[d.type]||[]).push(d.d));
console.log('Répartition :',Object.entries(rep).map(([k,v])=>k+' '+v.length).join(' · '));
console.log('Avertissements :',warn.length?'\n - '+warn.join('\n - '):'aucun');
console.log('Erreurs :',errs.length?'\n - '+errs.join('\n - '):'aucune');
process.exit(errs.length?1:0);
