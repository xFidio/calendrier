/* ============================================================
   CONFIGURATION : à remplir une fois le Google Form créé
   ============================================================ */
const CONFIG={
  // Adresse d'envoi du formulaire, du type :
  // https://docs.google.com/forms/d/e/XXXXXXXX/formResponse
  formUrl:'https://docs.google.com/forms/d/e/1FAIpQLSdhLcualzZbDof-z6fJOZwQxoturOYGILt70xhtVqz0TKuWRg/formResponse',
  // Identifiants des 3 champs du formulaire, du type 'entry.123456789'
  entry:{name:'entry.707447846',day:'entry.1870655844',answer:'entry.828175629'},
  // Adresse CSV du tableur de réponses (Fichier > Partager > Publier sur le web > CSV)
  statsCsvUrl:'https://docs.google.com/spreadsheets/d/e/2PACX-1vQHfbWnTuAR5kjcizMdjLWei_0ZuO2MfrBJgr_855LDPcSPaM4VuoFglKEi6g0fn1GeuhqKqrzZXUDr/pub?gid=1596634407&single=true&output=csv',
  // Position des colonnes dans le CSV (0 = horodatage)
  csvCols:{name:1,day:2,answer:3},
  // Nom du paramètre secret du mode test : ?scribe=2026-12-12
  testParam:'scribe',
  // Codes personnels (4 chiffres) : empreintes, pas les codes eux-mêmes. Vide = pas de code demandé.
  pins:{"Marine": "15172907c9d389", "Florian S": "133e3e2397a9dd", "Florian R": "17f294e513dc3e", "Orane": "15806ac77fb3f4", "Claire": "14946347a91891", "Jules": "1f58e30f893660", "Mathilde": "8b7997df0d054", "Kevin": "1ab14d6109915c"}
};

const YEAR=2026, MONTH=12;
const TZ='Europe/Paris';
const MONTHS_FR='décembre';

const TAUNTS=[
 `Pas touche. Cette case n'est pas encore prête (elle choisit son pull).`,
 `Patience. Les cases, c'est comme la raclette : ça ne se brusque pas.`,
 `Pas avant le jour J. Même en suppliant.`,
 `Cette case dort encore. Ne la réveille pas, elle est de mauvaise humeur le matin.`,
 `Non. (C'est gentil, c'est juste non.)`,
 `Tu as essayé, c'est beau. La case, elle, n'a pas bougé.`,
 `La case te regarde. Elle ne s'ouvrira pas.`,
 `Un peu de tenue. On n'ouvre pas les cadeaux avant l'heure.`,
 `Le volet est coincé. Par la loi. Et par moi.`,
 `Ici, derrière, il y a quelque chose. Tu ne sauras pas quoi. C'est le principe.`,
 `Si tu cliques plus fort, ça ne marchera pas mieux. Mais bravo pour l'énergie.`,
 `Cette case est en réunion. Pas de créneau avant son jour.`,
 `Mathilde a prévu ce clic. Mathilde a tout prévu.`,
 `Un dragon dort derrière ce volet. Tu veux vraiment le déranger ?`,
 `Ton enthousiasme est noté. Il ne change rien.`,
 `Fermé pour cause de suspense.`,
 `Tu sens l'odeur de la cannelle ? Non ? Normal, c'est fermé.`,
 `Les volets sont verrouillés par un sort de niveau 3. Il faut un jet de patience.`,
 `Cette case suit les horaires du Coffee Loud : elle n'ouvre pas avant son heure.`,
 `Tu as 0 point de charisme contre une case. Retente plus tard.`,
 `Ce volet te regarde comme on regarde quelqu'un qui double dans la queue.`,
 `Les cases s'ouvrent à minuit pile, heure de Paris. Pas à l'heure de ton impatience.`,
 `Désolé, cette case est réservée à un autre jour. Elle a une réservation.`,
 `Pas encore. La case sera là, elle ne va nulle part (elle n'a pas de jambes).`,
 `Tu ressembles au genre de personne qui ouvre les cadeaux la veille. Je ne juge pas. Si, un peu.`,
 `Une case, c'est comme un fromage : il faut savoir attendre le bon jour.`,
 `Verrouillé. Le code est secret, et même Mathilde ne te le donnera pas.`,
 `Réponse automatique : cette case est absente jusqu'à son jour. Elle répondra à son retour.`,
 `Ce clic a été transmis au service des clics perdus.`,
 `Ce clic est enregistré dans ton dossier. Il ne servira à rien, mais il est enregistré.`,
 `Mathilde a verrouillé cette case elle-même. Elle en est assez fière.`,
 `Acédia a regardé cette case et a dit « on verra le jour J ». Elle a raison, pour une fois.`
];
const TAUNTS_MANY=[
 `Troisième essai. Une case, ça ne s'use pas à force d'être regardée.`,
 `Tu insistes. La case aussi.`,
 `À force de cliquer, ton doigt va fatiguer avant la case.`,
 `Bon. Respire. On en parle le jour J.`,
 `Cliquer plus souvent ne l'ouvre pas plus tôt. C'est la physique des cases.`,
 `Tu fais ça toute la journée ? La case est impressionnée, mais toujours fermée.`
];
const TAUNTS_NEAR=[
 `Demain ! Oui, demain. Dors, et reviens.`,
 `Presque. Tu peux déjà préparer ton chocolat chaud.`,
 `Demain, promis. La case te garde une place.`
];
const TAUNTS_FAR=[
 `Tu es encore loin de cette case. Je te conseille un hobby entre-temps.`,
 `Cette case est à plusieurs jours. Tu as le temps de ranger ta chambre.`,
 `Cette case n'est pas pour tout de suite. Occupe-toi avec les précédentes.`
];
const TAUNTS_PRE=[
 `Décembre n'a pas commencé. Le calendrier, lui, a déjà tout prévu.`,
 `On est encore en novembre. Marine a décoré son sapin, pas toi, ne force pas.`,
 `Avant le 1er, rien ne s'ouvre. Même pas avec du charme.`
];
const CHEAT=[
 `Tu as changé l'heure de ton appareil ? Même Acédia n'oserait pas.`,
 `Voyage dans le temps détecté. Le Père Noël a été prévenu. Il note.`,
 `Ton horloge dit une chose, l'univers en dit une autre. L'univers gagne.`,
 `Tricher à un calendrier de l'Avent : le crime parfait… qui ne marche jamais.`,
 `Bien essayé. Retour au présent. Une case par jour, comme tout le monde.`,
 `Voyager dans le temps n'est pas au programme. Une case par jour, même pour toi.`,
 `Ton téléphone vit dans le futur. Ramène-le dans le présent, s'il te plaît.`,
 `Détecteur de tricheurs activé. Il fait aussi détecteur de fumée.`,
 `On dirait que tu voulais manger le chocolat avant l'heure. Les cases, elles, savent attendre.`,
 `Cette horloge a des projets pour toi, mais pas ceux-là.`,
 `Voyage dans le temps détecté. Retour immédiat à aujourd'hui, sans escale.`,
 `Tu pensais vraiment que l'horloge de ton téléphone suffirait ? Mignon.`,
 `Le calendrier a vérifié l'heure ailleurs. Il a un indic.`,
 `Changer la date de ton téléphone, c'est comme déplacer son pion en cachette. On a vu.`,
 `Les cases sont fermées. L'horloge de ton téléphone aussi, au passage.`,
 `Ce calendrier a une montre plus fiable que toi.`,
 `Tu as modifié la date. Mathilde l'a vu. Mathilde voit tout.`,
 `Mathilde a ajouté un détecteur de tricheurs. Elle ne te dira pas comment.`,
 `Hé ! Les cases n'aiment pas les voyageurs temporels.`,
 `Cette tentative sera mentionnée dans la finale. Sans nom. Enfin... peut-être.`
];

/* ---------- utilitaires ---------- */
const $=(s,r=document)=>r.querySelector(s);
const el=(tag,cls,html)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;return e;};
const txt=(tag,cls,t)=>{const e=document.createElement(tag);if(cls)e.className=cls;e.textContent=t;return e;};
// Mode test : ?scribe=AAAA-MM-JJ. Tout est isolé : autres clés de stockage, aucun envoi au formulaire.
const TEST_MODE=/^\d{4}-\d{2}-\d{2}$/.test(new URLSearchParams(location.search).get(CONFIG.testParam)||'');
const SK=k=>(TEST_MODE&&k!=='ate_music'?'test_':'')+k;
const store={
  get(k,d){try{const v=localStorage.getItem(SK(k));return v==null?d:JSON.parse(v);}catch(e){return d;}},
  set(k,v){try{localStorage.setItem(SK(k),JSON.stringify(v));}catch(e){}}
};
// Remise à zéro de TOUT ce que ce navigateur a enregistré : ajouter ?effacer=1 à l'adresse.
if(new URLSearchParams(location.search).get('effacer')==='1'){
  try{Object.keys(localStorage).filter(k=>k.startsWith('ate_')||k.startsWith('test_')).forEach(k=>localStorage.removeItem(k));}catch(e){}
  location.replace(location.pathname);
}
const pick=a=>a[Math.floor(Math.random()*a.length)];
function parisYMD(ms){return new Intl.DateTimeFormat('en-CA',{timeZone:TZ,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(ms));}

/* ---------- état ---------- */
let todayNum=0;      // 0 = avant décembre, 1..25 = jour courant, 26 = après le 25
let cheated=false;
let testMode=false;
let me=store.get('ate_me',null);
// sur un appareil où le code n'a pas encore été vérifié, on redemande le prénom (voir init)
let seen=store.get('ate_seen',{});
let myVotes=store.get('ate_votes',{});

function dayFromYMD(ymd){
  const [y,m,d]=ymd.split('-').map(Number);
  if(y<YEAR||(y===YEAR&&m<MONTH))return 0;
  if(y===YEAR&&m===MONTH)return d>25?26:d;
  return 26;
}

async function resolveToday(){
  const params=new URLSearchParams(location.search);
  const t=params.get(CONFIG.testParam);
  if(t&&/^\d{4}-\d{2}-\d{2}$/.test(t)){testMode=true;return dayFromYMD(t);}
  const dev=Date.now();
  let ms=dev;
  if(location.protocol==='http:'||location.protocol==='https:'){
    try{
      const r=await fetch(location.href.split('#')[0],{method:'HEAD',cache:'no-store'});
      const h=r.headers.get('Date');
      if(h){const s=Date.parse(h);if(!isNaN(s)&&Math.abs(s-dev)>6*3600*1000){cheated=true;ms=s;}}
    }catch(e){}
  }
  let ymd=parisYMD(ms);
  const last=store.get('ate_last',null);
  if(last&&ymd<last){cheated=true;ymd=last;}
  else store.set('ate_last',ymd);
  return dayFromYMD(ymd);
}

/* ---------- neige ---------- */
function snow(){
  const c=$('#snow');if(!c||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  const x=c.getContext('2d');let w,h,flakes=[];
  const resize=()=>{w=c.width=innerWidth;h=c.height=innerHeight;flakes=Array.from({length:Math.min(90,Math.floor(w/14))},()=>({x:Math.random()*w,y:Math.random()*h,r:Math.random()*2.4+.6,s:Math.random()*.8+.3,d:Math.random()*Math.PI*2}));};
  resize();addEventListener('resize',resize);
  (function frame(){
    if(!document.hidden){
      x.clearRect(0,0,w,h);x.fillStyle='rgba(255,255,255,.8)';
      flakes.forEach(f=>{f.y+=f.s;f.d+=.01;f.x+=Math.sin(f.d)*.4;if(f.y>h){f.y=-4;f.x=Math.random()*w;}x.beginPath();x.arc(f.x,f.y,f.r,0,6.283);x.fill();});
    }
    requestAnimationFrame(frame);
  })();
}

/* ---------- toast ---------- */
let toastT;
document.addEventListener('click',e=>{const t=document.getElementById('toast');if(t&&e.target===t){clearTimeout(toastT);t.className='';}});
function toast(msg,isCheat){
  const t=$('#toast');t.textContent=msg;t.className=(isCheat?'cheat ':'')+'show';
  clearTimeout(toastT);toastT=setTimeout(()=>{t.className='';},isCheat?9000:Math.max(7000,3000+msg.length*70));
}

/* ---------- grille ---------- */
const LOCK_SVG='<svg class="lock" viewBox="0 0 24 24" fill="#ffcf5c" stroke="#2b1b3d" stroke-width="2.2" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3" fill="none"/><circle cx="12" cy="16" r="1.4" fill="#2b1b3d" stroke="none"/></svg>';
const PIC_OPEN='<svg class="pic" viewBox="0 0 48 48" aria-hidden="true"><g stroke="#2b1b3d" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round">';
const PICS={
  histoire:PIC_OPEN+'<rect x="11" y="9" width="26" height="30" rx="3" fill="#f6e3b4"/><ellipse cx="24" cy="9" rx="15" ry="4.5" fill="#e8c77f"/><ellipse cx="24" cy="40" rx="15" ry="4.5" fill="#e8c77f"/><circle cx="19" cy="23" r="2" fill="#2b1b3d"/><circle cx="29" cy="23" r="2" fill="#2b1b3d"/><path d="M19 30q5 4 10 0" fill="none"/></g></svg>',
  apprends:PIC_OPEN+'<path d="M24 3v4M8 11l3 3M40 11l-3 3" fill="none"/><circle cx="24" cy="21" r="12" fill="#ffe66d"/><rect x="19" y="32" width="10" height="8" rx="2" fill="#b9c2d0"/><circle cx="19" cy="20" r="2" fill="#2b1b3d"/><circle cx="29" cy="20" r="2" fill="#2b1b3d"/><path d="M19 26q5 4 10 0" fill="none"/></g></svg>',
  test:PIC_OPEN+'<rect x="9" y="9" width="30" height="30" rx="7" fill="#fff" transform="rotate(-8 24 24)"/><g fill="#2b1b3d" stroke="none" transform="rotate(-8 24 24)"><circle cx="17" cy="17" r="2.6"/><circle cx="31" cy="17" r="2.6"/><circle cx="24" cy="24" r="2.6"/><circle cx="17" cy="31" r="2.6"/><circle cx="31" cy="31" r="2.6"/></g></g></svg>',
  site:PIC_OPEN+'<path d="M12 41V22a12 12 0 0 1 24 0v19l-4-3-4 3-4-3-4 3-4-3z" fill="#fff"/><circle cx="19" cy="22" r="2.2" fill="#2b1b3d"/><circle cx="29" cy="22" r="2.2" fill="#2b1b3d"/><ellipse cx="24" cy="30" rx="3" ry="3.4" fill="#2b1b3d"/></g></svg>',
  univers:PIC_OPEN+'<path d="M13 21L11 8l9 7zM35 21l2-13-9 7z" fill="#ffcf5c"/><ellipse cx="24" cy="28" rx="15" ry="13" fill="#5fc27a"/><ellipse cx="24" cy="33" rx="8" ry="5.5" fill="#a6e3a1"/><circle cx="18" cy="24" r="3" fill="#fff"/><circle cx="30" cy="24" r="3" fill="#fff"/><circle cx="18.6" cy="24.4" r="1.2" fill="#2b1b3d" stroke="none"/><circle cx="29.4" cy="24.4" r="1.2" fill="#2b1b3d" stroke="none"/><circle cx="21" cy="32" r="1" fill="#2b1b3d"/><circle cx="27" cy="32" r="1" fill="#2b1b3d"/></g></svg>',
  finale:PIC_OPEN+'<path d="M24 4l6 13 14 1.5-10.5 9.5 3 14L24 34.5 11.5 42l3-14L4 18.5 18 17z" fill="#ffcf5c"/><circle cx="19.5" cy="24" r="1.9" fill="#2b1b3d"/><circle cx="28.5" cy="24" r="1.9" fill="#2b1b3d"/><path d="M20 30q4 3.5 8 0" fill="none"/></g></svg>'
};
function renderGrid(){
  const g=$('#grid');g.innerHTML='';
  DAYS.forEach((x,i)=>{
    const open=x.d<=todayNum;
    const b=el('button','tile k'+(i%5)+' t-'+x.type+(open?'':' locked')+(x.d===todayNum&&todayNum<=24?' today':'')+(seen[x.d]?' seen':''));
    b.type='button';b.dataset.day=x.d;
    b.setAttribute('aria-label',`Case ${x.d}${open?'':' (verrouillée)'}`);
    b.innerHTML='<span class="glass">'+(open?PICS[x.type]:LOCK_SVG)+'</span>'+`<span class="num">${x.d}</span>`+(open?`<span class="mini">${TYPES[x.type].mini}</span>`:'')+(open&&SPECIAL_DAYS.includes(x.d)?'<span class="spflag" title="Case spéciale" aria-hidden="true">★</span>':'')+(seen[x.d]?'<span class="check" aria-hidden="true">✓</span>':'');
    b.addEventListener('click',ev=>onTile(x,b,ev));
    g.appendChild(b);
  });
  Game.markLock();
  // la case 25 s'impatiente à partir du 20
  const t25=g.querySelector('.tile[data-day="25"]');
  if(t25&&todayNum>=20&&todayNum<25){t25.classList.add('imp');t25.style.setProperty('--imp',String(todayNum-19));}
}
const tries={};
function tauntFor(x){
  tries[x.d]=(tries[x.d]||0)+1;
  const when=` Reviens le ${x.d===1?'1er':x.d} ${MONTHS_FR}.`;
  const dist=x.d-Math.max(todayNum,0);
  if(tries[x.d]>=3&&Math.random()<.75)return nextT(TAUNTS_MANY.concat(TAUNTS_COQUIN),'many');
  if(tries[x.d]===2&&Math.random()<.35)return nextT(TAUNTS_COQUIN,'coq');
  if(todayNum===0&&Math.random()<.4)return nextT(TAUNTS_PRE,'pre')+when;
  if(todayNum>0&&dist===1&&Math.random()<.6)return nextT(TAUNTS_NEAR,'near');
  if(dist>=8&&Math.random()<.3)return nextT(TAUNTS_FAR,'far')+when;
  return nextT(TAUNTS,'base')+when;
}
function onTile(x,b,ev){
  if(x.d>todayNum){
    if(Game.lockClick(x,ev))return;
    b.classList.remove('shake');void b.offsetWidth;b.classList.add('shake');
    if((tries[x.d]||0)>=2)kaoTile(b);
    if(cheated)toast(pick(CHEAT),true);
    else toast(tauntFor(x));
    return;
  }
  seen[x.d]=1;store.set('ate_seen',seen);
  Game.onOpen(x);
  b.classList.add('seen');
  openDay(x);
  renderGrid();
}
function renderStatus(){
  const s=$('#status');s.innerHTML='';
  let msg;
  if(todayNum===0)msg='L\'ouverture est le 1er décembre. Patience.';
  else if(todayNum>=25)msg=todayNum>=26?'Le calendrier est terminé. Merci d\'avoir joué.':'Toutes les cases sont ouvertes.';
  else msg=`Aujourd'hui : case ${todayNum}.`;
  s.appendChild(txt('span','',msg));
  if(todayNum<1){
    if(me){
      s.appendChild(txt('span','','·'));
      s.appendChild(txt('span','','Tu es '+me));
      const c=txt('button','','changer');c.type='button';c.addEventListener('click',()=>askWho(true));s.appendChild(c);
    }else{
      const c=txt('button','','Dis-nous qui tu es');c.type='button';c.addEventListener('click',()=>askWho(true));s.appendChild(c);
    }
  }
  renderYesterday();
}
function renderYesterday(){
  const y=$('#yday');if(!y)return;y.innerHTML='';
  const n=Math.min(todayNum-1,25);
  if(n<1){y.hidden=true;return;}
  y.hidden=false;
  y.appendChild(txt('span','','Résultat d\'hier :'));
  const b=txt('button','',`case ${n} · ${DAYS[n-1].title}`);b.type='button';
  b.addEventListener('click',()=>{seen[n]=1;store.set('ate_seen',seen);Game.onOpen(DAYS[n-1]);openDay(DAYS[n-1]);renderGrid();});
  y.appendChild(b);
  // verdict d'hier, annoncé une fois par jour
  const q=(DAYS[n-1].qs||[]).find(q=>q.kind==='who'||q.kind==='choice'||q.kind==='scale');
  if(!q||!CONFIG.statsCsvUrl)return;
  const tok=y._tok=(y._tok||0)+1;
  getAllRows().then(all=>{
    if(!all||tok!==y._tok)return;const{ok}=frozenVotes(all,q);if(!ok.length)return;
    let msg;
    if(q.kind==='scale'){const avg=ok.reduce((s,r)=>s+(parseFloat(r.answer)||0),0)/ok.length;msg=`Moyenne de la Table : ${avg.toFixed(1).replace('.',',')} / 10.`;}
    else{const{leads}=winners(ok);const award=q.award;
      if(q.kind==='who'&&leads.length===1&&award)Y_WIN={w:leads[0],a:award};
      if(q.kind==='who')msg=leads.length>1?`Égalité : ${leads.join(' et ')}${award?' se partagent « '+award+' »':''} !`:`${leads[0]}${award?' remporte « '+award+' »':' arrive en tête'} !`;
      else msg=leads.length>1?'Égalité parfaite : la Table n\'arrive pas à se décider.':`La Table a choisi : ${leads[0]}.`;}
    const v=txt('span','yverdict',msg);y.insertBefore(v,b);
    if(q.kind!=='scale')y.appendChild(reactBar(n,all));
    if(store.get('ate_yshown',0)!==todayNum){
      store.set('ate_yshown',todayNum);
      setTimeout(()=>{const r=y.getBoundingClientRect();if(r.width&&r.top<innerHeight){for(let i=0;i<3;i++)setTimeout(()=>sparkle(r.left+r.width*(.2+.3*i),r.top+r.height/2,14,['#ffcf5c','#e5484d','#3ddc84'][i]),i*180);}
        y.classList.add('pop');toast('Résultat d\'hier, case '+n+' : '+msg);},600);
    }
  });
}

/* ---------- identité ---------- */

function cyrb53(str,seed=0){let h1=0xdeadbeef^seed,h2=0x41c6ce57^seed;for(let i=0,ch;i<str.length;i++){ch=str.charCodeAt(i);h1=Math.imul(h1^ch,2654435761);h2=Math.imul(h2^ch,1597334677);}
  h1=Math.imul(h1^(h1>>>16),2246822507)^Math.imul(h2^(h2>>>13),3266489909);h2=Math.imul(h2^(h2>>>16),2246822507)^Math.imul(h1^(h1>>>13),3266489909);
  return ((h2>>>0)&0x1fffff).toString(16)+(h1>>>0).toString(16).padStart(8,'0');}
const PINS_ON=()=>CONFIG.pins&&Object.keys(CONFIG.pins).length>0;
function pinOk(name,pin){return CONFIG.pins[name]===cyrb53('table2026|'+name+'|'+pin);}
function setLocked(on){document.body.classList.toggle('locked',on);[...document.body.children].forEach(c=>{if(c.id==='who'||c.id==='toast'||c.tagName==='SCRIPT')return;if(on)c.setAttribute('inert','');else c.removeAttribute('inert');});}
function chooseMe(n){const wasGate=$('#who').classList.contains('gate');$('#who').classList.remove('gate');setLocked(false);me=n;store.set('ate_me',me);store.set('ate_pinok',n);Game.flush();$('#who').classList.remove('open');renderStatus();Game.renderGbar();refreshOpenModal();Game.syncFromSheet(true);renderSocks();if(wasGate&&!store.get('ate_welcome',0))setTimeout(()=>showWelcome(),350);}
function askPin(n){
  const box=$('#whoBox');box.innerHTML='';if($('#who').classList.contains('gate'))gateHead(box);
  box.appendChild(txt('h2','','Bonjour '+n+' !'));
  box.appendChild(txt('p','note','Tape ton code personnel à 4 chiffres (Mathilde te l\'a envoyé). On ne te le demandera plus sur cet appareil.'));
  const inp=document.createElement('input');inp.type='password';inp.inputMode='numeric';inp.maxLength=4;inp.autocomplete='off';inp.className='pinin';inp.setAttribute('aria-label','Code à 4 chiffres');
  const out=txt('p','note','');const ok=txt('button','btn','Valider');ok.type='button';
  const go=()=>{const wait=Math.ceil((store.get('ate_pinwait',0)-Date.now())/1000);if(wait>0){out.textContent='Trop d\'essais. Le bonhomme a confisqué le clavier : encore '+wait+' s.';return;}
    const v=inp.value.trim();if(!/^\d{4}$/.test(v)){out.textContent='Il faut 4 chiffres.';return;}
    if(pinOk(n,v)){store.set('ate_pinfail',0);chooseMe(n);toast('Bienvenue '+n+' !');}else{const f=store.get('ate_pinfail',0)+1;store.set('ate_pinfail',f);if(f%5===0){store.set('ate_pinwait',Date.now()+30000);out.textContent='Trop d\'essais. Le bonhomme a confisqué le clavier pendant 30 secondes.';inp.value='';return;}out.textContent=pick(['Ce n\'est pas le bon code. Le bonhomme te regarde bizarrement.','Raté. Tu es bien '+n+' ?','Code incorrect. Le cadenas reste fermé.']);inp.value='';inp.focus();const r=inp.getBoundingClientRect();inp.classList.remove('shake');void inp.offsetWidth;inp.classList.add('shake');}};
  ok.addEventListener('click',go);inp.addEventListener('keydown',e=>{if(e.key==='Enter')go();});
  const back=txt('button','btn ghost','Ce n\'est pas moi');back.type='button';back.addEventListener('click',()=>askWho(true));
  box.appendChild(inp);box.appendChild(ok);box.appendChild(out);box.appendChild(back);setTimeout(()=>inp.focus(),50);
}
function gateHead(box){const lk=el('div','gatehead');lk.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="10" width="16" height="11" rx="3" fill="#ffcf5c" stroke="#2b1b3d" stroke-width="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3" fill="none" stroke="#2b1b3d" stroke-width="2.4"/><circle cx="12" cy="15.5" r="1.8" fill="#2b1b3d"/></svg><span>La Table des Enfants · entrée réservée</span>';box.appendChild(lk);}
function askWho(force){
  const ov=$('#who');const box=$('#whoBox');box.innerHTML='';
  const gate=!me;ov.classList.toggle('gate',gate);setLocked(gate);
  if(gate)gateHead(box);
  box.appendChild(txt('h2','','Qui es-tu ?'));
  box.appendChild(txt('p','note',PINS_ON()?(gate?'Ce calendrier est réservé aux huit membres de la Table. Choisis ton prénom, puis tape ton code à 4 chiffres.':'Choisis ton prénom, puis ton code à 4 chiffres. Personne ne peut voter ou lire ta chaussette à ta place.'):'Pas de mot de passe : ton prénom sert seulement à compter tes votes une seule fois.'));
  const m=el('div','members');
  MEMBERS.forEach(n=>{const b=txt('button','opt',n);b.type='button';b.addEventListener('click',()=>{if(PINS_ON()&&store.get('ate_pinok',null)!==n)askPin(n);else chooseMe(n);});m.appendChild(b);});
  box.appendChild(m);
  if(!gate){const skip=txt('button','btn ghost','Annuler');skip.type='button';skip.addEventListener('click',()=>{ov.classList.remove('open');});box.appendChild(skip);}
  ov.classList.add('open');
}

/* ---------- bienvenue (première visite) ---------- */
function gcalUrl(){
  // Google Agenda : événement à 9 h (heure de Paris) le 1er décembre, répété 25 jours
  const base=/^https?:/.test(location.href)?location.origin+location.pathname:'';
  const p=new URLSearchParams({action:'TEMPLATE',text:'Ouvrir la case du jour (Table des Enfants)',dates:'20261201T090000/20261201T091500',ctz:'Europe/Paris',recur:'RRULE:FREQ=DAILY;COUNT=25',details:'Une case par jour. Les week-ends et le 25 rapportent 2 points de plus si tu ouvres le jour J.'+(base?'\n'+base:'')});
  return 'https://calendar.google.com/calendar/render?'+p.toString();
}
function gcalLink(label,cls){
  const a=txt('a',cls||'btn ghost',label);a.href=gcalUrl();a.target='_blank';a.rel='noopener';return a;
}
function showWelcome(after){
  const ov=$('#welcome'),box=$('#welcomeBox');box.innerHTML='';
  box.appendChild(txt('h2','','Bienvenue à la Table'));
  const ul=el('ul','wl');
  ['Une case par jour, du 1er au 25 décembre. Les cases passées restent ouvrables en retard (1 point au lieu de 3).','Ton prénom et ton code servent à compter tes votes une fois et à garder tes points. Sur un autre appareil, reconnecte-toi avec le même prénom et le même code : tes points reviennent (Google met quelques minutes à suivre).','Ouvre la case le jour J pour les points, les séries et les badges. Ton Carnet explique tout, point par point.'].forEach(x=>ul.appendChild(txt('li','',x)));
  box.appendChild(ul);
  const ics=gcalLink('Ajouter un rappel à 9 h dans Google Agenda');
  const ok=txt('button','btn','C\'est parti');ok.type='button';
  ok.addEventListener('click',()=>{store.set('ate_welcome',1);ov.classList.remove('open');if(after)after();});
  box.appendChild(ok);box.appendChild(ics);
  ov.classList.add('open');ok.focus();
}

/* ---------- focus dans les fenêtres ---------- */
function setupFocus(){
  const ids=['modal','carnet','who','welcome'];
  ids.forEach(id=>{
    const ov=document.getElementById(id);let opener=null;
    new MutationObserver(()=>{
      document.body.classList.toggle('ov',ids.some(i=>document.getElementById(i).classList.contains('open')));
      if(ov.classList.contains('open')){if(!ov._was){opener=document.activeElement;ov._was=true;}}
      else if(ov._was){ov._was=false;if(opener&&opener.isConnected&&opener.focus)opener.focus();}
    }).observe(ov,{attributes:true,attributeFilter:['class']});
  });
  document.addEventListener('keydown',e=>{
    if(e.key!=='Tab')return;
    const ov=ids.map(i=>document.getElementById(i)).filter(o=>o.classList.contains('open')).pop();if(!ov)return;
    const f=[...ov.querySelectorAll('button,a[href],input,select,textarea,[tabindex]:not([tabindex="-1"])')].filter(x=>!x.disabled&&!x.hidden&&x.offsetParent!==null);
    if(!f.length)return;
    const first=f[0],last=f[f.length-1];
    if(!ov.contains(document.activeElement)){e.preventDefault();first.focus();}
    else if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
    else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
  });
}

/* ---------- modale de case ---------- */
let openedDay=null;
function openDay(x){
  openedDay=x;
  const box=$('#sheet');box.innerHTML='';
  const close=txt('button','close','×');close.type='button';close.setAttribute('aria-label','Fermer');close.addEventListener('click',closeModal);
  box.appendChild(close);
  const head=el('div','');
  head.appendChild(txt('span','badge',TYPES[x.type].label));
  if(x.noel)head.appendChild(txt('span','badge noel','Noël'));
  box.appendChild(head);
  box.appendChild(txt('p','daynum','Case '+x.d+' · '+x.d+' décembre'));
  if(Game.isWE(x.d)&&x.d===todayNum)box.appendChild(txt('p','note','Bonus week-end / jour férié : +2 pts pour avoir ouvert la case ce jour-là.'));
  box.appendChild(txt('h2','',x.title));
  if(x.d===1||x.d===25)setTimeout(()=>fireworks(x.d===25?6000:4200),250);
  const first=Game.isFirst(x);
  const rest=el('div','rest');
  if(first){
    rest.hidden=!Game.gameDone(x);
    box.appendChild(Game.gameBlock(x,{first:true,onDone:()=>{rest.hidden=false;rest.classList.add('reveal');}}));
  }
  rest.appendChild(el('div','body',x.body));
  rest.appendChild(Game.special(x));
  if(x.d===19)rest.appendChild(pullBlock());
  if(TIGRE_DAY&&x.d===TIGRE_DAY)rest.appendChild(tigreBlock());
  if(x.d===GIFT_DAY)rest.appendChild(giftBlock());
  if(x.d===21)rest.appendChild(devinBlock());
  if(x.links&&x.links.length){
    const l=el('div','links');l.appendChild(txt('h3','','Pour aller plus loin'));
    x.links.forEach(([label,url])=>{const a=txt('a','',label);a.href=url;a.target='_blank';a.rel='noopener noreferrer';l.appendChild(a);});
    rest.appendChild(l);
  }
  x.qs.forEach(q=>rest.appendChild(questionBlock(q,x)));
  if(x.d===25)rest.appendChild(finaleExtras());
  rest.appendChild(Game.teaserBlock(x));
  box.appendChild(rest);
  $('#modal').classList.add('open');
  document.body.style.overflow='hidden';
  box.scrollTop=0;
  close.focus();
}
function closeModal(){$('#modal').classList.remove('open');document.body.style.overflow='';openedDay=null;}
function refreshOpenModal(){if(openedDay)openDay(openedDay);}

/* ---------- questions et votes ---------- */
function optionsFor(q){
  if(q.kind==='who')return MEMBERS.slice();
  if(q.kind==='scale')return Array.from({length:11},(_,i)=>String(i));
  return q.options||[];
}
function revealDay(id){const n=parseInt(id,10);return /^25/.test(String(id))?26:n+1;}

function questionBlock(q,x){
  const wrap=el('div','qbox');
  wrap.appendChild(txt('h3','','Question de la table'));
  wrap.appendChild(txt('p','qtext',q.text));
  const already=myVotes[q.id];
  let chosen=already||null;
  let ctl;
  if(q.kind==='select'){
    ctl=document.createElement('select');ctl.setAttribute('aria-label',q.text);
    ctl.appendChild(txt('option','','Choisis une case…')).value='';
    DAYS.slice(0,24).forEach(dd=>{const o=txt('option','',`Case ${dd.d} : ${dd.title}`);o.value=String(dd.d);ctl.appendChild(o);});
    if(already)ctl.value=already;
    ctl.disabled=!!already;
    ctl.addEventListener('change',()=>{chosen=ctl.value||null;btn.disabled=!chosen;});
    wrap.appendChild(ctl);
  }else{
    ctl=el('div','opts'+(q.kind==='scale'?' scale':''));ctl.setAttribute('role','radiogroup');ctl.setAttribute('aria-label',q.text);
    optionsFor(q).forEach(o=>{
      const b=txt('button','opt',o);b.type='button';b.setAttribute('role','radio');b.setAttribute('aria-checked',String(already===o));
      b.disabled=!!already;
      b.addEventListener('click',()=>{chosen=o;[...ctl.children].forEach(c=>c.setAttribute('aria-checked',String(c===b)));btn.disabled=false;});
      ctl.appendChild(b);
    });
    wrap.appendChild(ctl);
  }
  const btn=txt('button','btn'+(already?' done':''),already?'✓ Vote enregistré':'Voter');btn.type='button';btn.disabled=true;
  const note=txt('p','note',already?'Ta réponse est enregistrée : '+already:'');
  btn.addEventListener('click',async()=>{
    if(!me){askWho(true);return;}
    if(!chosen)return;
    btn.disabled=true;btn.textContent='Envoi…';
    await sendVote(me,q.id,chosen);rowsPromise=null;
    myVotes[q.id]=chosen;store.set('ate_votes',myVotes);
    btn.textContent='✓ Vote enregistré';btn.classList.add('done');note.textContent='Ta réponse est enregistrée : '+chosen;
    Game.onVote(q);
    [...(ctl.children||[])].forEach(c=>{if(c.tagName==='BUTTON')c.disabled=true;});
    if(ctl.tagName==='SELECT')ctl.disabled=true;
    hold.replaceChildren(statsBlock(q,()=>hold.replaceChildren(statsBlock(q,rerender))));
  });
  if(!already){btn.disabled=true;}
  wrap.appendChild(btn);wrap.appendChild(note);
  const hold=el('div','');const rerender=()=>hold.replaceChildren(statsBlock(q,rerender));
  hold.appendChild(statsBlock(q,rerender));wrap.appendChild(hold);
  return wrap;
}

const TEST_TAG='[test] ';
async function sendVote(name,day,answer){
  if(!CONFIG.formUrl||!CONFIG.entry.name)return;
  // en mode test, la réponse part quand même, marquée « [test] » : elle n'apparaît que dans les résultats du mode test
  if(TEST_MODE)name=TEST_TAG+name;
  try{
    const body=new URLSearchParams();
    body.append(CONFIG.entry.name,name);body.append(CONFIG.entry.day,day);body.append(CONFIG.entry.answer,answer);
    await fetch(CONFIG.formUrl,{method:'POST',mode:'no-cors',body,keepalive:true});
  }catch(e){}
}

/* ---------- stats ---------- */
function parseCSV(t){
  const out=[];let row=[],f='',q=false;
  for(let i=0;i<t.length;i++){
    const ch=t[i];
    if(q){if(ch==='"'){if(t[i+1]==='"'){f+='"';i++;}else q=false;}else f+=ch;}
    else if(ch==='"')q=true;
    else if(ch===','){row.push(f);f='';}
    else if(ch==='\n'){row.push(f);out.push(row);row=[];f='';}
    else if(ch!=='\r')f+=ch;
  }
  if(f.length||row.length){row.push(f);out.push(row);}
  return out;
}
// horodatage du tableur : « 03/12/2026 14:05:09 » (FR), « 12/3/2026 14:05:09 » (US) ou « 2026-12-03 14:05 »
function tsInfo(t){
  t=(t||'').trim();let m,mo=0,d=0,h=12;
  if((m=/(\d{4})-(\d{1,2})-(\d{1,2})/.exec(t))){mo=+m[2];d=+m[3];}
  else if((m=/(\d{1,2})\/(\d{1,2})\/(\d{2,4})/.exec(t))){const a=+m[1],b=+m[2];
    if(b===12||b===11){mo=b;d=a;}else if(a===12||a===11){mo=a;d=b;}else if(b>12){mo=a;d=b;}else{mo=b;d=a;}}
  const hm=/(\d{1,2}):(\d{2})(?::(\d{2}))?/.exec(t);let mi=0,se=0;if(hm){h=+hm[1];mi=+hm[2];se=+(hm[3]||0);}
  return{mo,d,h,mi,se};
}
let rowsPromise=null;
function getAllRows(){
  if(!CONFIG.statsCsvUrl)return Promise.resolve(null);
  if(!rowsPromise){
    rowsPromise=fetch(CONFIG.statsCsvUrl,{cache:'no-store'}).then(r=>{if(!r.ok)throw 0;return r.text();}).then(t=>{
      const c=CONFIG.csvCols;const out=[];
      parseCSV(t).slice(1).forEach(r=>{let n=(r[c.name]||'').trim();const isT=n.startsWith(TEST_TAG.trim());if(isT&&!TEST_MODE)return;if(isT)n=n.slice(TEST_TAG.trim().length).trim();
        const d=(r[c.day]||'').trim(),a=(r[c.answer]||'').trim();if(n&&d&&a)out.push(Object.assign({name:n,day:d,answer:a},tsInfo(r[0])));});
      return out;
    }).catch(()=>null);
  }
  return rowsPromise;
}
// dernière réponse de chaque personne pour chaque identifiant
function dedupe(rows){const last=new Map();rows.forEach(r=>last.set(r.name+'|'+r.day,r));return[...last.values()];}
function getRows(){return getAllRows().then(rows=>rows?dedupe(rows):null);}
// un vote compte s'il est arrivé avant l'ouverture de la case qui dévoile le résultat
function inTime(r,rd){if(!r.mo)return true;if(r.mo<12)return true;return r.mo===12&&r.d<rd;}
function frozenVotes(rows,q){const rd=revealDay(q.id);const mine=rows.filter(r=>r.day===q.id);const ok=dedupe(mine.filter(r=>inTime(r,rd)));const late=dedupe(mine).filter(r=>!ok.some(o=>o.name===r.name));return{ok,late};}
function winners(list){const c=new Map();list.forEach(r=>c.set(r.answer,(c.get(r.answer)||0)+1));const max=Math.max(0,...c.values());return{max,leads:[...c.entries()].filter(e=>e[1]===max).map(e=>e[0]),counts:c};}
function statsBlock(q,rerender){
  const box=el('div','stats');
  const rd=revealDay(q.id);
  if(todayNum<rd){
    box.appendChild(txt('h3','','Résultats'));
    box.appendChild(txt('p','note',rd===26?'Les résultats de cette question seront dévoilés le 26 décembre.':`Les résultats seront dévoilés demain, à l'ouverture de la case ${rd}.`));
    return box;
  }
  box.appendChild(txt('h3','','Résultats de la table'));
  if(TEST_MODE)box.appendChild(txt('p','note small','Mode test : Google met à jour le tableur publié toutes les 5 minutes environ.'));
  const body=txt('p','note','Chargement…');box.appendChild(body);
  getAllRows().then(all=>{
    if(!all){body.textContent=CONFIG.statsCsvUrl?'Les résultats ne se chargent pas pour le moment.':'Les résultats arrivent bientôt.';return;}
    const {ok:mine,late}=frozenVotes(all,q);
    if(!mine.length){body.textContent='Personne n\'a voté à temps pour cette question.';return;}
    body.remove();
    const {max:top,leads,counts}=winners(mine);
    const total=mine.length;
    const award=q.award||((typeof AWARDS!=='undefined'&&AWARDS.find(a=>a.id===q.id))||{}).title;
    if(q.kind==='scale'){
      const avg=mine.reduce((s,r)=>s+(parseFloat(r.answer)||0),0)/total;
      box.appendChild(txt('p','',`Moyenne de la table : ${avg.toFixed(1).replace('.',',')} / 10 (${total} réponse${total>1?'s':''})`));
    }else if(q.kind==='who'&&leads.length){
      const v=el('p','verdict');
      v.appendChild(document.createTextNode(leads.length>1?'Égalité ! ':''));
      v.appendChild(txt('b','',leads.join(' et ')));
      v.appendChild(document.createTextNode(award?(leads.length>1?' se partagent le titre « '+award+' ».':' remporte le titre « '+award+' ».'):(leads.length>1?' à égalité.':' en tête.')));
      box.appendChild(v);
    }else if(leads.length>1&&q.kind!=='scale'){box.appendChild(txt('p','verdict','Égalité parfaite : la Table n\'arrive pas à se décider.'));}
    const opts=q.kind==='select'?[...counts.keys()]:optionsFor(q);
    const sorted=opts.map(o=>[o,counts.get(o)||0]).filter(s=>s[1]>0).sort((a,b)=>b[1]-a[1]);
    const my=myVotes[q.id];
    sorted.forEach(([o,n])=>{
      const label=q.kind==='select'?'Case '+o+' : '+(DAYS[parseInt(o,10)-1]||{title:''}).title:o;
      const r=el('div','bar'+(n===top?' lead':'')+(o===my?' mine':''));
      const lb=txt('span','lbl',label);if(o===my)lb.appendChild(txt('em','minetag',' ← ton vote'));r.appendChild(lb);
      const tr=el('span','track');const f=el('span','fill');f.style.width=(n/top*100)+'%';tr.appendChild(f);r.appendChild(tr);
      r.appendChild(txt('span','val',n+' ('+Math.round(n/total*100)+' %)'));
      box.appendChild(r);
    });
    if(my&&!counts.has(my)&&q.kind!=='scale')box.appendChild(txt('p','note small','Ton vote : '+my+'.'));
    if(late.length)box.appendChild(txt('p','note small',`Résultat arrêté à l'ouverture de la case ${revealDay(q.id)===26?'du 26':revealDay(q.id)}. ${late.length} vote${late.length>1?'s':''} arrivé${late.length>1?'s':''} après coup ${late.length>1?'sont enregistrés':'est enregistré'} mais ne ${late.length>1?'changent':'change'} pas le verdict.`));
  });
  return box;
}

/* ---------- finale ---------- */
function finaleExtras(){
  const w=el('div','');
  const pal=el('div','stats');pal.appendChild(txt('h3','','Palmarès de l\'Avent'));
  const pbody=txt('p','note','Chargement…');pal.appendChild(pbody);
  getAllRows().then(rows=>{
    if(!rows){pbody.textContent=CONFIG.statsCsvUrl?'Le palmarès ne se charge pas pour le moment.':'Le palmarès arrive bientôt.';return;}
    const list=el('div','pal');let any=false;
    AWARDS.forEach(a=>{
      const mine=frozenVotes(rows,{id:a.id}).ok;if(!mine.length)return;
      const lead=winners(mine).leads;
      const row=el('div','');row.appendChild(txt('span','',a.title));row.appendChild(txt('b','',lead.join(' et ')));list.appendChild(row);any=true;
    });
    pbody.replaceWith(any?list:txt('p','note','Pas encore assez de votes.'));
  });
  w.appendChild(pal);
  const rk=el('div','stats');rk.appendChild(txt('h3','','Classement final de la Table'));const rkb=txt('p','note','Chargement…');rk.appendChild(rkb);
  getRows().then(rows=>{if(!rows){rkb.textContent=CONFIG.statsCsvUrl?'Le classement ne se charge pas pour le moment.':'Le classement arrive bientôt.';return;}rkb.replaceWith(Game.rankingEl(rows));});
  w.appendChild(rk);
  w.appendChild(txt('p','note','Et les cadeaux maudits ? On espère qu\'ils étaient assez maudits.'));
  const sec=el('div','');sec.style.textAlign='right';
  const star=txt('button','star','✦');star.type='button';star.setAttribute('aria-label','Une étoile discrète');
  const secret=el('div','msg');secret.hidden=true;
  secret.innerHTML=`<b>Case 26.</b> Quelque part, une démone de la flemme a tout lu. Elle dit : « on se fait ça après les fêtes ». La Table répond : <strong>non, on se voit en janvier</strong>.`;
  star.addEventListener('click',()=>{secret.hidden=!secret.hidden;});
  sec.appendChild(star);w.appendChild(sec);w.appendChild(secret);
  return w;
}

/* ---------- démarrage ---------- */
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if($('#welcome').classList.contains('open')){store.set('ate_welcome',1);$('#welcome').classList.remove('open');}else if($('#carnet').classList.contains('open'))$('#carnet').classList.remove('open');else if($('#who').classList.contains('open')){if(!$('#who').classList.contains('gate'))$('#who').classList.remove('open');}else closeModal();}});
$('#modal').addEventListener('click',e=>{if(e.target.id==='modal')closeModal();});
$('#welcome').addEventListener('click',e=>{if(e.target.id==='welcome'){store.set('ate_welcome',1);$('#welcome').classList.remove('open');}});
$('#who').addEventListener('click',e=>{if(e.target.id==='who'&&!$('#who').classList.contains('gate'))$('#who').classList.remove('open');});


/* ---------- musique 8-bit (générée, aucun fichier) ---------- */
const TRACK_BY_DAY={1:'d1',2:'d2',3:'d3',4:'train',5:'d5',6:'d6',7:'d7',8:'d8',9:'d9',10:'choco',11:'d11',12:'d12',13:'d13',14:'d14',15:'d15',16:'d16',17:'jdr',18:'mimic',19:'d19',20:'d20',21:'d21',22:'dragon',23:'d23',24:'foot',25:'noel'};
const Music=(()=>{
  let ctx=null,master=null,timer=null,on=false,step=0,nextT=0;
  const mf=m=>440*Math.pow(2,(m-69)/12);
  const TRACKS={
    base:{bpm:70,wave:'sine',vol:.075,len:3.4,bvol:.5,lead:[
      [76,0,79,0,84,0,79,0],[81,0,76,0,72,0,76,0],[77,0,81,0,84,0,81,0],[83,0,79,0,74,0,79,0],
      [79,0,84,0,83,0,79,0],[81,0,84,0,81,0,76,0],[77,0,79,0,81,0,77,0],[79,0,74,0,72,0,0,0]],
      bass:[48,45,41,43,48,45,41,43]},
    jdr:{bpm:112,wave:'square',lead:[
      [74,0,74,77,81,0,77,74],[72,0,72,76,79,0,76,72],[70,0,70,74,77,0,74,70],[72,74,76,77,76,74,72,0],
      [74,0,74,77,81,0,84,81],[79,0,77,76,74,0,72,70],[69,70,72,74,77,76,74,72],[74,0,0,0,62,0,0,0]],
      bass:[50,48,46,45,50,43,45,50]},
    choco:{bpm:132,wave:'square',lead:[
      [72,76,79,76,72,76,79,0],[74,77,81,77,74,77,81,0],[76,79,83,79,76,79,84,83],[81,79,77,76,74,0,72,0],
      [72,76,79,84,79,76,72,0],[74,77,81,86,81,77,74,0],[79,81,83,84,83,81,79,76],[77,76,74,72,67,0,72,0]],
      bass:[48,50,52,45,48,50,43,48]},
    dragon:{bpm:80,wave:'sawtooth',vol:.028,lead:[
      [57,0,60,0,64,0,69,0],[65,0,0,0,64,0,0,0],[55,0,59,0,62,0,67,0],[64,0,0,0,62,0,0,0],
      [57,0,60,0,64,0,69,0],[72,0,71,0,69,0,64,0],[62,0,65,0,69,0,74,0],[73,0,69,0,64,0,57,0]],
      bass:[45,41,43,40,45,41,40,45]},
    mimic:{bpm:96,wave:'triangle',vol:.09,lead:[
      [60,0,61,0,60,0,0,0],[63,0,62,0,61,0,0,0],[72,0,71,0,0,0,0,0],[60,61,60,59,60,0,0,0],
      [60,0,61,0,60,0,0,0],[66,0,65,0,63,0,0,0],[84,0,0,83,0,0,82,0],[60,0,0,0,0,0,0,0]],
      bass:[36,36,35,36,36,34,35,36]},
    foot:{bpm:120,wave:'square',lead:[
      [72,72,72,0,67,0,67,0],[69,69,69,0,65,0,65,0],[72,72,72,0,76,0,79,0],[77,0,76,0,74,0,72,0],
      [72,72,72,0,67,0,67,0],[69,69,69,0,65,0,65,0],[67,69,71,72,74,76,77,79],[84,0,84,0,79,0,72,0]],
      bass:[48,53,48,43,48,53,43,48]},
    train:{bpm:140,wave:'square',chug:1,lead:[
      [67,0,67,71,74,0,71,67],[69,0,69,72,76,0,72,69],[71,0,71,74,79,0,74,71],[72,0,71,0,69,0,67,0],
      [67,67,0,67,67,0,71,0],[69,69,0,69,69,0,72,0],[71,74,79,74,71,74,79,0],[79,0,74,0,67,0,0,0]],
      bass:[43,45,47,48,43,45,47,43]},
    noel:{bpm:100,wave:'square',vol:.04,lead:[
      [79,0,76,0,72,0,76,0],[77,0,74,0,71,0,74,0],[79,0,76,0,72,0,76,79],[84,0,0,0,79,0,0,0],
      [81,0,77,0,74,0,77,0],[79,0,76,0,72,0,76,0],[77,79,81,79,77,76,74,72],[72,0,0,0,60,0,0,0]],
      bass:[48,53,48,48,50,48,43,48]}
  };
  let cur='base';
  /* pistes générées : une intention musicale par jour (mélodies originales) */
  const SCALES={major:[0,2,4,5,7,9,11],minor:[0,2,3,5,7,8,10],dorian:[0,2,3,5,7,9,10],phrygian:[0,1,3,5,7,8,10],lydian:[0,2,4,6,7,9,11],mixo:[0,2,4,5,7,9,10],harm:[0,2,3,5,7,8,11],pent:[0,2,4,7,9]};
  const MASKS={even:[1,1,1,1,1,1,1,0],bounce:[1,0,1,1,0,1,1,0],sparse:[1,0,0,1,0,0,1,0],swing:[1,0,1,1,0,1,0,1],arp:[1,1,1,1,1,1,1,1],slow:[1,0,0,0,1,0,0,0]};
  const PROGS={a:[0,5,3,4,0,5,4,0],b:[0,3,4,0,0,3,4,0],c:[0,2,3,4,0,2,4,0],d:[0,0,3,3,0,4,4,0],e:[0,4,5,3,0,4,3,0]};
  function rng(seed){let t=seed>>>0;return()=>{t+=0x6D2B79F5;let r=Math.imul(t^t>>>15,1|t);r^=r+Math.imul(r^r>>>7,61|r);return((r^r>>>14)>>>0)/4294967296;};}
  function gen(sp){
    const rnd=rng(sp.seed),sc=SCALES[sp.scale],n=sc.length,mask=MASKS[sp.rhythm],prog=PROGS[sp.prog];
    const base=sp.root>=65?sp.root-12:sp.root;
    const deg2m=d=>base+sc[((d%n)+n)%n]+12*Math.floor(d/n);
    const lead=[],bass=[];
    let prev=n; // une octave au-dessus de la tonique
    const bars=[];
    for(let b=0;b<8;b++){
      const cd=prog[b];const tones=[cd,cd+2,cd+4];
      let bar;
      if(b===2||b===4||b===5||b===6){ // reprises du début, transposées sur l'accord
        const src=bars[b===2?0:(b===4?0:(b===5?1:2))];
        bar=src.map(x=>x===null?null:x+(cd-prog[b===2?0:(b===4?0:(b===5?1:2))]));
      }else{
        bar=[];
        for(let i=0;i<8;i++){
          if(!mask[i]){bar.push(null);continue;}
          let d;
          if(i===0||i===4){ // temps forts : note de l'accord la plus proche
            const cands=[];tones.forEach(t=>{for(let o=0;o<3;o++)cands.push(t+n*o);});
            cands.sort((x,y)=>Math.abs(x-prev)-Math.abs(y-prev));
            d=cands[Math.floor(rnd()*2)];
          }else{
            const step=[-2,-1,-1,1,1,2][Math.floor(rnd()*6)];
            d=prev+step;
          }
          d=Math.max(n-3,Math.min(n+n+2,d));
          bar.push(d);prev=d;
        }
        if(b===3||b===7){ // cadence : on retombe sur la tonique
          bar[0]=(b===7)?n:n+2;
          for(let i=1;i<8;i++){if(bar[i]!==null&&i>=5)bar[i]=null;}
          if(b===7){bar[4]=n-1;bar[7]=null;}
        }
      }
      bars.push(bar);
      lead.push(bar.map(x=>x===null?0:deg2m(x)));
      let bm=deg2m(cd)-24;while(bm<40)bm+=12;bass.push(bm);
    }
    return{bpm:sp.bpm,wave:sp.wave,vol:sp.vol,chug:sp.chug,lead,bass};
  }
  const GEN={
    d1:{seed:11,bpm:96,wave:'triangle',vol:.1,root:72,scale:'pent',rhythm:'sparse',prog:'a'},
    d2:{seed:22,bpm:100,wave:'triangle',vol:.11,root:57,scale:'dorian',rhythm:'slow',prog:'e'},
    d3:{seed:33,bpm:108,wave:'square',vol:.035,root:57,scale:'harm',rhythm:'swing',prog:'c'},
    d5:{seed:55,bpm:138,wave:'square',vol:.045,root:67,scale:'major',rhythm:'bounce',prog:'d'},
    d6:{seed:66,bpm:84,wave:'triangle',vol:.11,root:57,scale:'dorian',rhythm:'slow',prog:'e'},
    d7:{seed:77,bpm:124,wave:'square',vol:.04,root:64,scale:'phrygian',rhythm:'swing',prog:'b'},
    d8:{seed:88,bpm:92,wave:'triangle',vol:.1,root:72,scale:'lydian',rhythm:'arp',prog:'a'},
    d9:{seed:99,bpm:72,wave:'triangle',vol:.1,root:60,scale:'minor',rhythm:'slow',prog:'e'},
    d11:{seed:111,bpm:112,wave:'square',vol:.035,root:64,scale:'mixo',rhythm:'arp',prog:'c'},
    d12:{seed:121,bpm:128,wave:'square',vol:.035,root:57,scale:'harm',rhythm:'arp',prog:'c'},
    d13:{seed:131,bpm:128,wave:'square',vol:.045,root:65,scale:'major',rhythm:'even',prog:'b'},
    d14:{seed:141,bpm:100,wave:'triangle',vol:.11,root:62,scale:'dorian',rhythm:'swing',prog:'d'},
    d15:{seed:151,bpm:112,wave:'square',vol:.04,root:67,scale:'mixo',rhythm:'bounce',prog:'c'},
    d16:{seed:161,bpm:150,wave:'sawtooth',vol:.026,root:52,scale:'phrygian',rhythm:'bounce',prog:'d',chug:true},
    d19:{seed:191,bpm:126,wave:'square',vol:.04,root:69,scale:'pent',rhythm:'even',prog:'d'},
    d20:{seed:201,bpm:88,wave:'triangle',vol:.11,root:62,scale:'major',rhythm:'sparse',prog:'e'},
    d21:{seed:211,bpm:66,wave:'triangle',vol:.1,root:57,scale:'dorian',rhythm:'slow',prog:'a'},
    d23:{seed:231,bpm:96,wave:'sine',vol:.1,root:76,scale:'lydian',rhythm:'arp',prog:'b'}
  };
  Object.keys(GEN).forEach(k=>{TRACKS[k]=gen(GEN[k]);});
  function tone(type,f,t,dur,vol){
    const o=ctx.createOscillator(),g=ctx.createGain();
    o.type=type;o.frequency.value=f;
    g.gain.setValueAtTime(0.0001,t);g.gain.exponentialRampToValueAtTime(vol,t+0.01);g.gain.exponentialRampToValueAtTime(0.0001,t+dur);
    o.connect(g);g.connect(master);o.start(t);o.stop(t+dur+0.02);
  }
  function schedule(){
    const tr=TRACKS[cur],eighth=60/tr.bpm/2;
    while(nextT<ctx.currentTime+0.25){
      const bar=Math.floor(step/8)%8,i=step%8;
      const n=tr.lead[bar][i];
      if(n)tone(tr.wave,mf(n),nextT,eighth*(tr.len||1.7),tr.vol||0.045);
      const r=tr.bass[bar],bv=tr.bvol||1;
      if(tr.chug){if(i%2===0)tone('triangle',mf(r),nextT,eighth*1.1,0.12*bv);}
      else{
        if(i===0||i===4)tone('triangle',mf(r),nextT,eighth*3.2,0.16*bv);
        if(i===2||i===6)tone('triangle',mf(r+7),nextT,eighth*1.4,0.07*bv);
      }
      step++;nextT+=eighth;
    }
  }
  function ensure(){
    if(!ctx){const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return false;ctx=new AC();master=ctx.createGain();master.gain.value=.5;master.connect(ctx.destination);}
    if(ctx.state==='suspended')ctx.resume();
    return true;
  }
  return{
    get on(){return on;},
    setTrack(k){if(TRACKS[k]&&k!==cur){cur=k;step=0;}},
    start(){if(on||!ensure())return;on=true;nextT=ctx.currentTime+.05;timer=setInterval(schedule,40);},
    stop(){on=false;clearInterval(timer);timer=null;},
    beep(f,d=.2,type='square',v=.08){if(!ensure())return;tone(type,f,ctx.currentTime,d,v);},
    blip(f,d=.12,type='square',v=.07){if(!on||!ctx)return;tone(type,f,ctx.currentTime,d,v);},
    arp(list){if(!on||!ctx)return;list.forEach((m,i)=>tone('square',mf(m),ctx.currentTime+i*.07,.14,.06));}
  };
})();
function setupMusic(){
  const btn=$('#music');if(!btn)return;
  const AC=window.AudioContext||window.webkitAudioContext;
  if(!AC){btn.hidden=true;return;}
  const paint=()=>{btn.setAttribute('aria-pressed',String(Music.on));btn.classList.toggle('on',Music.on);btn.title=Music.on?'Couper la musique':'Mettre la musique';};
  btn.addEventListener('click',()=>{
    if(Music.on){Music.stop();store.set('ate_music','0');}
    else{Music.start();store.set('ate_music','1');}
    paint();
  });
  paint();
  if(store.get('ate_music')==='1'){
    const kick=()=>{removeEventListener('pointerdown',kick);if(store.get('ate_music')==='1'&&!Music.on){Music.start();paint();}};
    addEventListener('pointerdown',kick);
  }
}

/* ---------- easter eggs : sapins et bonhomme de neige ---------- */
const SNOWMAN_LINES=[
 `Je suis un bonhomme de neige, pas une case. Arrête de cliquer.`,
 `Je n'ai pas de bras, juste deux branches. Respecte ça.`,
 `Je ne lèche pas les tables, moi. Je ne donne aucun nom.`,
 `Une pause au Coffee Loud ? Chocolat chaud, tiède pour moi.`,
 `Marine a décoré son sapin le 10 novembre. Je ne juge pas. J'étais déjà là.`,
 `J'adore les câlins tout chauds. Le problème, c'est le mot « chauds ».`,
 `Certaines personnes valent la peine qu'on fonde pour elles. Toi, tu as juste cliqué trois fois.`,
 `Mon rêve, c'est l'été. Tout le monde me dit que c'est une mauvaise idée.`,
 `Tu as pris mon nez ? Rends-le : c'est une carotte, pas un objet de collection.`,
 `L'amour, c'est mettre les besoins de l'autre avant les siens. Aujourd'hui, c'est laisser la case {N} fermée.`,
 `Je suis né avec une tête, un corps, et déjà un avis sur la chaleur.`,
 `Un jour, quelqu'un a rêvé d'être libérée, délivrée. Moi je suis juste posé là.`,
 `Dis-le à Mathilde : j'ai froid aux boules. C'est un fait.`,
 `Le 25 décembre, je serai encore là. Le 26, on verra la météo.`,
 `Jet de dés : 1 naturel. Pas grave, je suis un bonhomme de neige, j'ai déjà fondu pour moins que ça.`,
 `Mon alignement : neutre. Surtout neutre : je suis à 0 °C.`,
 `Dans un donjon, je serais le mimic. Un coffre en neige, ça surprend.`,
 `Dans les jeux d'horreur, le bonhomme de neige qui bouge quand on ne regarde pas, c'est moi. Ne te retourne pas.`,
 `Je compte les jours jusqu'à Noël. Sur mes doigts. Ah non en fait, j'en ai pas.`,
 `Je garde le calendrier la nuit. Personne n'a ouvert de case en avance. Enfin… presque personne.`,
 `Une sorcière boulangère a voulu me cuire. J'ai refusé poliment.`,
 `Kupo ! Il y a sûrement un moogle derrière ce volet.`,
 `Je ne suis pas un Pokémon, mais j'ai déjà un type : glace.`,
 `Mon cœur est un peu froid, mais il est sincère.`,
 `Les petits esprits de neige te regardent cliquer.`,
 `Il est dangereux d'y aller seul. Prends cette carotte.`,
 "Pas de bras, pas de chocolat ! Merde…"
];
const PINE_LINES=[
 `Ce sapin a déjà été décoré avant le 10 novembre. Chut.`,
 `Un sapin, c'est une raclette verticale. Ça se garnit.`,
 `Je suis un sapin, pas un portemanteau. Mais bon, vas-y.`,
 `Encore une boule ? Tu me gâtes.`,
 `Ne me secoue pas. J'ai des projets.`,
 `Si tu cherches les cadeaux, ils sont derrière le bonhomme de neige.`,
 `Je perds mes aiguilles, pas mon calme.`,
 `Marine m'a décoré le 10 novembre. Je suis prêt depuis.`,
 `Un sapin ne dort jamais. Il attend.`,
 `Plus je brille, moins on voit que je penche.`,
 `Je suis vert, mais je ne le fais pas exprès.`,
 `Ici, on ne dit pas « sapin », on dit « grand arbre à boules ».`,
 `Pas de panique : le chat ne m'a pas encore vu.`,
 `Guirlande ou pas guirlande, je reste classe.`,
 `Chaque boule est une décision. Merci pour celle-ci.`,
 `Je ne fais pas partie du paysage. Je suis le paysage.`,
 `Un dragon dort sous mes branches. Parle moins fort.`,
 `Mathilde a dit que j'étais le plus beau. Je ne vérifie pas.`,
 `Les étoiles là-haut ? Je les ai vues avant toi.`,
 `On m'a dit que le Coffee Loud avait un meilleur sapin. Je ne les crois pas.`,
 `Tu as de l'or dans les doigts. Ou de la glu. Je ne sais pas.`,
 `Un peu plus à gauche. Non, à droite. Voilà.`,
 `Je tiens debout par miracle et par un seau de sable.`,
 `Dans une autre vie, j'étais un mât de pirate.`
];
const PINE_SPOTS=(()=>{
  const hw=y=>y<34?(y-4)/30*20:(y<56?10+(y-34)/22*16:12+(y-56)/20*16);
  const out=[];
  [14,20,26,31,38,44,50,54,60,66,71].forEach(y=>{
    const w=hw(y)*0.78,n=Math.floor(2*w/9)+1;
    for(let i=0;i<n;i++){const x=n===1?30:30-w+(2*w)*i/(n-1);out.push([x/60*100,y/90*100]);}
  });
  return out;
})();
const LIT_LINES=["Je clignote. Marine dit que c'est de l'art.", "Allumé, je me sens important.", "Les guirlandes, c'est mon seul rapport à l'électricité.", "Je suis prêt pour la photo de famille.", "Si je clignote trop, c'est que je suis émotif.", "Éclairé de la tête aux pieds. Les aiguilles n'ont rien vu venir.", "Ne me regarde pas trop longtemps : tu vas voir des étoiles.", "Je brille. Le bonhomme de neige est jaloux.", "Lumière, couleurs, ambiance. Il ne me manque que le chocolat chaud.", "Je suis la lumière de la Table. Enfin, du coin du salon.", "Mes boules sont bien accrochées. C'est un exploit.", "Allumé depuis tout à l'heure. Aucun regret.", "On dirait un sapin. Ah oui, c'est moi.", "Un jour, je serai un sapin de centre commercial. Ça vous fera drôle.", "Ça sent le sapin. C'est moi, merci de le noter.", "Je suis rouge, jaune, bleu, violet et blanc. Je ne choisis pas.", "Ça chatouille, les guirlandes. C'est le prix de la gloire.", "Les lumières, c'est comme les cases : une par jour, c'est mieux.", "Je scintille avec modération. Enfin, avec beaucoup, mais avec style.", "J'ai la boule. Plusieurs, même.", "Les boules, ça tient. Les promesses, c'est plus compliqué.", "C'est joli, mais ça fait un peu chaud.", "Ne me secoue pas, tout est en équilibre fragile.", "Je suis la star du salon. Le bonhomme de neige le sait.", "Je me sens fêtard. Et vert.", "Branché sur l'ambiance.", "Mon moment de gloire dure tant que tu cliques.", "Ta curiosité me fait briller.", "Ho ho ho. Pardon, c'est une habitude locale.", "Je suis allumé et je n'ai pas peur de le dire."];
const SULK_ARG=["Arg. Je crois que tu m'as tapé dans la gorge cette fois-ci.","Aïe. Là, tu as touché la carotte.","Ouille. Dans les côtes. Je n'en ai pas, mais ça fait mal quand même.","Hé ! Je suis en neige, pas en caoutchouc."];
const SULK_END=["J'ai plus envie de parler.","Je fais la tête. Reviens demain.","Chut. Je regarde la neige tomber.","Je n'ai plus rien à dire. Je fonds en silence."];
function snowTalk(){const t=store.get('ate_snowtalk',null);return(t&&t.d===todayNum)?t:{d:todayNum,n:0};}
function pineDayState(){
  const st=store.get('ate_pine',null);
  return (st&&st.d===todayNum)?st:{d:todayNum,pl:0,pr:0};
}
function bubble(host,ground,msg){
  let b=ground.querySelector('.bubble');
  if(!b){b=el('div','bubble');b.setAttribute('role','status');ground.appendChild(b);}
  if(document.body.classList.contains('uwu')&&!/uwu/.test(msg))msg+=' uwu';
  b.textContent=msg;
  const gx=host.offsetLeft+host.offsetWidth/2;
  const bw=b.offsetWidth||220,gl=ground.getBoundingClientRect().left;
  const lo=8-gl+bw/2,hi=document.documentElement.clientWidth-8-gl-bw/2;
  b.style.left=Math.max(lo,Math.min(hi,gx))+'px';
  b.style.bottom=(ground.clientHeight-host.offsetTop+6)+'px';
  const dur=Math.max(6500,3000+msg.length*70);
  b.style.setProperty('--d',dur+'ms');
  b.classList.remove('show');void b.offsetWidth;b.classList.add('show');
  clearTimeout(b._t);b._t=setTimeout(()=>b.classList.remove('show'),dur);
}
function nextFrom(h,pool,key){
  key=key||'p';h._dk=h._dk||{};
  const st=h._dk[key]||(h._dk[key]={deck:[],last:null});
  if(!st.deck.length){
    st.deck=pool.slice();
    for(let i=st.deck.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[st.deck[i],st.deck[j]]=[st.deck[j],st.deck[i]];}
    const l=st.deck.length-1;
    if(l>0&&st.deck[l]===st.last){[st.deck[0],st.deck[l]]=[st.deck[l],st.deck[0]];}
  }
  st.last=st.deck.pop();return st.last;
}
// répliques réservées à un jour (d) ou à une semaine de décor (w)
const SNOWMAN_DATED=[
 {d:20,t:"Le chocolat chaud me fait de l'œil aujourd'hui. Je résiste. Je suis de glace."},
 {w:2,t:"Cette semaine, je pétris, je malaxe, et je fais monter la pâte bien comme il faut."},
 {w:2,t:"À la boulangerie, on m'a dit que j'avais la plus belle baguette du quartier. Je n'ai pas compris, mais j'ai dit merci."}
];
function snowPool(){
  const n=todayNum+1,ok=todayNum>=0&&todayNum<=24;
  const base=SNOWMAN_LINES.filter(l=>ok||!l.includes('{N}')).map(l=>l.replace('{N}',String(n)));
  const wk=typeof WEEK==='function'?WEEK():1;
  return base.concat(SNOWMAN_DATED.filter(x=>(x.d&&x.d===todayNum)||(x.w&&x.w===wk&&todayNum>=1)).map(x=>x.t));
}
function burst(ground,host,n,up){
  const gx=host.offsetLeft+host.offsetWidth/2,gy=host.offsetTop+host.offsetHeight*(up?.25:.5);
  for(let i=0;i<n;i++){
    const p=el('span','pf');
    p.style.left=gx+'px';p.style.top=gy+'px';
    p.style.setProperty('--dx',((Math.random()-.5)*(up?90:140))+'px');
    p.style.setProperty('--dy',(up?(Math.random()*70+30):-(Math.random()*90+40))+'px');
    p.style.animationDelay=(Math.random()*.15)+'s';
    ground.appendChild(p);setTimeout(()=>p.remove(),1200);
  }
}
function bigStorm(){
  toast('Tempête de neige. Tu l\'as cherché.');
  for(let i=0;i<70;i++){
    const f=el('span','storm');f.style.left=(Math.random()*100)+'vw';
    f.style.animationDelay=(Math.random()*1.6)+'s';f.style.animationDuration=(2.2+Math.random()*1.8)+'s';
    f.style.setProperty('--s',(4+Math.random()*7)+'px');
    document.body.appendChild(f);setTimeout(()=>f.remove(),5200);
  }
}
let eggTotal=0;
function setupEggs(){
  const ground=$('.ground');if(!ground)return;
  ground.querySelectorAll('.egg').forEach(h=>{
    let n=0;
    h.addEventListener('click',()=>{
      n++;eggTotal++;Game.eggClick(h);
      const anim=h.classList.contains('snowman')?'jump':'shk';
      h.classList.remove('jump','shk');void h.offsetWidth;h.classList.add(anim);
      if(h.classList.contains('snowman')){
        const ts=snowTalk();ts.n++;store.set('ate_snowtalk',ts);
        if(ts.n>7)return;
        burst(ground,h,14,false);
        Music.arp([72,76,79,84]);
        if(ts.n===3){
          h.classList.add('melt');bubble(h,ground,'Je fonds… dites à Mathilde que c\'était bien.');
          const nx=Game.nextCostume(h.dataset.cos||'');
          setTimeout(()=>{h.classList.remove('melt');h.dataset.cos=nx.cos;bubble(h,ground,nx.line);},3800);
        }else if(ts.n===2&&teaseLine())bubble(h,ground,teaseLine());
        else if(ts.n===4&&lastLine())bubble(h,ground,lastLine());
        else if(ts.n===6)bubble(h,ground,pick(SULK_ARG));
        else if(ts.n===7){bubble(h,ground,pick(SULK_END));Game.setSulk();}
        else bubble(h,ground,nextFrom(h,snowPool(),'snow'));
      }else{
        burst(ground,h,12,true);
        const bl=h.querySelector('.baubles');
        if(bl){
          if(!h._spots){h._spots=PINE_SPOTS.slice();for(let i=h._spots.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[h._spots[i],h._spots[j]]=[h._spots[j],h._spots[i]];}}
          let add=5;
          while(add-->0&&bl.children.length<h._spots.length){
            const sp=h._spots[bl.children.length],c=el('span','bauble');
            c.style.left=sp[0]+'%';c.style.top=sp[1]+'%';
            c.style.background=['#e5484d','#ffcf5c','#6ec6ff','#8e5bd6','#fff'][Math.floor(Math.random()*5)];
            bl.appendChild(c);
          }
        }
        Music.blip(660+Math.random()*400,.1,'triangle',.1);
        const key=h.classList.contains('pl')?'pl':'pr';
        const st=pineDayState();const c=st[key]||0;st[key]=c+1;store.set('ate_pine',st);
        const full=bl&&bl.children.length>=h._spots.length;
        const justLit=full&&!h.classList.contains('lit');
        if(justLit){h.classList.add('lit');Game.setLit();}
        if(justLit){bubble(h,ground,LIT_LINES[(Math.max(todayNum,0)*7+(key==='pl'?0:13))%LIT_LINES.length]);}
        else if(h.classList.contains('lit')){
          const k2=key+'L',lc=st[k2]||0;st[k2]=lc+1;store.set('ate_pine',st);
          if(lc<2)bubble(h,ground,nextFrom(h,LIT_LINES,'lit'));
          else if(lc===2)bubble(h,ground,nextFrom(h,PINE_COQUIN,'coq')+' '+pick(KAO_SHY));
          else if(lc===3)bubble(h,ground,'Arrête. '+pick(KAO_SHY));
          else if(lc===4)bubble(h,ground,'Je boude. '+pick(KAO_SULK));
        }
        else if(c<2)bubble(h,ground,nextFrom(h,PINE_LINES,'pine'));
        else if(c===2)bubble(h,ground,nextFrom(h,PINE_COQUIN,'coq')+' '+pick(KAO_SHY));
        else if(c===3)bubble(h,ground,'Arrête. '+pick(KAO_SHY));
        else if(c===4)bubble(h,ground,'Je boude. '+pick(KAO_SULK));
      }
      if(eggTotal===15){bigStorm();}
    });
  });
}

/* ---------- décor latéral (bureau) : lampadaire + compte à rebours, boîte aux lettres ---------- */
function setupSide(){
  const L=$('#sideL'),Rr=$('#sideR');if(!L||!Rr)return;
  L.innerHTML='<div class="lamp"><svg viewBox="0 0 60 150" aria-hidden="true"><g stroke="#2b1b3d" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round"><path d="M30 148V40" fill="none" stroke-width="6"/><rect x="18" y="18" width="24" height="26" rx="4" fill="#ffe9a8" class="glow"/><path d="M14 18l16-12 16 12z" fill="#2f8a62"/><path d="M10 148h40" fill="none"/><path d="M14 150q16-12 32 0z" fill="#fff"/></g></svg><div class="plate"><span id="cdLabel"></span><b id="cdTime"></b></div></div>';
  Rr.innerHTML='<button type="button" class="mail new" id="mailBtn" aria-label="Boîte aux lettres : le courrier de demain"><svg viewBox="0 0 70 110" aria-hidden="true"><g stroke="#2b1b3d" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round"><path d="M35 108V60" fill="none" stroke-width="6"/><path d="M12 60V40q0-18 23-18t23 18v20z" fill="#e5484d"/><path d="M12 60h46" fill="none"/><g class="flag"><path d="M20 30V6" fill="none"/><path d="M20 6h14v9H20z" fill="#ffcf5c"/></g><path d="M16 22q19-9 38 0" fill="none" stroke="#fff" stroke-width="3"/><path d="M14 110q21-12 42 0z" fill="#fff"/></g></svg><div class="plate"><span id="mailLabel">Courrier du jour</span></div><div class="plate letter" id="mailLetter"></div></button>';
  const lab=$('#cdLabel'),tm=$('#cdTime');
  const fmt=new Intl.DateTimeFormat('fr-FR',{timeZone:TZ,hour:'numeric',minute:'numeric',second:'numeric',hour12:false});
  function tick(){
    if(TEST_MODE){lab.textContent='Mode test';tm.textContent='';return;}
    if(todayNum===0){lab.textContent='Ouverture';tm.textContent='1er déc.';return;}
    if(todayNum>=25){lab.textContent='Joyeux';tm.textContent='Noël';return;}
    const p=fmt.formatToParts(new Date()).reduce((o,x)=>(o[x.type]=+x.value,o),{});
    let sec=86400-((p.hour%24)*3600+p.minute*60+p.second);
    const h=Math.floor(sec/3600),m=Math.floor(sec%3600/60);
    lab.textContent='Prochaine case dans';tm.textContent=h+' h '+String(m).padStart(2,'0');
  }
  tick();setInterval(tick,30000);
  const mb=$('#mailBtn'),ml=$('#mailLetter');
  const key='ate_mail';
  if(store.get(key,0)===todayNum){mb.classList.remove('new');mb.classList.add('read');}
  mb.addEventListener('click',()=>{
    if(mb.dataset.sock==='1'){openMySock();return;}
    let msg;
    if(todayNum<1)msg='Pas encore de courrier. Reviens le 1er décembre.';
    else if(todayNum>=25)msg='Le facteur a fini sa tournée. Joyeux Noël.';
    else msg=(TEASERS[todayNum-1]||'Demain : une surprise.').replace(/^Demain : /,'Demain : ');
    ml.textContent=msg;ml.classList.add('show');
    mb.classList.remove('new');mb.classList.add('read');store.set(key,todayNum);
    clearTimeout(mb._t);mb._t=setTimeout(()=>ml.classList.remove('show'),9000);
  });
}

/* ---------- jouets du décor : flocons, fumée, guirlande, rouge-gorge, boule de neige, feux d'artifice ---------- */
const RM=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
function plus(x,y,t){const p=el('span','plus');p.textContent=t||'+1';p.style.left=x+'px';p.style.top=y+'px';document.body.appendChild(p);setTimeout(()=>p.remove(),900);}
function sparkle(x,y,n=10,col){
  for(let i=0;i<n;i++){const s=el('span','spark');const a=Math.random()*6.283,r=18+Math.random()*26;
    s.style.left=x+'px';s.style.top=y+'px';s.style.setProperty('--dx',Math.cos(a)*r+'px');s.style.setProperty('--dy',Math.sin(a)*r+'px');
    if(col)s.style.background=col;document.body.appendChild(s);setTimeout(()=>s.remove(),700);}
}
const FLAKE_SVG='<svg viewBox="0 0 40 40" aria-hidden="true"><g stroke="#2b1b3d" stroke-width="4.5" stroke-linecap="round"><path d="M20 3v34M5 11.5l30 17M5 28.5l30-17"/><path d="M15 6l5 5 5-5M15 34l5-5 5 5M4 17l7-1-3-6M36 23l-7 1 3 6M4 23l7 1-3 6M36 17l-7-1 3-6"/></g><g stroke="#fff" stroke-width="2" stroke-linecap="round"><path d="M20 3v34M5 11.5l30 17M5 28.5l30-17"/><path d="M15 6l5 5 5-5M15 34l5-5 5 5M4 17l7-1-3-6M36 23l-7 1 3 6M4 23l7 1-3 6M36 17l-7-1 3-6"/></g></svg>';
function setupFlakes(){
  const box=$('#toys');if(!box||RM())return;
  const live=[];
  function spawn(){
    if(document.hidden||document.body.classList.contains('ov')||live.length>=3)return;
    const f=el('button','bflake');f.type='button';f.tabIndex=-1;f.innerHTML=FLAKE_SVG;
    const o={el:f,x:30+Math.random()*(innerWidth-60),y:-40,vx:0,vy:.55+Math.random()*.5,d:Math.random()*6.283,rot:0,grab:false,moved:0,last:null};
    box.appendChild(f);live.push(o);
    f.addEventListener('pointerdown',e=>{e.preventDefault();o.grab=true;o.moved=0;o.last={x:e.clientX,y:e.clientY,t:performance.now()};o.vx=0;f.setPointerCapture(e.pointerId);f.classList.add('held');});
    f.addEventListener('pointermove',e=>{if(!o.grab)return;const dx=e.clientX-o.last.x,dy=e.clientY-o.last.y,dt=Math.max(8,performance.now()-o.last.t);o.moved+=Math.abs(dx)+Math.abs(dy);o.x+=dx;o.y+=dy;o.vx=dx/dt*16;o.vy=dy/dt*16;o.last={x:e.clientX,y:e.clientY,t:performance.now()};});
    const up=()=>{if(!o.grab)return;o.grab=false;f.classList.remove('held');
      if(o.moved<8){catchIt(o);}else{o.thrown=true;o.vy=Math.max(Math.min(o.vy,6),-6);o.vx=Math.max(Math.min(o.vx,8),-8);}};
    f.addEventListener('pointerup',up);f.addEventListener('pointercancel',up);
  }
  function catchIt(o){
    const i=live.indexOf(o);if(i<0)return;live.splice(i,1);
    const r=o.el.getBoundingClientRect();sparkle(r.left+r.width/2,r.top+r.height/2,12,'#bfe8ff');
    o.el.remove();Music.blip(1568,.08,'triangle');setTimeout(()=>Music.blip(2093,.1,'triangle'),70);
    const n=Game.toy('flk');plus(r.left+r.width/2,r.top,'+1 ❄');
    if(n===1)toast('Un flocon attrapé ! Tu peux aussi les attraper et les lancer.');
    else if(n===10||n===25||n===50||n%100===0)toast(n+' flocons attrapés. Ta collection fond doucement.');
  }
  (function frame(){
    const sm=$('.egg.snowman');const smr=sm&&live.some(o=>o.thrown)?sm.getBoundingClientRect():null;
    for(let i=live.length-1;i>=0;i--){const o=live[i];
      if(smr&&o.thrown&&o.x>smr.left&&o.x<smr.right&&o.y>smr.top&&o.y<smr.bottom){sparkle(o.x,o.y,12,'#fff');o.el.remove();live.splice(i,1);snowmanHit(sm);continue;}
      if(o.thrown&&Math.abs(o.vx)<.6&&Math.abs(o.vy-.7)<.3)o.thrown=false;
      if(!o.grab){o.d+=.02;o.vy+=(0.7-o.vy)*.02;o.vx*=.97;o.y+=o.vy;o.x+=o.vx+Math.sin(o.d)*.5;o.rot+=.4+Math.abs(o.vx)*.6;
        if(o.x<10){o.x=10;o.vx=Math.abs(o.vx)*.6;}if(o.x>innerWidth-10){o.x=innerWidth-10;o.vx=-Math.abs(o.vx)*.6;}
        if(o.y<-60)o.vy=Math.abs(o.vy);}
      if(o.y>innerHeight+40){o.el.remove();live.splice(i,1);continue;}
      o.el.style.transform='translate('+(o.x-17)+'px,'+(o.y-17)+'px) rotate('+o.rot+'deg)';
    }
    requestAnimationFrame(frame);
  })();
  setTimeout(spawn,2500);setInterval(spawn,6500);
}
function setupSmoke(){
  document.querySelectorAll('.smoke').forEach(s=>{
    s.addEventListener('pointerdown',e=>{
      if(s.classList.contains('gone'))return;e.preventDefault();
      const r=s.getBoundingClientRect();sparkle(r.left+r.width/2,r.top+r.height/2,9,'#f3eefb');
      s.classList.add('gone');Music.blip(988+Math.random()*400,.06,'square',.05);
      const n=Game.toy('bub');plus(r.left+r.width/2,r.top,'pop');
      if(n===1)toast('Pop ! Les bulles de fumée éclatent quand on les touche.');
      else if(n===20)toast('20 bulles éclatées. La cheminée tousse un peu.');
    });
    s.addEventListener('animationiteration',()=>s.classList.remove('gone'));
  });
}
const BULB_COLS=['#e5484d','#ffcf5c','#3ddc84','#6ec6ff','#c58bff'];
function setupGarland(){
  const g=$('#garl');if(!g)return;
  const N=11,st=[];
  for(let i=0;i<N;i++){
    const b=el('button','bulb');b.type='button';b.tabIndex=-1;
    const t=i/(N-1),left=7+t*86;b.style.left=left+'%';b.style.top=(i%2?93:90)+'%';
    st[i]=i%BULB_COLS.length;b.style.setProperty('--b',BULB_COLS[st[i]]);
    b.addEventListener('click',()=>{
      st[i]=(st[i]+1)%BULB_COLS.length;b.style.setProperty('--b',BULB_COLS[st[i]]);
      b.classList.remove('flash');void b.offsetWidth;b.classList.add('flash');
      Music.blip(523*Math.pow(2,st[i]/5),.09,'triangle',.05);
      Game.toy('blb');
      if(st.every(x=>x===st[0])){
        g.classList.remove('party');void g.offsetWidth;g.classList.add('party');
        if(!Game.flag('glo')){Game.flag('glo',1);toast('Guirlande assortie ! Le bonhomme de neige trouve ça très chic.');}
        else toast('Encore toute assortie. Tu as du goût.');
      }
    });
    g.appendChild(b);
  }
}
function setupBird(){
  const b=$('#bird');if(!b)return;let away=false;
  b.addEventListener('click',()=>{
    if(away)return;away=true;b.classList.add('fly');
    Music.blip(2637,.05,'sine',.05);setTimeout(()=>Music.blip(3136,.06,'sine',.05),90);
    const n=Game.toy('bird');
    if(n===1)toast('Le rouge-gorge s\'envole. Il revient toujours, il est curieux.');
    setTimeout(()=>{b.classList.remove('fly');b.classList.add('back');setTimeout(()=>{b.classList.remove('back');away=false;},900);},RM()?1500:7000);
  });
}
function setupSnowball(){
  const s=$('#sball');if(!s)return;let size=1,rolls=0,x=52,rot=0;
  const place=()=>{s.style.setProperty('--sz',size);s.style.setProperty('--x',x+'%');s.style.setProperty('--r',rot+'deg');};
  place();
  s.addEventListener('click',()=>{
    rolls++;
    if(rolls>=7){
      s.classList.add('away');Music.arp([67,64,60,55]);
      toast('Elle est trop grosse ! La boule de neige part rouler toute seule.');Game.flag('sball',1);Game.toy('roll');
      setTimeout(()=>{s.classList.remove('away');size=1;rolls=0;x=52;rot=0;place();},2600);return;
    }
    let nx,tries=0;do{nx=6+Math.random()*80;tries++;}while(Math.abs(nx-x)<28&&tries<20);
    const dir=nx>x?1:-1;rot+=dir*(Math.abs(nx-x)*14);x=nx;size=Math.min(2.2,size+.2);
    s.classList.remove('hop');void s.offsetWidth;s.classList.add('hop');
    place();Music.blip(196+rolls*30,.12,'triangle',.06);Game.toy('roll');
  });
}
function fireworks(dur=4200){
  if(RM())return;
  const c=$('#fw');if(!c)return;const x=c.getContext('2d');
  c.width=innerWidth;c.height=innerHeight;c.classList.add('on');
  const cols=['#ffcf5c','#e5484d','#3ddc84','#6ec6ff','#c58bff','#fff4dc'];
  const rockets=[],parts=[];const t0=performance.now();let lastLaunch=0;
  function launch(){const y0=innerHeight+10,tgt=innerHeight*(.12+Math.random()*.38);rockets.push({x:innerWidth*(.12+Math.random()*.76),y:y0,vy:-Math.sqrt(2*.25*(y0-tgt))*1.02,vx:(Math.random()-.5)*2,tgt,c:cols[Math.floor(Math.random()*cols.length)]});}
  function burst(r){const n=90;for(let i=0;i<n;i++){const a=i/n*6.283+Math.random()*.1,v=1.5+Math.random()*4.5;parts.push({x:r.x,y:r.y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:1,c:Math.random()<.2?'#fff':r.c});}
    Music.blip(110+Math.random()*60,.25,'sawtooth',.05);}
  (function frame(now){
    const dt=now-t0;
    if(dt<dur-1200&&now-lastLaunch>380){launch();if(Math.random()<.5)launch();lastLaunch=now;}
    x.globalAlpha=1;x.fillStyle='rgba(0,0,0,0)';x.clearRect(0,0,c.width,c.height);x.shadowBlur=8;x.shadowColor='rgba(255,255,255,.6)';
    for(let i=rockets.length-1;i>=0;i--){const r=rockets[i];r.x+=r.vx;r.y+=r.vy;r.vy+=.25;x.fillStyle=r.c;x.beginPath();x.arc(r.x,r.y,3,0,6.283);x.fill();
      if(r.y<=r.tgt||r.vy>=0){burst(r);rockets.splice(i,1);}}
    for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.x+=p.vx;p.y+=p.vy;p.vy+=.06;p.vx*=.985;p.l-=.009;
      if(p.l<=0){parts.splice(i,1);continue;}x.globalAlpha=Math.max(0,p.l);x.fillStyle=p.c;x.beginPath();x.arc(p.x,p.y,3.2,0,6.283);x.fill();}
    x.globalAlpha=1;
    if(dt<dur||parts.length||rockets.length)requestAnimationFrame(frame);else{x.clearRect(0,0,c.width,c.height);c.classList.remove('on');}
  })(t0);
}
function setupToys(){setupFlakes();setupSmoke();setupGarland();setupBird();setupSnowball();}

/* ---------- ambiance : neige qui monte, jour/nuit, étoiles filantes, traîneau, aurore, confettis ---------- */
let Y_WIN=null; // gagnant d'hier, pour les taquineries du bonhomme
const TEASE=[
  "{W} ? « {A} » ? Félicitations. Je garde un œil sur toi.",
  "Hier, la Table a élu {W} « {A} ». Moi, je n'ai rien dit. Je n'ai même pas de bouche, regarde bien.",
  "{W}, « {A} »… Je l'aurais parié. Enfin, si j'avais pu voter.",
  "Bravo {W}. « {A} », c'est un titre qui se mérite. Ou qui se subit.",
  "On se moque gentiment, hein {W} ? « {A} », ça te va très bien."
];
const TEASE_ME=["« {A} » ! Toutes mes félicitations. Je fais semblant d'être surpris.","Alors, « {A} » ? Ne prends pas la grosse tête, elle fondrait."];
function teaseLine(){if(!Y_WIN)return null;const p=Y_WIN.w===me?TEASE_ME:TEASE;return pick(p).replace(/\{W\}/g,Y_WIN.w).replace(/\{A\}/g,Y_WIN.a);}
function setupSnowDepth(){
  const d=Math.max(0,Math.min(todayNum,25));
  document.documentElement.style.setProperty('--snowh',(2+d*.85).toFixed(1)+'px');
  document.body.classList.toggle('buried',d>=25);
}
function hourNow(){const h=new URLSearchParams(location.search).get('heure');if(TEST_MODE&&h!==null&&/^\d{1,2}$/.test(h))return +h%24;return parisHour();}
function setupSky(){
  const apply=()=>{const h=hourNow();const c=h>=7&&h<10?'aube':h>=10&&h<17?'jour':h>=17&&h<19?'crepuscule':'nuit';
    ['aube','jour','crepuscule','nuit'].forEach(k=>document.body.classList.toggle('sky-'+k,k===c));};
  apply();setInterval(apply,5*60*1000);
  if(WEEKEND_DAYS.includes(todayNum)||WEEK()===4){const a=el('div','aurora');a.setAttribute('aria-hidden','true');document.body.insertBefore(a,document.body.firstChild);}
}
const WISHES=["Vœu enregistré. Il sera traité après les fêtes, comme tout le reste.","Ton vœu est parti. Délai de livraison : entre maintenant et jamais.","Vœu noté. L'étoile dit que c'est possible, mais elle dit ça à tout le monde.","Joli vœu. Le bonhomme de neige a fait le même.","L'étoile a filé avec ton vœu. Elle était pressée.","Vœu accepté. Option chocolat chaud incluse."];
function setupShootingStars(){
  if(RM())return;
  const go=()=>{
    if(document.hidden||document.body.classList.contains('ov')||document.body.classList.contains('sky-jour'))return;
    const s=el('button','sstar');s.type='button';s.tabIndex=-1;s.setAttribute('aria-label','Une étoile filante');
    const y=6+Math.random()*22,fromLeft=Math.random()<.5;
    s.style.top=y+'vh';s.style.setProperty('--dir',fromLeft?1:-1);s.style.left=fromLeft?'-8vw':'100vw';
    s.addEventListener('click',()=>{const r=s.getBoundingClientRect();sparkle(r.left+r.width/2,r.top+r.height/2,16,'#ffe9a8');s.remove();
      Music.arp([84,88,91,96]);const n=Game.toy('wish');toast('Une étoile filante ! '+pick(WISHES)+(n===1?' (Elles passent la nuit, de temps en temps.)':''));});
    $('#toys').appendChild(s);setTimeout(()=>s.remove(),2400);
  };
  const loop=()=>{go();setTimeout(loop,25000+Math.random()*35000);};
  setTimeout(loop,9000+Math.random()*8000);
}
const GIFTS=["une paire de chaussettes qui chantent","un pull de Noël en forme de sapin (taille unique : trop grand)","un bon pour un chocolat chaud à volonté","un dé à 20 faces qui ne fait que des 1","un calendrier de l'Avent… pour l'année prochaine","une boule à neige avec le bonhomme dedans (il n'a pas l'air ravi)","un manuel « Mentir à la Table pour les débutants »","un bonnet avec un pompon plus gros que la tête","une carte de jeu de rôle « Relance gratuite »","un mug « Meilleure personne de la Table » (il y en a huit)"];
function setupSleigh(){
  if(todayNum!==24)return;
  const fly=()=>{
    if(document.hidden||document.body.classList.contains('ov'))return;
    const s=el('button','sleigh');s.type='button';s.tabIndex=-1;s.setAttribute('aria-label','Le traîneau du Père Noël');
    s.innerHTML='<svg viewBox="0 0 220 70" aria-hidden="true"><g stroke="#2b1b3d" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"><path d="M64 38q30 6 60 2" fill="none" stroke="#8a5a3c"/>'+[0,1].map(i=>`<g transform="translate(${8+i*28} ${i?6:0})"><path d="M4 30q4-12 18-12h8q6 0 6 8v4z" fill="#a0673f"/><path d="M26 18l2-10M30 18l6-8M24 10l-4-4M34 10l4-6" fill="none" stroke="#6b4a2e"/><circle cx="34" cy="21" r="2.5" fill="${i?'#2b1b3d':'#e5484d'}" stroke="none"/><path d="M8 30v10M24 30v10" fill="none"/></g>`).join('')+'<path d="M124 34h52q14 0 16-16l8-4-2 22q-4 16-22 16h-46q-10 0-10-8z" fill="#e5484d"/><path d="M118 50h80q8 0 12-6" fill="none" stroke="#ffcf5c" stroke-width="4"/><circle cx="160" cy="18" r="10" fill="#ffe0c2"/><path d="M150 14q10-14 22-2l-4 2z" fill="#e5484d"/><circle cx="172" cy="10" r="3" fill="#fff"/><path d="M152 22q8 10 16 0" fill="#fff"/><rect x="140" y="20" width="16" height="14" rx="2" fill="#3ddc84"/><path d="M148 20v14" fill="none" stroke="#ffcf5c"/></g></svg>';
    let dropped=false;
    s.addEventListener('click',()=>{
      if(dropped){toast('Le Père Noël a déjà lâché ton cadeau. Il a une tournée, tu sais.');return;}
      dropped=true;const r=s.getBoundingClientRect();
      const g=el('span','gift');g.style.left=(r.left+r.width*.7)+'px';g.style.top=(r.top+r.height*.6)+'px';document.body.appendChild(g);
      setTimeout(()=>{const gr=g.getBoundingClientRect();sparkle(gr.left+12,gr.top+12,14,'#ffcf5c');g.remove();},1300);
      Music.arp([79,83,86,91]);Game.toy('gift');
      setTimeout(()=>toast('Un cadeau tombe du traîneau ! Dedans : '+pick(GIFTS)+'.'),900);
    });
    $('#toys').appendChild(s);setTimeout(()=>s.remove(),11000);
  };
  setTimeout(fly,3000);setInterval(fly,45000);
}
function confetti(){
  if(RM())return;
  const cols=['#ffcf5c','#e5484d','#3ddc84','#6ec6ff','#c58bff','#fff4dc'];
  for(let i=0;i<70;i++){const c=el('span','confetti');c.style.left=(Math.random()*100)+'vw';c.style.background=cols[i%cols.length];
    c.style.animationDelay=(Math.random()*.5)+'s';c.style.animationDuration=(1.8+Math.random()*1.4)+'s';c.style.setProperty('--rx',(Math.random()*720-360)+'deg');c.style.setProperty('--sx',(Math.random()*60-30)+'vw');
    document.body.appendChild(c);setTimeout(()=>c.remove(),3600);}
}
const HIT_LINES=["Hé ! Pas dans la carotte !","Raté… ah non, touché. Je note.","Tu veux la guerre ? Tu vas l'avoir.","Esquive ! Enfin, j'ai essayé.","Je suis fait de neige, ça ne compte pas comme une attaque.","Riposte !"];
function snowmanHit(sm){
  const ground=$('.ground');sm.classList.remove('jump','shk');void sm.offsetWidth;sm.classList.add('shk');
  const n=Game.toy('hit');const line=n%4===0?'Riposte !':pick(HIT_LINES);bubble(sm,ground,line);
  Music.blip(330,.1,'square',.06);
  if(line==='Riposte !'&&!RM()){const r=sm.getBoundingClientRect();const b=el('span','sbshot');b.style.left=(r.left+r.width/2)+'px';b.style.top=(r.top+r.height*.3)+'px';
    b.style.setProperty('--tx',(Math.random()*60-30)+'vw');b.style.setProperty('--ty',-(30+Math.random()*30)+'vh');document.body.appendChild(b);
    setTimeout(()=>{const br=b.getBoundingClientRect();sparkle(br.left+8,br.top+8,12,'#fff');b.remove();},900);}
}

/* ---------- décors de la semaine ---------- */
const WEEK=(()=>{const d=Math.max(1,Math.min(todayNum||1,25));return d<=6?1:d<=13?2:d<=20?3:4;});
const WEEK_TXT={
 1:{k:'Le calendrier de l\'Avent de la Table des Enfants · 2026',h:'La Table des Enfants',e:'ouvre ses ',w:'fenêtres',hi:''},
 2:{k:'Nouvelle adresse · La boulangerie du port',h:'La Boulangerie de la Table',e:'ouvre ses ',w:'fenêtres',hi:'Non, tu ne t\'es pas trompé·e de site. La Table a juste déménagé : bienvenue à la boulangerie du port !'},
 3:{k:'Grand marché · 3e semaine · vin chaud et café',h:'Le Marché de Noël de la Table',e:'ouvre ses ',w:'stands',hi:'Non, tu ne t\'es pas trompé·e de site. Cette semaine, la Table tient un marché de Noël.'},
 4:{k:'Dernière étape · Le palais de glace',h:'Le Palais de glace de la Table',e:'ouvre ses ',w:'portes',hi:'Non, tu ne t\'es pas trompé·e de site. Dernière étape avant Noël : le pôle Nord.'}
};
const WITCH_SVG='<svg viewBox="0 0 220 110" aria-hidden="true"><g fill="#1a1330"><path d="M40 79L210 62l1 4L41 83z"/> <path d="M46 76C32 72 14 66 2 70l9 4-9 4 11 2-9 7c14-2 30-5 43-8z"/> <path d="M44 76c2-4 2-8 0-10M38 78c2-3 2-6 0-8" stroke="#1a1330" stroke-width="2" fill="none"/> <path d="M100 76C86 70 70 72 54 82 64 66 80 56 96 50l12-12c8 2 12 12 10 22l-4 14z"/> <path d="M112 40c6 0 10 6 9 14l-8 18-10 2z"/> <circle cx="117" cy="31" r="7.5"/> <path d="M110 33c-8 2-14 8-18 16 6-5 12-8 20-9z"/> <ellipse cx="116" cy="25.5" rx="15" ry="3"/> <path d="M106 25h20c-3-8-9-16-22-24 5 8 4 16 2 24z"/> <path d="M115 46l26 18-3 4-27-15z"/> <path d="M106 72l12 20 4-2-9-19zM98 75l3 21h5l-2-21z"/> <g transform="translate(170 46)"><ellipse cx="8" cy="10" rx="7" ry="8"/><circle cx="10" cy="0" r="5.5"/><path d="M5-3l1-7 4 5zM11-5l4-6 1 7z"/><path d="M2 14c-6 0-8-6-6-12 1 4 3 8 7 9z"/></g></g></svg>';
const DRAGON_SVG='<svg aria-hidden="true" viewBox="-6 -10 314 150"><defs><linearGradient id="dbr" x1="0" x2="1"><stop offset="0" stop-color="#bfe9ff" stop-opacity=".95"/><stop offset="1" stop-color="#bfe9ff" stop-opacity="0"/></linearGradient></defs><g fill="#120d22"><path d="M10 104c20-6 40-6 60-14l6 8c-20 10-42 12-62 14z"/><path d="M4 112l-4-12 14 4z"/><path d="M66 94c10-14 34-20 60-18 20 2 34 0 46-6l6 12c-14 10-30 16-52 18-24 2-44 0-60-6z"/><path d="M92 104l-4 18 7-2 3-15zM140 102l6 16 6-4-5-14z"/><path class="wing" d="M110 82C102 56 86 34 62 20c6 10 8 18 6 24-8-6-18-8-26-6 10 8 14 14 14 22-8-2-16-2-22 2 18 6 34 14 48 24z"/><path class="wing" d="M126 80c-2-30 8-58 30-76-2 10 0 18 4 24 4-8 12-12 20-12-6 8-8 16-6 24 6-4 14-4 20-2-14 6-26 16-36 30z"/><path d="M170 72c14-6 30-14 40-24l10 8c-10 12-28 22-46 28z"/><path d="M206 44c6-8 18-12 28-8l14 6 18 2c4 1 4 5 0 6l-14 2 12 4c2 1 1 4-2 4l-18-2c-10 2-24-2-32-8z"/><path d="M214 38l-14-16 18 10zM224 36l-4-20 10 16z"/><path d="M188 64l-3-9 8 5zM176 72l-4-9 8 6z"/></g><circle cx="236" cy="43" r="2.6" fill="#7fe3ff"/><path class="breath" d="M268 50L306 36V70z" fill="url(#dbr)"/></svg>';
function starIris(){
  if(RM())return;const o=el('div','iris');o.innerHTML='<svg viewBox="0 0 60 60" aria-hidden="true"><path d="M30 3l8 17 19 2-14 13 4 19-17-9-17 9 4-19L3 22l19-2z" fill="#ffcf5c" stroke="#2b1b3d" stroke-width="1.5" stroke-linejoin="round"/></svg>';
  document.body.appendChild(o);setTimeout(()=>o.remove(),1900);
}
function setupStar(){
  const s=$('#pstar');if(!s)return;
  s.addEventListener('click',()=>{
    if(s.classList.contains('got'))return;s.classList.add('got');
    Music.arp([72,76,79,84,88,91,96]);const n=Game.toy('etoile');
    setTimeout(starIris,700);
    setTimeout(()=>toast(n===1?'Tu as trouvé une étoile ! ★ × 1. Elle reviendra : elle aime qu\'on la cherche.':'Encore une étoile ! ★ × '+n+'.'),1500);
    setTimeout(()=>s.classList.remove('got'),4200);
  });
}
document.addEventListener('click',e=>{const l=e.target.closest&&e.target.closest('.slamp');if(!l)return;l.classList.toggle('off');Music.blip(l.classList.contains('off')?330:660,.08,'square',.05);Game.toy('lamp');});
function setupWeek(){
  const w=WEEK();document.body.classList.add('wk'+w);
  const T=WEEK_TXT[w];const k=$('.kicker');if(k)k.textContent=T.k;
  const h1=$('header h1');if(h1&&h1.firstChild){h1.firstChild.textContent=T.h+' ';const em=h1.querySelector('em');if(em&&em.firstChild)em.firstChild.textContent=T.e;const bt=$('#bTitle');if(bt)bt.textContent=T.w;}
  document.title=T.h+' '+T.e+T.w;
  const last=store.get('ate_week',0);store.set('ate_week',w);
  if(last&&last!==w&&T.hi)setTimeout(()=>{toast(T.hi);const sm=$('.egg.snowman');if(sm)bubble(sm,$('.ground'),pick(['Surprise ! On a déménagé.','Ne fais pas cette tête, c\'est toujours moi.','J\'ai changé de décor. Pas de carotte.']));},2600);
  if(w===2||w===4){
    const fly=()=>{if(document.hidden||document.body.classList.contains('ov')||RM())return;
      const f=el('button','flyer'+(w===4?' dragon':''));f.type='button';f.tabIndex=-1;f.setAttribute('aria-label',w===2?'Une sorcière livreuse':'Un dragon de Noël');
      f.innerHTML=(w===2?WITCH_SVG:DRAGON_SVG);
      f.addEventListener('click',()=>{const r=f.getBoundingClientRect();sparkle(r.left+r.width/2,r.top+r.height/2,14,w===2?'#ffcf5c':'#7fd6c2');Game.toy(w===2?'witch':'dragon');
        toast(w===2?pick(['La sorcière livre le pain de la Table. Elle a encore oublié la monnaie.','La sorcière te fait coucou. Son chat, beaucoup moins.','Livraison express de croissants. Signature non requise.']):pick(['Le dragon a fait fondre trois flocons. Il s\'excuse.','Le dragon de Noël te salue. Il a mis son écharpe.','Il crache des flammes ? Non : des paillettes. C\'est Noël.']));});
      $('#toys').appendChild(f);setTimeout(()=>f.remove(),12500);};
    setTimeout(fly,5000);setInterval(fly,42000);
  }
}
function setupAmbiance(){setupWeek();setupStar();setupSnowDepth();setupSky();setupShootingStars();setupSleigh();}

/* ---------- la Table se taquine : chaussettes, couronne, réactions, pull moche, bonhomme qui se souvient ---------- */
const FRIDAYS=[4,11,18,25];
const SOCK_COLS=['#e5484d','#2f8a62','#f2a900','#3d6fe0','#8e5bd6','#e5674d','#3ddc84','#6ec6ff'];
function encM(t){try{return 'm1:'+btoa(unescape(encodeURIComponent(t))).split('').reverse().join('');}catch(e){return t;}}
function decM(t){if(!/^m1:/.test(t))return t;try{return decodeURIComponent(escape(atob(t.slice(3).split('').reverse().join(''))));}catch(e){return '…';}}
function sockReveal(r){const sent=(!r.mo||r.mo<12)?0:r.d;const f=FRIDAYS.find(F=>F>sent);return f||26;}
function nextFriday(){return FRIDAYS.find(F=>F>=Math.max(todayNum,1))||null;}
function fmtDay(d){return(d===1?'1er':d)+' décembre';}
let SOCK_ROWS=[];
function sockData(name){
  const mine=SOCK_ROWS.filter(r=>r.day==='m'&&r.name==='~'+name);
  const open=mine.filter(r=>sockReveal(r)<=todayNum),wait=mine.filter(r=>sockReveal(r)>todayNum);
  return{all:mine,open,wait};
}
function renderSocks(){
  const box=$('#socks');if(!box)return;box.innerHTML='';
  MEMBERS.forEach((n,i)=>{
    const d=sockData(n);const b=el('button','sock'+(n===me?' me':'')+(d.all.length?' full':''));b.type='button';
    b.style.setProperty('--c',SOCK_COLS[i%SOCK_COLS.length]);b.style.setProperty('--fill',Math.min(d.all.length,6));
    b.setAttribute('aria-label',n===me?`Ta chaussette (${d.all.length} mot${d.all.length>1?'s':''})`:`La chaussette de ${n} : y glisser un mot`);
    b.innerHTML='<svg viewBox="0 0 30 44" aria-hidden="true"><path d="M8 2h14v22q0 4 3 7l2 2q3 4-1 8t-9 0l-9-8Q6 31 6 27V2z" fill="var(--c)" stroke="#2b1b3d" stroke-width="2.6" stroke-linejoin="round"/><rect x="5" y="1" width="19" height="8" rx="2" fill="#fff" stroke="#2b1b3d" stroke-width="2.4"/></svg>'+(d.all.length?`<span class="scount">${d.all.length}</span>`:'')+`<span class="sname">${n.replace(/^Florian /,'Flo ')}</span>`;
    if(n===me&&d.open.length>(store.get('ate_sockseen',0)||0))b.classList.add('new');
    if(n===me){const mb=$('#mailBtn');if(mb){const nw=d.open.length>(store.get('ate_sockseen',0)||0);mb.dataset.sock=nw?'1':'';if(nw){mb.classList.add('new');mb.classList.remove('read');mb.setAttribute('aria-label','Boîte aux lettres : des mots t\'attendent dans ta chaussette');}}}
    b.addEventListener('click',()=>n===me?openMySock():openSockFor(n));
    box.appendChild(b);
  });
}
function openMySock(){
  const d=sockData(me);const n=el('div','sockpanel');
  n.appendChild(txt('span','badge','Ta chaussette'));
  n.appendChild(txt('h2','',d.open.length?`${d.open.length} mot${d.open.length>1?'s':''} pour toi`:'Ta chaussette'));
  if(d.open.length){
    const list=el('div','mots');d.open.slice().reverse().forEach((r,i)=>{const m=el('div','mot');m.style.animationDelay=(i*.12)+'s';m.appendChild(txt('p','',decM(r.answer)));m.appendChild(txt('span','note small','Glissé anonymement · ouvert le vendredi '+fmtDay(sockReveal(r))));list.appendChild(m);});
    n.appendChild(list);
    if(d.open.length>(store.get('ate_sockseen',0)||0)){store.set('ate_sockseen',d.open.length);setTimeout(confetti,250);}
  }else n.appendChild(txt('p','note','Pas encore de mot dans ta chaussette.'));
  if(d.wait.length){const nf=nextFriday();n.appendChild(txt('p','sockwait',`${d.wait.length} mot${d.wait.length>1?'s':''} ${d.wait.length>1?'attendent':'attend'} dans ta chaussette. Ouverture le vendredi ${fmtDay(d.wait.map(sockReveal).sort((a,b)=>a-b)[0])}.`));}
  n.appendChild(txt('p','note small','Les mots sont anonymes. On peut taquiner, jamais blesser : c\'est la règle de la Table.'));
  Game.openSheet(n);renderSocks();
}
function openSockFor(name){
  const n=el('div','sockpanel');
  n.appendChild(txt('span','badge','Chaussette de '+name));
  n.appendChild(txt('h2','','Un mot pour '+name));
  if(!me){n.appendChild(txt('p','note','Dis-nous d\'abord qui tu es.'));const b=txt('button','btn','Choisir mon prénom');b.type='button';b.addEventListener('click',()=>{$('#carnet').classList.remove('open');askWho(true);});n.appendChild(b);Game.openSheet(n);return;}
  if(todayNum<1){n.appendChild(txt('p','note','Les chaussettes ouvrent le 1er décembre.'));Game.openSheet(n);return;}
  const nf=nextFriday();
  n.appendChild(txt('p','note',`Ton mot est anonyme. ${name} pourra l'ouvrir le vendredi ${fmtDay(nf&&nf>todayNum?nf:(FRIDAYS.find(F=>F>todayNum)||25))}. Gentil ou taquin, jamais méchant.`));
  n.appendChild(txt('p','note small','Règle : 3 mots maximum par chaussette et par semaine. Le compteur repart à zéro après chaque vendredi.'));
  const sent=store.get('ate_sockout',{});const wk=FRIDAYS.find(F=>F>todayNum)||26;const k=name+'|'+wk;const used=sent[k]||0;
  if(used>=3){n.appendChild(txt('p','note','Tu as déjà glissé 3 mots dans cette chaussette cette semaine. Laisse un peu de place aux autres !'));Game.openSheet(n);return;}
  const ta=document.createElement('textarea');ta.maxLength=180;ta.rows=3;ta.className='motin';ta.placeholder=pick(['Un compliment, une taquinerie, un souvenir…','Ce que tu n\'oses pas dire à table…','Un petit mot qui fera sourire…']);ta.setAttribute('aria-label','Ton mot pour '+name);
  const cnt=txt('span','note small','0 / 180');ta.addEventListener('input',()=>{cnt.textContent=ta.value.length+' / 180';});
  const go=txt('button','btn','Glisser le mot');go.type='button';
  const out=txt('p','note','');
  go.addEventListener('click',async()=>{
    const v=ta.value.trim();if(v.length<3){out.textContent='Un mot un peu plus long, peut-être ?';return;}
    go.disabled=true;go.textContent='Envoi…';
    await sendVote('~'+name,'m',encM(v));
    sent[k]=used+1;store.set('ate_sockout',sent);Game.toy('sock');
    go.textContent='✓ Mot glissé';go.classList.add('done');ta.disabled=true;
    out.textContent=`C'est dans la chaussette. ${name} ne saura pas que c'est toi (sauf si tu signes, ou si tu fais des fautes reconnaissables).`;
    const r=go.getBoundingClientRect();sparkle(r.left+r.width/2,r.top,14,'#ffcf5c');
  });
  n.appendChild(ta);n.appendChild(cnt);n.appendChild(go);n.appendChild(out);
  Game.openSheet(n);setTimeout(()=>ta.focus(),50);
}
/* couronne du lève-tôt */
let L_LAST=null;
function tsKey(r){return((r.mo||0)*100+(r.d||0))*1e6+(r.h||0)*1e4+(r.mi||0)*100+(r.se||0);}
function crownAndLast(all){
  const pill=$('#crown');if(!pill)return;
  const firstOf=d=>{const o=all.filter(r=>r.day==='o'+d&&r.answer==='jour');if(!o.length)return null;return o.slice().sort((a,b)=>tsKey(a)-tsKey(b));};
  const t=todayNum>=1&&todayNum<=25?firstOf(todayNum):null;
  if(t){const w=t[0];pill.hidden=false;pill.innerHTML='';pill.appendChild(txt('span','crownic','♛'));
    pill.appendChild(txt('span','',w.name===me?` Tu es le lève-tôt du jour (${w.h} h ${String(w.mi||0).padStart(2,'0')}) !`:` Lève-tôt du jour : ${w.name} (${w.h} h ${String(w.mi||0).padStart(2,'0')})`));}
  else pill.hidden=true;
  const y=todayNum>1?firstOf(todayNum-1):null;
  if(y&&y.length>=3){const l=y[y.length-1];L_LAST={w:l.name,t:`${l.h} h ${String(l.mi||0).padStart(2,'0')}`};}
}
const LAST_LINES=["Hier, {W} a ouvert la case à {T}. On t'attendait, mais avec amour.","{W}, dernier·e à ouvrir hier ({T}). Le bonhomme de neige ne juge pas. Enfin, un peu.","Petite pensée pour {W}, qui a ouvert la case d'hier à {T}. Tout arrive à qui sait attendre."];
function lastLine(){if(!L_LAST||L_LAST.w===me&&Math.random()<.5)return null;return pick(LAST_LINES).replace('{W}',L_LAST.w===me?'toi':L_LAST.w).replace('{T}',L_LAST.t);}
/* réactions au résultat d'hier */
const REACTS=['Scandale','Mérité','Je demande un recomptage'];
function reactBar(n,all){
  const id='r'+n;const mine=store.get('ate_react',{});
  const rows=dedupe(all.filter(r=>r.day===id));const c={};REACTS.forEach(k=>c[k]=rows.filter(r=>r.answer===k).length);
  if(mine[n]&&!rows.some(r=>r.name===me))c[mine[n]]++;
  const bar=el('div','reacts');
  REACTS.forEach(k=>{const b=txt('button','react'+(mine[n]===k?' on':''),k+(c[k]?' · '+c[k]:''));b.type='button';
    b.addEventListener('click',e=>{e.stopPropagation();if(!me){askWho(true);return;}if(mine[n]===k)return;
      if(mine[n])c[mine[n]]=Math.max(0,c[mine[n]]-1);c[k]++;mine[n]=k;store.set('ate_react',mine);sendVote(me,id,k);
      const r=b.getBoundingClientRect();sparkle(r.left+r.width/2,r.top+r.height/2,10,'#ffcf5c');Music.blip(880,.08,'triangle');
      [...bar.children].forEach((x,i)=>{x.classList.toggle('on',REACTS[i]===k);x.textContent=REACTS[i]+(c[REACTS[i]]?' · '+c[REACTS[i]]:'');});});
    bar.appendChild(b);});
  return bar;
}
/* atelier du pull moche */
const PULL_COLS=['#e5484d','#2f8a62','#3d6fe0','#f2a900','#8e5bd6'];
const PULL_MOTIFS=['sapin','flocon','renne','cœur','éclair'];
const PULL_EXTRAS=['rien','pompons','guirlande'];
function motifSVG(m,x,y){
  if(m===0)return `<path d="M${x} ${y-5}l4 6h-2.5l3 4h-9l3-4H${x-4}z" fill="#3ddc84" stroke="#2b1b3d" stroke-width="1"/>`;
  if(m===1)return `<path d="M${x} ${y-5}v10M${x-4.5} ${y-2.5}l9 5M${x-4.5} ${y+2.5}l9-5" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/>`;
  if(m===2)return `<circle cx="${x}" cy="${y+1}" r="3.4" fill="#a0673f" stroke="#2b1b3d" stroke-width="1"/><circle cx="${x}" cy="${y+3}" r="1.3" fill="#e5484d"/><path d="M${x-2} ${y-2}l-2-4M${x+2} ${y-2}l2-4" stroke="#6b4a2e" stroke-width="1.4"/>`;
  if(m===3)return `<path d="M${x} ${y+4}l-4.5-4.5a2.6 2.6 0 0 1 4.5-3 2.6 2.6 0 0 1 4.5 3z" fill="#ff8fb1" stroke="#2b1b3d" stroke-width="1"/>`;
  return `<path d="M${x+1} ${y-6}l-4 6h3l-2 6 5-7h-3z" fill="#ffcf5c" stroke="#2b1b3d" stroke-width="1"/>`;
}
function pullSVG(code,small){
  const [c,m,e]=String(code||'0-0-0').split('-').map(n=>+n||0);const col=PULL_COLS[c%5];
  let mot='';[20,35,50].forEach(x=>mot+=motifSVG(m%5,x,70));[27,43].forEach(x=>mot+=motifSVG(m%5,x,82));
  let ex='';if(e===1)ex='<circle cx="22" cy="56" r="3" fill="#fff" stroke="#2b1b3d" stroke-width="1.5"/><circle cx="48" cy="56" r="3" fill="#fff" stroke="#2b1b3d" stroke-width="1.5"/><circle cx="35" cy="94" r="3" fill="#fff" stroke="#2b1b3d" stroke-width="1.5"/>';
  if(e===2)ex=[16,24,32,40,48,54].map((x,i)=>`<circle cx="${x}" cy="${61+Math.sin(i)*3}" r="1.9" fill="${['#ffcf5c','#e5484d','#6ec6ff'][i%3]}"/>`).join('');
  return `<svg viewBox="0 0 70 100" aria-hidden="true" class="${small?'pmini':'pbig'}"><g stroke="#2b1b3d" stroke-width="3" stroke-linejoin="round"><circle cx="35" cy="38" r="15" fill="#fff"/><circle cx="35" cy="72" r="23" fill="${col}"/><path d="M22 54q13 6 26 0" fill="none" stroke="#fff" stroke-width="3"/><circle cx="30" cy="35" r="2" fill="#2b1b3d" stroke="none"/><circle cx="40" cy="35" r="2" fill="#2b1b3d" stroke="none"/><path d="M35 40l11 3-11 3z" fill="#ff8a3d"/></g>${mot}${ex}</svg>`;
}
function pullBlock(){
  const w=el('div','pullbox');w.appendChild(txt('h3','','L\'atelier du pull moche'));
  w.appendChild(txt('p','note','Tricote le pull le plus moche possible pour le bonhomme de neige. Tous les pulls de la Table s\'affichent ici, puis on vote pour le pire. Juste en dessous.'));
  let code=store.get('ate_pull',null)||'0-0-0';const [c0,m0,e0]=code.split('-').map(Number);const st={c:c0,m:m0,e:e0};
  const prev=el('div','pprev');const paint=()=>{code=`${st.c}-${st.m}-${st.e}`;prev.innerHTML=pullSVG(code);};paint();
  const row=(label,arr,key,isCol)=>{const r=el('div','prow');r.appendChild(txt('span','plab',label));arr.forEach((v,i)=>{const b=txt('button','popt'+(st[key]===i?' on':''),isCol?'':v);b.type='button';if(isCol){b.style.background=v;b.setAttribute('aria-label','Couleur '+(i+1));}
    b.addEventListener('click',()=>{st[key]=i;[...r.querySelectorAll('.popt')].forEach((x,j)=>x.classList.toggle('on',j===i));paint();});r.appendChild(b);});return r;};
  const ctl=el('div','pctl');ctl.appendChild(row('Couleur',PULL_COLS,'c',true));ctl.appendChild(row('Motif',PULL_MOTIFS,'m'));ctl.appendChild(row('Finition',PULL_EXTRAS,'e'));
  const top=el('div','ptop');top.appendChild(prev);top.appendChild(ctl);w.appendChild(top);
  const send=txt('button','btn',store.get('ate_pull',null)?'Mettre à jour mon pull':'Envoyer mon pull');send.type='button';
  send.addEventListener('click',async()=>{if(!me){askWho(true);return;}send.disabled=true;await sendVote(me,'pull',code);store.set('ate_pull',code);Game.toy('pull');send.disabled=false;send.textContent='✓ Pull envoyé';send.classList.add('done');toast('Ton pull est parti à la Table. Il est magnifiquement affreux.');});
  w.appendChild(send);
  const gal=el('div','pgal');gal.appendChild(txt('p','note','Chargement des pulls de la Table…'));w.appendChild(gal);
  getAllRows().then(all=>{gal.innerHTML='';const ps=all?dedupe(all.filter(r=>r.day==='pull')):[];
    const mineLocal=store.get('ate_pull',null);if(me&&mineLocal&&!ps.some(p=>p.name===me))ps.push({name:me,answer:mineLocal});
    if(!ps.length){gal.appendChild(txt('p','note','Aucun pull pour l\'instant. Lance la mode !'));return;}
    ps.forEach(p=>{const f=el('figure','pfig');f.innerHTML=pullSVG(p.answer,true);f.appendChild(txt('figcaption','',p.name));gal.appendChild(f);});});
  return w;
}
/* le bonhomme se souvient */
function memoryLine(){
  const last=store.get('ate_lastday',0);const cur=Game.streakNow();let msg=null;
  if(todayNum>=1&&last&&todayNum-last>=3)msg=pick(['Ah, te revoilà ! On a gardé ta place.','Tiens, un revenant ! La Table a cru que tu hibernais.','Te revoilà ! Le rouge-gorge demandait de tes nouvelles.'])+` ${todayNum-last} jours sans toi, c'est long pour un bonhomme de neige.`;
  else if([5,10,15,20,25].includes(cur)&&last!==todayNum)msg=cur+' jours de suite. Tu habites ici maintenant ?';
  if(todayNum>=1)store.set('ate_lastday',todayNum);
  return msg;
}
function setupSocial(){
  renderSocks();
  const mem=memoryLine();
  if(mem)setTimeout(()=>{const h=$('.egg.snowman');if(h)bubble(h,$('.ground'),mem);},2200);
  getAllRows().then(all=>{if(!all)return;SOCK_ROWS=all;renderSocks();crownAndLast(all);});
}

/* ---------- taquineries, uwu, cadeaux maudits, tigre, devin des régions ---------- */
const TDECK={};
const TIGRE_DAY=11; // case « Tié un tigre » : à choisir
const GIFT_DAY=7;   // cadeaux maudits : tirage et vote de la date
function nextT(pool,key){return nextFrom(TDECK,pool,key);}
const TAUNTS_COQUIN=[
 `Je ne m'ouvre pas au premier venu.`,
 `Ça fait trois fois que tu tripotes ma serrure… On se connaît ?`,
 `Les meilleures choses se déballent lentement.`,
 `Tu insistes ? C'est flatteur. Mais c'est non.`,
 `Un peu de tenue, on est dans un calendrier de l'Avent.`,
 `Pas de ça avant le jour J. J'ai des principes.`,
 `Doucement avec mon verrou, il est sensible.`,
 `Tu me fais de l'œil depuis tout à l'heure. Je rougis, mais je reste fermée.`,
 `Si tu me caresses encore la porte, je préviens le bonhomme de neige.`,
 `On ne déshabille pas une case comme ça.`,
 `J'aime qu'on me désire. Reviens à mon jour.`,
 `Tu veux voir ce que je cache ? Toi alors…`,
 `Même avec un clin d'œil, ça ne marche pas.`,
 `Tu as les mains froides. Et la case reste fermée.`,
 `Je suis une case sérieuse. Enfin, à partir de mon jour.`
];
const PINE_COQUIN=[
 `Doucement… je suis chatouilleux des aiguilles.`,
 `On se connaît à peine et tu me décores déjà ?`,
 `Tu me secoues comme ça, devant le bonhomme de neige ?`,
 `Encore ? Tu y prends goût, on dirait.`,
 `Attention à mes boules, elles sont fragiles. Et moi aussi.`,
 `Tu sais que je n'ai rien sous mes branches, hein ?`,
 `Si tu continues, je vais perdre mes aiguilles. Et ma dignité.`,
 `Mmh, plus à gauche. Non, je plaisante. Arrête.`,
 `Un sapin a besoin de tendresse, pas de tripotage.`,
 `Tu fais ça à tous les sapins ?`,
 `Je suis un sapin bien élevé. Toi, je ne sais pas.`,
 `On m'a enguirlandé pour moins que ça.`,
 `Je frissonne. C'est l'hiver, ou c'est toi ?`,
 `Range tes mains, il y a des enfants. Enfin, la Table des Enfants.`,
 `Mon tronc n'est pas une barre de pole dance.`
];
const KAO_SHY=['>///<','(˶ᵔ ᵕ ᵔ˶)','uwu','owo','(⁄ ⁄•⁄ω⁄•⁄ ⁄)'];
const KAO_SULK=['(｡•́︿•̀｡)','(>_<)','(ಥ﹏ಥ)','(ーー;)','(╥_╥)'];
function kaoTile(b){
  let k=b.querySelector('.kao');if(!k){k=el('span','kao');b.appendChild(k);}
  k.textContent=pick(KAO_SULK);k.classList.remove('show');void k.offsetWidth;k.classList.add('show');
  clearTimeout(k._t);k._t=setTimeout(()=>k.classList.remove('show'),2600);
}
/* mode uwu secret : taper « uwu », ou toucher 5 fois la lune */
let uwuT=null;
function uwuMode(){
  document.body.classList.add('uwu');toast('Mode uwu activé (˶ᵔ ᵕ ᵔ˶) Tout le chalet rougit pendant 30 secondes.');
  Music.arp([84,88,91,96,91,88]);if(!Game.flag('uwu'))Game.flag('uwu',1);
  const h=$('.egg.snowman');if(h)setTimeout(()=>bubble(h,$('.ground'),'uwu… tu m\'as eu.'),600);
  clearTimeout(uwuT);uwuT=setTimeout(()=>document.body.classList.remove('uwu'),30000);
}
const TIGRE_REP=['Merci ! Tié un lynx.','Non, c\'est toi le tigre.','Tié un iguane, toi. Un vrai.','Arrête, je vais fondre de gêne.','Tié un hippopotame. C\'est un compliment, je te jure.','Tché un ovni. Voilà, c\'est dit.'];
function tigreSays(){const h=$('.egg.snowman');const r=pick(TIGRE_REP);if(h)bubble(h,$('.ground'),r);Game.toy('tigre');return r;}
function setupSecrets(){
  let buf='';
  document.addEventListener('keydown',e=>{
    if(e.target&&/INPUT|TEXTAREA|SELECT/.test(e.target.tagName))return;
    if(e.key.length!==1)return;buf=(buf+e.key.toLowerCase()).replace(/[^a-zé]/g,'').slice(-12);
    if(buf.endsWith('uwu')){buf='';uwuMode();}
    else if(/ti[ée]untigre$|tesuntigre$/.test(buf)){buf='';tigreSays();}
  });
  const moon=$('.moon');if(moon){let n=0,t0=0;moon.addEventListener('click',()=>{const now=Date.now();if(now-t0>4000)n=0;t0=now;n++;if(n>=5){n=0;uwuMode();}});}
}
/* case 8 : dire « tié un tigre » au bonhomme */
function tigreBlock(){
  const w=el('div','tigrebox');w.appendChild(txt('h3','','À toi de jouer'));
  w.appendChild(txt('p','note','Dis « tié un tigre » au bonhomme de neige. (Ou tape-le au clavier, n\'importe où sur la page.)'));
  const b=txt('button','btn','Tié un tigre !');b.type='button';const out=txt('p','tigreout','');
  b.addEventListener('click',()=>{out.textContent='Le bonhomme : « '+pick(TIGRE_REP)+' »';const r=b.getBoundingClientRect();sparkle(r.left+r.width/2,r.top,12,'#f2a900');Music.arp([67,71,74,79]);Game.toy('tigre');});
  w.appendChild(b);w.appendChild(out);return w;
}
/* case 14 : les cadeaux maudits, tirage secret */
function seeded(str){let h=1779033703^str.length;for(let i=0;i<str.length;i++){h=Math.imul(h^str.charCodeAt(i),3432918353);h=h<<13|h>>>19;}
  return()=>{h=Math.imul(h^h>>>16,2246822507);h=Math.imul(h^h>>>13,3266489909);h^=h>>>16;return(h>>>0)/4294967296;};}
function giftDraw(){const r=seeded('cadeaux-maudits-table-2026');const a=MEMBERS.slice();
  for(let i=a.length-1;i>0;i--){const j=Math.floor(r()*i);[a[i],a[j]]=[a[j],a[i]];} // Sattolo : un seul cycle, personne ne se tire soi-même
  const m={};MEMBERS.forEach((n,i)=>m[n]=a[i]);return m;}
function giftBlock(){
  const w=el('div','giftbox');w.appendChild(txt('h3','','Les cadeaux maudits de la Table'));
  w.appendChild(el('div','body',`<p>Chacun offre un <strong>cadeau maudit</strong> à un membre de la Table : drôle, inutile, ou un peu inquiétant. Budget conseillé : 10 €. On ouvre tout en même temps, et on devine qui a offert quoi.</p><p>La date se vote juste en dessous : 17 ou 22 décembre. Tu as donc quelques jours pour trouver la pire idée possible.</p>`));
  const b=txt('button','btn','Découvrir à qui j\'offre');b.type='button';const out=el('div','giftout');
  b.addEventListener('click',()=>{if(!me){askWho(true);return;}const to=giftDraw()[me];
    out.innerHTML='';out.appendChild(txt('p','',`Tu offres un cadeau maudit à…`));const n=txt('p','giftname',to);out.appendChild(n);
    out.appendChild(txt('p','note small','Chut. Ne regarde pas le tirage des autres en changeant de prénom : c\'est de la triche, et le bonhomme le saura.'));
    const r=b.getBoundingClientRect();sparkle(r.left+r.width/2,r.top,16,'#c58bff');Music.arp([60,63,67,72]);Game.toy('maudit');});
  w.appendChild(b);w.appendChild(out);return w;
}
/* case 21 : le bonhomme devin des régions (façon Akinator) */
const REGIONS={no:'le Nord',idf:'l\'Île-de-France',est:'l\'Est, du côté de l\'Alsace',ly:'Lyon',ma:'Marseille',so:'le Sud-Ouest',ou:'l\'Ouest',bs:'la Belgique ou la Suisse'};
const REG_PUNCH={no:'Il drache, hein ?',idf:'Un grec, une Tipp-Ex et au lit.',est:'Un schmoutz et un döner, et au lit.',ly:'Salut les gones !',ma:'Et ça, dégun ne le savait.',so:'Chocolatine, évidemment.',ou:'Tu débauches à quelle heure ?',bs:'Septante, nonante… et la vogue !'};
const DEVIN_Q=[
 {q:'Un sac en plastique, au supermarché, c\'est…',o:[{t:'un sac',n:['so','ou']},{t:'une poche',r:['so']},{t:'un pochon',r:['ou']}]},
 {q:'Le petit pot blanc pour corriger tes fautes, c\'est…',o:[{t:'du Tipp-Ex',r:['idf']},{t:'du blanc',r:['est']},{t:'du blanco',r:['ou']},{t:'du correcteur',n:[]}]},
 {q:'Le sandwich de fin de soirée, c\'est…',o:[{t:'un grec',r:['idf']},{t:'un kebab',n:['idf','est']},{t:'un döner',r:['est']}]},
 {q:'La fête foraine, c\'est…',o:[{t:'la fête foraine',n:['no','ly','bs']},{t:'la vogue',r:['ly','bs']},{t:'la ducasse',r:['no']},{t:'la fête votive',r:['ma','so']}]},
 {q:'Ta viennoiserie du matin, c\'est…',o:[{t:'un pain au chocolat',n:['so']},{t:'une chocolatine',r:['so']}]},
 {q:'Après quatre-vingt-neuf, tu dis…',o:[{t:'quatre-vingt-dix',n:['bs']},{t:'nonante',r:['bs']}]},
 {q:'« Personne n\'est venu », chez toi, ça se dit…',o:[{t:'personne n\'est venu',n:['ma']},{t:'dégun est venu',r:['ma']}]},
 {q:'Un enfant, c\'est…',o:[{t:'un gamin',n:['ly','ma','ou']},{t:'un gone',r:['ly']},{t:'un minot',r:['ma']},{t:'un drôle',r:['ou']}]},
 {q:'Il pleut très fort : …',o:[{t:'il pleut des cordes',n:['no']},{t:'il drache',r:['no','bs']}]},
 {q:'Finir sa journée de travail, c\'est…',o:[{t:'finir le boulot',n:['ou']},{t:'débaucher',r:['ou']}]},
 {q:'C\'est très bon : …',o:[{t:'c\'est trop bon',n:['ma','so']},{t:'c\'est tarpin bon',r:['ma']},{t:'c\'est gavé bon',r:['so']}]},
 {q:'Un pain aux raisins, c\'est…',o:[{t:'un pain aux raisins',n:['est']},{t:'un escargot',r:['est']}]}
];
function devinBlock(){
  const w=el('div','devin');
  const face=el('div','devface');face.innerHTML='<svg viewBox="0 0 70 70" aria-hidden="true"><g stroke="#2b1b3d" stroke-width="3" stroke-linejoin="round"><circle cx="35" cy="42" r="20" fill="#fff"/><path d="M15 34q-1-20 20-21 21 1 20 21-20-8-40 0z" fill="#8e5bd6"/><circle cx="35" cy="22" r="4" fill="#ffcf5c"/><circle cx="28" cy="40" r="2.6" fill="#2b1b3d" stroke="none"/><circle cx="42" cy="40" r="2.6" fill="#2b1b3d" stroke="none"/><path d="M35 45l11 3-11 3z" fill="#ff8a3d"/></g></svg>';
  const say=txt('p','devsay','Je suis le grand bonhomme devin. Réponds comme tu parles vraiment, et je devine d\'où tu viens.');
  const meter=el('div','devmeter');const mf=el('span','');meter.appendChild(mf);
  const area=el('div','devarea');
  const head=el('div','devhead');head.appendChild(face);head.appendChild(say);
  w.appendChild(txt('h3','','Le bonhomme devin'));w.appendChild(head);w.appendChild(meter);w.appendChild(area);
  let P,asked,guessed,qn;
  const keys=Object.keys(REGIONS);
  const norm=()=>{const s=keys.reduce((a,k)=>a+P[k],0);keys.forEach(k=>P[k]/=s);};
  const best=()=>keys.slice().sort((a,b)=>P[b]-P[a]);
  function lik(o,k){if(o.r&&o.r.includes(k))return 5;if(o.r)return .45;if(o.n&&o.n.includes(k))return .3;return 1;}
  function gain(q){ // question qui sépare le mieux les régions encore probables
    let g=0;q.o.forEach(o=>{let pm=0;keys.forEach(k=>pm+=P[k]*lik(o,k));keys.forEach(k=>{const v=P[k]*lik(o,k)/pm;g-=pm*(v>0?v*Math.log(v):0);});});return -g;}
  function start(){P={};keys.forEach(k=>P[k]=1/keys.length);asked=new Set();guessed=new Set();qn=0;next();}
  function think(cb){say.textContent=pick(['Hmm…','Je sens quelque chose…','Les vibrations régionales sont fortes…','Laisse-moi réfléchir…','Intéressant…']);face.classList.add('think');setTimeout(()=>{face.classList.remove('think');cb();},RM()?100:650);}
  function setMeter(){const b=best()[0];mf.style.width=Math.round(P[b]*100)+'%';meter.setAttribute('aria-label','Certitude du devin : '+Math.round(P[b]*100)+' %');}
  function next(){
    setMeter();const b=best()[0];
    if((qn>=4&&P[b]>.72&&!guessed.has(b))||qn>=9||asked.size>=DEVIN_Q.length)return guess();
    const left=DEVIN_Q.filter((q,i)=>!asked.has(i));const sc=left.map(q=>[q,gain(q)]).sort((a,b)=>a[1]-b[1]);
    const q=sc[0][0];const qi=DEVIN_Q.indexOf(q);asked.add(qi);qn++;
    say.textContent=`Question ${qn}. ${q.q}`;area.innerHTML='';
    const opts=el('div','opts');q.o.forEach(o=>{const bt=txt('button','opt',o.t);bt.type='button';bt.addEventListener('click',()=>{keys.forEach(k=>P[k]*=lik(o,k));norm();think(next);});opts.appendChild(bt);});
    const dk=txt('button','btn ghost','Je ne sais pas');dk.type='button';dk.addEventListener('click',()=>think(next));
    area.appendChild(opts);area.appendChild(dk);
  }
  function guess(){
    const b=best().find(k=>!guessed.has(k));if(!b)return lost();guessed.add(b);setMeter();
    say.textContent=`Je pense que tu viens de… ${REGIONS[b]} !`;area.innerHTML='';face.classList.add('ta');setTimeout(()=>face.classList.remove('ta'),900);
    const opts=el('div','opts');const y=txt('button','opt','Oui, bien vu !');y.type='button';const n=txt('button','opt','Non, raté');n.type='button';
    y.addEventListener('click',()=>{say.textContent=`Évidemment. ${REG_PUNCH[b]} Le grand bonhomme ne se trompe jamais (ou presque).`;area.innerHTML='';const r=w.getBoundingClientRect();sparkle(r.left+r.width/2,r.top+40,18,'#c58bff');confetti();Game.toy('devin');again();});
    n.addEventListener('click',()=>{P[b]=0.0001;norm();if(guessed.size>=2||qn>=9)return lost();say.textContent='Raté ? Impossible. Encore quelques questions.';setTimeout(next,900);});
    opts.appendChild(y);opts.appendChild(n);area.appendChild(opts);
  }
  function lost(){
    say.textContent='Tu m\'as eu. Je retire mon turban. Tu viens d\'où, alors ?';area.innerHTML='';
    const opts=el('div','opts');keys.concat(['ailleurs']).forEach(k=>{const bt=txt('button','opt',k==='ailleurs'?'Ailleurs':REGIONS[k].replace(/^l'|^le |^la /,'').replace(/^./,c=>c.toUpperCase()));bt.type='button';
      bt.addEventListener('click',()=>{say.textContent=k==='ailleurs'?'Ailleurs ! Je ne pouvais pas deviner. Je garde ma dignité.':`${REGIONS[k].replace(/^./,c=>c.toUpperCase())} ! Je note. La prochaine fois, je t'aurai.`;area.innerHTML='';Game.flag('devinko',1);again();});opts.appendChild(bt);});
    area.appendChild(opts);
  }
  function again(){const r=txt('button','btn ghost','Rejouer');r.type='button';r.addEventListener('click',start);area.appendChild(r);}
  const go=txt('button','btn','Je suis prêt·e');go.type='button';go.addEventListener('click',start);area.appendChild(go);
  return w;
}

(async function init(){
  snow();setupMusic();setupEggs();setupSide();setupToys();
  todayNum=await resolveToday();
  renderGrid();renderStatus();
  setupAmbiance();
  if(cheated){toast(pick(CHEAT),true);Game.setCheat();}
  setupFocus();
  if(me&&PINS_ON()&&store.get('ate_pinok',null)!==me){me=null;store.set('ate_me',null);renderStatus();}
  Game.init();
  if(me)Game.syncFromSheet(true);
  setupSocial();
  setupSecrets();
  if(!me)askWho(false);else if(!store.get('ate_welcome',0))showWelcome();
})();
