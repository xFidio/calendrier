const MEMBERS=['Marine','Florian S','Florian R','Orane','Claire','Jules','Mathilde','Kevin'];

const TYPES={
  histoire:{label:'Histoire dingue',mini:'histoire'},
  apprends:{label:'Apprends un truc',mini:'apprends'},
  test:{label:'Test sur la table',mini:'test'},
  site:{label:'Site de la nuit',mini:'site'},
  univers:{label:'Case Univers',mini:'univers'},
  finale:{label:'Grande finale',mini:'finale'}
};

const DAYS=[
{d:1,type:'histoire',noel:true,
 title:`Qui a eu l'idée de ce truc ?`,
 body:`<p>Tu tiens un calendrier de l'Avent. Mais qui a eu l'idée de compter les jours avant Noël ? Au XIX<sup>e</sup> siècle, des familles protestantes allemandes marquaient chaque jour de décembre à la craie sur une porte, ou allumaient une bougie par jour.</p>
 <p>Le premier calendrier imprimé est souvent attribué à <strong>Gerhard Lang</strong>, un imprimeur allemand, au début du XXe siècle (autour de 1908 selon les sources). Les versions au chocolat arrivent bien plus tard, vers les années 1950.</p>
 <p class="tip">Règle d'or de la maison : une case par jour. Pas deux. On te regarde.</p>`,
 links:[[`24matins : l'origine du calendrier de l'Avent`,`https://www.24matins.fr/lorigine-du-calendrier-de-lavent-pourquoi-ouvre-t-on-des-cases-avant-noel-1384212`],[`Wikipédia : calendrier de l'Avent`,`https://fr.wikipedia.org/wiki/Calendrier_de_l'Avent`],[`Aleteia : d'où viennent les calendriers de l'Avent`,`https://aleteia.org/2017/12/07/where-did-advent-calendars-originate`],[`NPR : l'histoire des calendriers de l'Avent`,`https://www.npr.org/2022/12/11/1141855237/advent-calendar-history-evolution`]],
 qs:[{id:'1',kind:'who',text:`Qui ouvrira une case en avance ?`,award:`Tricheur·se de l'Avent`}]},

{d:2,type:'univers',noel:false,
 title:`Le bourdonnement le plus célèbre de la galaxie`,
 body:`<p>Le « vvvmmmm » des sabres laser de <em>Star Wars</em> n'a rien d'électronique. Il a été fabriqué par Ben Burtt, l'ingénieur du son de la saga, à partir de bruits du quotidien. D'abord le <strong>ronronnement des moteurs de vieux projecteurs de cinéma</strong>, qu'il avait remarqué quand il était projectionniste à l'université. Ensuite un bourdonnement capté par accident : son micro, passé près d'un <strong>téléviseur allumé</strong>, a enregistré le grésillement du tube.</p>
 <p>Mélangés, les deux sons donnent la note de base. Pour l'effet de mouvement, Burtt a diffusé ce mélange dans un haut-parleur et agité un second micro devant, en le rapprochant et en l'éloignant : le son « fouette » l'air comme une lame. Pas de synthétiseur, juste un projecteur, une télé et un micro qu'on balance.</p>`,
 links:[[`Ciné-Séries : comment le son du sabre laser a-t-il été créé ?`,`https://www.cineserie.com/news/cinema/star-wars-comment-le-son-du-sabre-laser-a-t-il-ete-cree-4738401/`],[`Brut : le son du sabre laser (vidéo)`,`https://www.brut.media/fr/videos/le-son-du-sabre-laser`],[`Looper : How Star Wars created the lightsaber sound effect`,`https://www.looper.com/1503665/star-wars-how-lightsaber-sound-effect-created`]],
 qs:[{id:'2',kind:'who',text:`Qui ferait le meilleur bruiteur ou la meilleure bruiteuse de la Table ?`,award:`Micro d'or`}]},

{d:3,type:'histoire',noel:false,
 title:`Le cadavre qui a trompé l'armée allemande`,
 body:`<p>Printemps 1943. Les Alliés veulent débarquer en Sicile, mais les Allemands s'attendent à une attaque ailleurs. Les services secrets britanniques montent l'<strong>opération Mincemeat</strong> : ils habillent un cadavre en officier britannique, sous une fausse identité, muni de faux documents suggérant un débarquement en Grèce ou en Sardaigne, et le laissent dériver au large de l'Espagne.</p>
 <p>Le corps est retrouvé, les papiers parviennent aux Allemands. Le cadavre était en fait celui d'un Gallois, Glyndwr Michael, mort d'intoxication, dont l'identité n'a été révélée qu'en 1996. Les historiens débattent encore de l'ampleur exacte de la tromperie, mais l'opération reste un cas d'école de désinformation.</p>`,
 links:[[`Wikipédia : opération Mincemeat`,`https://fr.wikipedia.org/wiki/Opération_Mincemeat`],[`History of War : Operation Mincemeat`,`https://www.historyofwar.org/articles/operation_mincemeat.html`],[`Wikipédia (en anglais) : l'officier fictif de l'opération`,`https://en.wikipedia.org/wiki/William_Martin_(Royal_Marines_officer)`]],
 qs:[{id:'3',kind:'who',text:`Qui est le meilleur menteur de la table ?`,award:`Menteur·se en chef`}]},

{d:4,type:'site',noel:false,
 title:`Ta fenêtre sur le monde`,
 body:`<p><strong>WindowSwap</strong> est un site où des inconnus partagent la vue depuis leur fenêtre : un balcon quelque part en Asie, une forêt sous la neige, un port dans la brume. Tu cliques, tu changes de fenêtre. Pas de commentaire, juste la vue et les bruits autour.</p>
 <p>Né pendant le confinement, quand voyager n'était plus possible. À mettre en fond sur un chocolat chaud, pour passer cinq minutes ailleurs.</p>`,
 links:[[`L'ADN : un site apaisant pour voyager sans bouger`,`https://www.ladn.eu/mondes-creatifs/confinement-site-apaisant-voyager-bout-du-monde/`],[`WindowSwap`,`https://www.window-swap.com`],[`Wikipédia : WindowSwap`,`https://en.wikipedia.org/wiki/WindowSwap`]],
 qs:[{id:'4',kind:'choice',text:`Quelle fenêtre pour passer Noël ?`,options:[`Chalet enneigé`,`Plage australe (30° à Noël)`,`Gratte-ciel de Tokyo`,`Village de montagne`,`Mon canapé, point.`]}]},

{d:5,type:'test',noel:false,
 title:`Le chifoumi de la Table`,
 body:`<p>Pierre, feuille, ciseaux. Le jeu le plus simple du monde, et pourtant personne n'aime perdre à table.</p>
 <ol><li>Tirez les huit prénoms au sort pour former un tableau : quarts de finale, demi-finales, finale.</li><li>Chaque duel se joue au meilleur des trois manches.</li><li>Le perdant de la finale offre le prochain chocolat chaud.</li></ol>`,
 links:[],
 qs:[{id:'5',kind:'who',text:`Qui gagnerait le tournoi de chifoumi de la Table ?`,award:`Main d'or`}]},

{d:6,type:'histoire',noel:true,
 title:`Saint Nicolas, ses os et le casse de 1087`,
 body:`<p>Le 6 décembre, on fête saint Nicolas, évêque de Myre (aujourd'hui en Turquie) au IV<sup>e</sup> siècle. En 1087, selon la tradition, des marins d'une ville portuaire d'Italie du Sud débarquent à Myre, entrent dans l'église et repartent avec ses reliques. Un casse religieux, assumé : ils jugeaient que leur ville méritait mieux.</p>
 <p>Elles reposent depuis là-bas, dans une basilique construite pour l'occasion. Venise revendique aussi une partie des ossements.</p>
 <p>Côté folklore français : en Lorraine, saint Nicolas est accompagné du <strong>Père Fouettard</strong>, chargé de punir les enfants pas sages.</p>
 <p class="tip">Les résultats de chaque question sont dévoilés le lendemain : va voir ceux de la case 5.</p>`,
 links:[[`Finestre sull'Arte : le culte de saint Nicolas à Bari`,`https://finestresullarte.info/fr/carnets-de-voyage/1067v_le-culte-de-saint-nicolas-dans-l-art-a-bari-et-dans-les-pouilles.php`],[`St. Nicholas Center : les marins de Bari, 1087`,`https://www.stnicholascenter.org/who-is-st-nicholas/saint-in-bari/bari-sailors-1087`]],
 qs:[{id:'6',kind:'who',text:`Qui est le Père Fouettard de la table ?`,award:`Père/Mère Fouettard`}]},

{d:7,type:'histoire',noel:true,
 title:`La bûche qui fait des cadeaux (à sa façon)`,
 body:`<p>En Catalogne, la tradition veut qu'une bûche à visage, le <strong>Caga Tió</strong>, soit « nourrie » par les enfants à partir du 8 décembre et couverte d'une couverture pour qu'elle n'ait pas froid. Le 24 au soir, on la frappe à coups de bâton en chantant pour qu'elle « fasse » des cadeaux : bonbons, nougats, petites surprises glissés sous la couverture.</p>
 <p>Autre personnage de la crèche catalane : le <strong>caganer</strong>, un petit personnage accroupi, culotte baissée, en train de faire ses besoins. Il se cache dans le décor, et le trouver porte chance. Il en existe des versions de célébrités.</p>`,
 links:[[`Equinox : le Caga Tió, la bûche qui fait des cadeaux`,`https://www.equinoxmagazine.fr/2021/12/22/la-tradition-catalane-du-caga-tio-la-buche-qui-fait-caca-des-cadeaux/`],[`Equinox : les traditions de Noël catalanes (dont le caganer)`,`https://www.equinoxmagazine.fr/2024/12/23/5-traditions-de-noel-catalogne/`],[`Barcelone : traditions de Noël`,`https://www.barcelona.cat/nadal/en/traditions/christmas-traditions`]],
 qs:[{id:'7',kind:'choice',text:`Un caganer dans la crèche : ton avis ?`,options:[`Génial`,`Sacrilège`,`Je veux le mien tout de suite`]},{id:'7b',kind:'choice',text:`Les cadeaux maudits, on se les échange quand ?`,options:[`Jeudi 17 décembre`,`Mardi 22 décembre`,`Peu importe, tant qu'il y a du chocolat chaud`]}]},

{d:8,type:'apprends',noel:false,
 title:`Orion, le panneau indicateur du ciel d'hiver`,
 body:`<p>Ce soir, si le ciel est dégagé, regarde vers le sud-est en début de soirée (plein sud vers minuit) et cherche <strong>trois étoiles alignées</strong>, serrées et brillantes : la ceinture d'Orion.</p>
 <ul><li>Au-dessus à gauche : <strong>Bételgeuse</strong>.</li><li>En dessous à droite : <strong>Rigel</strong>.</li><li>En prolongeant la ligne de la ceinture vers le bas à gauche, tu tombes sur <strong>Sirius</strong>, l'étoile la plus brillante du ciel nocturne.</li></ul>
 <p>Pas de télescope, pas de jumelles, pas d'horoscope. Trente secondes dehors, avec un bonnet.</p>`,
 links:[[`Stelvision : randonnée céleste dans les pas d'Orion`,`https://www.stelvision.com/guide-observation/randonnee-celeste-dans-les-pas-du-chasseur-orion/`],[`timeanddate : comment repérer Orion`,`https://www.timeanddate.com/news/astronomy/how-to-spot-orion`],[`Stellarium Web (planétarium en ligne)`,`https://stellarium-web.org`]],
 qs:[{id:'8',kind:'choice',text:`Quelle planète te ressemble le plus ?`,options:[`Mercure (toujours pressée)`,`Vénus (jour plus long que l'année)`,`Mars (rouge de colère)`,`Jupiter (en grand)`,`Saturne (avec des anneaux)`,`Neptune (froid et lointain)`]}]},

{d:9,type:'apprends',noel:true,
 title:`Le déluge de livres islandais`,
 body:`<p>En Islande, la veille de Noël, on s'offre des <strong>livres</strong>, et on passe la soirée à lire, souvent avec du chocolat. Ça s'appelle le <em>Jólabókaflóð</em>, « le déluge de livres de Noël ».</p>
 <p>La tradition est souvent rattachée à la guerre : pourquoi des livres, justement ? (réponse dans le mini-jeu). Chaque année, un catalogue de toutes les nouveautés est distribué dans les foyers du pays.</p>
 <p class="tip">Idée à voler pour le 24 : un livre par personne, et tout le monde lit en silence jusqu'à ce que quelqu'un craque.</p>`,
 links:[[`Icelandair : le Jólabókaflóð, déluge de livres de Noël`,`https://www.icelandair.com/fr-fr/blog/jolabokaflod/`],[`Icelandic Literature Center : le déluge de livres`,`https://www.islit.is/en/news/the-christmas-book-flood-a-beloved-icelandic-tradition`]],
 qs:[{id:'9',kind:'choice',text:`Quel livre offrirais-tu à la Table le 24 au soir ?`,options:[`Un roman policier`,`Une BD`,`Un livre de cuisine`,`Un manga`,`Un livre de jeux de rôle`]}]},

{d:10,type:'univers',noel:false,
 title:`Avant les consoles, des cartes à jouer`,
 body:`<p>Nintendo n'a pas toujours fabriqué des consoles. L'entreprise est fondée à <strong>Kyoto</strong> par Fusajiro Yamauchi, pour produire des cartes à jouer traditionnelles japonaises, les <em>hanafuda</em> (« cartes de fleurs »). Elle en fabrique d'ailleurs encore aujourd'hui.</p>
 <p>Bien plus tard, la même maison a vendu Mario, Zelda et Pokémon. Entre-temps elle a tenté le riz en portions, les taxis et les « love hotels » (ça n'a pas toujours marché).</p>
 <p class="tip">Site bonus : <strong>The Cutting Room Floor</strong> répertorie tout ce qui a été supprimé ou caché dans des jeux vidéo : niveaux jamais utilisés, textes coupés, dialogues d'avant-vente. Bon trou de lapin.</p>`,
 links:[[`Wikipédia : Nintendo`,`https://fr.wikipedia.org/wiki/Nintendo`],[`MoneyWeek : 23 septembre 1889, Nintendo fabrique des cartes`,`https://moneyweek.com/349214/23-september-1889-nintendo-starts-making-playing-cards`],[`The Cutting Room Floor`,`https://www.tcrf.net`]],
 qs:[{id:'10',kind:'who',text:`Qui est le Ronflex de la table ?`,award:`Ronflex officiel`}]},

{d:11,type:'univers',noel:false,
 title:`« Tié un tigre » : le merci qui rugit`,
 body:`<p>À Marseille, quand quelqu'un te rend service, on ne dit plus forcément merci : on lui dit qu'il est un <strong>tigre</strong>. Avec l'accent, ça donne « tié un tigre ». Traduction : « merci, t'es au top ».</p>
 <p>L'expression circule sur Twitter et TikTok depuis au moins le printemps 2024, et elle a fait des petits : « tié un lynx », « tié un iguane », « tie un hippopotame », et même « tché un ovni ». Dans le Nord, on dira plutôt « t'es un loup ». En mai 2026, Jul lui a même consacré un titre, <em>Tié un tigre</em>.</p>
 <p>D'où ça vient exactement ? Personne ne sait qui l'a dit en premier. Mais tout Marseille l'a répété, et maintenant, toi aussi.</p>`,
 links:[[`Twog : « Tié un tigre », ces expressions pour dire merci dans le Sud`,`https://twog.fr/tie-un-tigre-ces-expressions-pour-dire-merci-dans-le-sud/`],[`Apple Music : Jul, « Tié un tigre » (2026)`,`https://music.apple.com/fr/song/ti%C3%A9-un-tigre/6767266132`]],
 qs:[{id:'11',kind:'who',text:`Qui est le plus tigre de la Table ?`,award:`Tigre de la Table`}]},

{d:12,type:'univers',noel:false,
 title:`Ce que cache la pluie verte de Matrix`,
 body:`<p>La célèbre pluie de caractères verts de <em>Matrix</em> (1999) n'a pas été imaginée par des informaticiens. Selon Simon Whiteley, le chef décorateur du film, ce sont des caractères tirés de <strong>livres de recettes japonaises</strong> appartenant à sa femme, scannés puis retravaillés numériquement pour créer cet effet de « douche de code ».</p>
 <p>Chaque fois que Neo regarde un mur de lettres vertes, il lit donc, sans le savoir, quelque chose comme une recette de sushi.</p>`,
 links:[[`Paris Match Belgique : le secret le mieux caché de Matrix`,`https://www.parismatch.be/culture/cinema/2017/10/27/le-secret-le-mieux-cache-de-matrix-a-un-gout-dumami-6XNKSM2LTJA2NFVJYWBIFHTPHE/`],[`Food.com : the opening of The Matrix`,`https://www.food.com/article/sushi-matrix-450`]],
 qs:[{id:'12',kind:'choice',text:`Pilule rouge ou pilule bleue, à la Table ?`,options:[`Rouge : je veux savoir`,`Bleue : je reste dans mon canapé`,`Ni l'une ni l'autre, je prends un chocolat chaud`]}]},

{d:13,type:'test',noel:false,
 title:`Dessine un vélo de mémoire`,
 body:`<p>Chaque membre de la table prend une feuille et un stylo, <strong>sans téléphone</strong>, et dessine un vélo de mémoire en deux minutes. Puis vous comparez avec un vrai vélo (ou une photo).</p>
 <p>Résultat attendu : des chaînes qui ne relient rien, des cadres impossibles, des pédales flottantes. Des chercheurs ont montré que même des gens qui font du vélo régulièrement dessinent souvent un vélo qui ne pourrait pas rouler.</p>`,
 links:[[`The Science of Cycology (université de Liverpool)`,`https://www.liverpool.ac.uk/~rlawson/cycleweb2.html`]],
 qs:[{id:'13',kind:'who',text:`Qui dessine le meilleur vélo ?`,award:`Cycliste de mémoire`}]},

{d:14,type:'apprends',noel:true,
 title:`Pourquoi le lait végétal rechigne à mousser`,
 body:`<p>Une mousse, ce sont des bulles d'air qu'il faut réussir à faire tenir. Dans le lait de vache, certaines molécules sont particulièrement bonnes à ça. Les boissons végétales contiennent autre chose, souvent en plus petite quantité, et réagissent différemment à la chaleur.</p>
 <p>C'est pour cela que les versions « barista » sont reformulées (matières grasses, stabilisants) afin de mieux résister à la chaleur et à la vapeur.</p>
 <p class="tip">Moralité : si ça ne mousse pas, ce n'est pas toi, c'est de la chimie. À méditer devant un chocolat chaud.</p>`,
 links:[[`Allodocteurs : réussir une mousse de lait`,`https://www.allodocteurs.fr/alimentation/cappuccino-latte-comment-faire-une-mousse-de-lait-maison_30919.html`],[`Fresh Cup : lattes et laits alternatifs`,`https://freshcup.com/latte-art-and-alternative-milks-the-good-the-bad-and-the-tasty`]],
 qs:[{id:'14',kind:'choice',text:`Pour ton chocolat chaud, la garniture ?`,options:[`Chantilly`,`Guimauves`,`Cannelle`,`Piment`,`Nature`]}]},

{d:15,type:'apprends',noel:true,
 title:`Treize desserts pour un seul repas`,
 body:`<p>En Provence, le repas de Noël se termine par <strong>treize desserts</strong>, un pour chaque convive de la Cène (Jésus et ses douze apôtres), selon l'explication la plus répandue. On y trouve presque toujours les « quatre mendiants » (raisins secs, figues sèches, amandes, noisettes), de la pompe à l'huile, du nougat blanc et noir, des fruits frais, des calissons.</p>
 <p>Règle de table : en principe, on goûte à chacun. Les desserts restent sur la table jusqu'à trois jours.</p>`,
 links:[[`ProvenceWeb : les 13 desserts du repas de Noël`,`https://www.provenceweb.fr/f/vie-locale/traditions/13-desserts.htm`],[`Provence Camargue Tourisme : les 13 desserts`,`https://www.provence-camargue-tourisme.com/en/les-13-desserts-de-noel-en-provence/`]],
 qs:[{id:'15',kind:'choice',text:`Dessert de Noël à garder pour toujours ?`,options:[`Bûche`,`Galette ou gâteau des rois`,`Panettone`,`Nougat`,`Calissons`,`Rien, je veux juste du fromage`]}]},

{d:16,type:'univers',noel:false,
 title:`Doom cache un message à l'envers (et la tête d'un développeur)`,
 body:`<p>Dans <em>Doom II</em> (1994), le boss final est un gigantesque mur à tête de démon, l'<strong>Icône du Péché</strong>. Quand il se réveille, il pousse un cri. Si on passe ce son à l'envers, on entend : <em>« To win the game, you must kill me, John Romero ! »</em> (« pour gagner, tu dois me tuer, John Romero »).</p>
 <p>La voix est celle de John Romero lui-même, un des développeurs, retravaillée par le compositeur Robert Prince. Et ce n'est pas tout : dans le cerveau du boss se cache la <strong>tête de Romero empalée sur un pieu</strong>. C'est elle qu'il faut toucher pour le vaincre.</p>`,
 links:[[`Doom Wiki : Icon of Sin`,`https://doomwiki.org/wiki/Icon_of_Sin`]],
 qs:[{id:'16',kind:'who',text:`Qui finirait Doom sans mourir une seule fois ?`,award:`Slayer de la Table`}]},

{d:17,type:'univers',noel:false,
 title:`Le Monopoly a été inventé pour critiquer le capitalisme`,
 body:`<p>Le Monopoly est né d'un jeu appelé <strong>The Landlord's Game</strong>, breveté au début des années 1900 par une Américaine, <strong>Lizzie Magie</strong>. Son but : montrer comment les loyers enrichissent les propriétaires et ruinent les locataires. Le jeu avait deux jeux de règles : un où l'on s'enrichit en écrasant les autres, un où la richesse est partagée.</p>
 <p>Des versions maison se sont répandues pendant des années. En 1935, la société Parker Brothers a racheté le brevet de Magie pour une somme modeste (500 dollars selon la plupart des sources) et a diffusé le Monopoly que l'on connaît, avec sa seule règle : tout prendre.</p>`,
 links:[[`Gus & Co : l'histoire du Monopoly`,`https://gusandco.net/2023/03/06/monopoly-histoire-documentaire/`],[`The Public Domain Review : The Landlord's Game`,`https://publicdomainreview.org/collection/the-landlords-game`]],
 qs:[{id:'17',kind:'choice',text:`Quel jeu de société détruit le plus les amitiés ?`,options:[`Monopoly`,`Uno`,`Skyjo`,`Code Names`,`Risk`]}]},

{d:18,type:'site',noel:false,
 title:`La Fondation qui range les choses interdites`,
 body:`<div class="warn"><strong>Case sombre.</strong> Contenu fictif d'horreur, certains textes décrivent des scènes dérangeantes. Lis les fiches que tu veux, ferme l'onglet quand tu veux.</div>
 <p>La <strong>SCP Foundation</strong> est un wiki collaboratif de fiction : des centaines de milliers d'auteurs inventent des fiches de « dossiers » sur des objets, créatures ou phénomènes paranormaux, confinés par une organisation secrète. Le ton froid et clinique des fiches rend certaines histoires encore plus glaçantes.</p>
 <p>Pour commencer : cherche <strong>SCP-173</strong>, une des fiches les plus connues.</p>`,
 links:[[`Wikipédia : Fondation SCP`,`https://fr.wikipedia.org/wiki/Fondation_SCP`],[`SCP Foundation (wiki)`,`https://scp-wiki.wikidot.com`]],
 qs:[{id:'18',kind:'who',text:`Qui survivrait le plus longtemps dans un film d'horreur ?`,award:`Dernier·ère survivant·e`}]},

{d:19,type:'apprends',noel:false,
 title:`Pourquoi dit-on « quatre-vingt-dix » ?`,
 body:`<p>En français, on compte en base 10 jusqu'à 69, puis on part en base 20 : <em>soixante-dix</em> (60+10), <em>quatre-vingts</em> (4×20), <em>quatre-vingt-dix</em> (4×20+10). C'est un reste d'un ancien système en vingtaines. Son origine est débattue (substrat gaulois, influence normande...).</p>
 <p>En Belgique et en Suisse romande, on dit <strong>septante</strong> et <strong>nonante</strong> ; certaines régions suisses disent aussi <em>huitante</em> pour 80. Et le danois est pire : <em>halvtreds</em> pour 50 vient de « deux fois vingt et demi ».</p>`,
 links:[[`Académie française : soixante-dix et quatre-vingt`,`https://dictionnaire-academie.fr/article/QDL078`]],
 qs:[{id:'19',kind:'choice',text:`Septante et nonante : on adopte ?`,options:[`Oui, ça simplifie`,`Non, quatre-vingt-dix c'est mon identité`,`Je compte en anglais pour fuir le problème`]},{id:'19b',kind:'who',text:`Qui a tricoté le pull le plus moche ?`,award:`Pull le plus moche`}]},

{d:20,type:'test',noel:true,
 title:`Le chocolat chaud, deviné les yeux fermés`,
 body:`<p>Pas de tasses, pas de casseroles : cette dégustation se joue à l'écran. Quatre recettes de chocolat chaud, quatre indices. À toi de retrouver qui est qui, comme si tu goûtais à l'aveugle.</p>
 <p>Rien à préparer, rien à laver. Si l'envie te prend d'en faire un vrai après, personne ne t'en empêchera.</p>`,
 links:[[`Hérodote : la saga du chocolat`,`https://www.herodote.net/La_saga_du_chocolat-synthese-657.php`]],
 qs:[{id:'20',kind:'who',text:`Qui trouvera les quatre chocolats chauds du premier coup ?`,award:`Palais d'or`}]},

{d:21,type:'test',noel:false,
 title:`Le bonhomme devin des régions`,
 body:`<p>Crayon de bois ou crayon à papier ? Chocolatine ou pain au chocolat ? Le français change d'une région à l'autre, et le linguiste Mathieu Avanzi en a fait des cartes entières. Le bonhomme de neige, lui, a fait mieux : il a mis un turban.</p>
 <p>Réponds à ses questions comme tu parles vraiment, sans tricher. Il essaie de deviner d'où tu viens. Et puisque c'est le jour le plus court de l'année, il fera vite.</p>`,
 links:[[`Brut : ces mots qui changent d'une région à l'autre (avec Mathieu Avanzi)`,`https://www.brut.media/fr/news/ces-mots-qui-changent-d-une-region-a-l-autre-7d9bb991-47ab-4833-94de-64dd851a7dbe`],[`Le Petit Journal : les expressions régionales préférées des Français`,`https://lepetitjournal.com/vivre-en-france/expressions-regionales-francaises-populaires-france-382386`],[`10h26 : ces mots qui changent de sens selon les régions`,`https://www.10h26.com/top-mots-changent-sens-regions-france`]],
 qs:[{id:'21',kind:'choice',text:`D'où vient (vraiment) ta façon de parler ?`,options:[`Nord`,`Île-de-France`,`Est et Alsace`,`Lyon et Rhône-Alpes`,`Marseille et Provence`,`Sud-Ouest`,`Ouest`,`Belgique ou Suisse`,`Un peu de partout`]}]},

{d:22,type:'histoire',noel:true,
 title:`Krampus, l'autre visiteur de décembre`,
 body:`<div class="warn"><strong>Un peu sombre.</strong> Noël, version Alpes.</div>
 <p>Dans les Alpes autrichiennes, bavaroises et italiennes, le soir du 5 décembre, saint Nicolas est accompagné d'une créature à cornes, fourrure et chaînes : le <strong>Krampus</strong>. Lui, il punit les enfants pas sages. Des défilés, les <em>Krampuslauf</em>, réunissent des centaines de personnes costumées et masquées.</p>
 <p>Le nom viendrait d'un vieux mot germanique qui évoque la griffe ou le crochet (l'origine reste incertaine). Les liens avec d'anciennes traditions païennes alpines sont souvent affirmés, mais peu prouvés.</p>`,
 links:[[`Wikipédia : Krampus`,`https://fr.wikipedia.org/wiki/Krampus`],[`Le Petit Journal Berlin : Krampus, le compagnon de saint Nicolas`,`https://lepetitjournal.com/berlin/comprendre-allemagne/krampus-qui-est-compagnon-du-saint-nicolas-33803`],[`Atlas Obscura : comment se fondre dans un défilé de Krampus`,`https://www.atlasobscura.com/articles/how-to-blend-in-at-an-alpine-krampus-parade`],[`Library of Congress : origines de Krampus`,`https://blogs.loc.gov/folklife/2025/12/krampus-origins-and-development-of-a-winter-devil/`]],
 qs:[{id:'22',kind:'who',text:`Qui joue le Krampus ?`,award:`Krampus de l'Avent`}]},

{d:23,type:'univers',noel:true,
 title:`La Reine des neiges n'est pas (tout à fait) celle d'Andersen`,
 body:`<p>Le conte <strong>La Reine des neiges</strong> a été publié par Hans Christian Andersen fin 1844 (daté de 1845 selon les éditions). L'histoire : une fillette part sauver son ami Kay, dont le cœur a été gelé par un éclat de miroir enchanté. La Reine des neiges est plutôt l'antagoniste.</p>
 <p>Disney y réfléchissait depuis des décennies. Le film de 2013 s'en inspire librement et a changé l'essentiel : deux sœurs, des chansons, et la glace comme pouvoir plutôt que comme malédiction.</p>
 <p class="tip">Et les chansons ? <em>Libérée, délivrée</em> est devenue un tube mondial, doublé en dizaines de langues.</p>`,
 links:[[`Le Petit Journal Copenhague : La Reine des neiges et Andersen`,`https://lepetitjournal.com/copenhague/frozen-reine-neiges-andersen-271594`],[`D23 : les films Disney tirés de livres pour enfants`,`https://d23.com/disney-films-that-started-out-as-childrens-books/`]],
 qs:[{id:'23',kind:'choice',text:`Au karaoké, tu prends…`,options:[`Disney`,`EPIC`,`Les deux en medley`,`Karaoké ? Jamais`]}]},

{d:24,type:'histoire',noel:true,
 title:`La trêve de Noël 1914`,
 body:`<p>Décembre 1914, front de l'Ouest. Des soldats britanniques et allemands, par endroits, cessent de se tirer dessus pour Noël. Des chants circulent d'une tranchée à l'autre, on échange des cigarettes et de petits cadeaux, on enterre les morts de la terre de personne. Tout cela est <strong>bien documenté</strong> par des lettres de soldats.</p>
 <p>Le match de football, lui, fait débat : plusieurs témoignages parlent de parties improvisées, mais il y a peu de preuves de vrais matchs organisés avec équipes et arbitre. Et la trêve n'a pas été générale : elle dépendait des secteurs, et les états-majors l'ont ensuite découragée.</p>`,
 links:[[`World History Encyclopedia : la trêve de Noël de 1914`,`https://www.worldhistory.org/trans/fr/1-23836/treve-de-noel-de-1914`],[`Football and the First World War : la trêve de Noël`,`https://footballandthefirstworldwar.org/the-christmas-truce-and-football/`]],
 qs:[{id:'24',kind:'choice',text:`Ton rituel du 24 ?`,options:[`Un repas qui dure quatre heures`,`Les cadeaux à minuit`,`Un film de Noël`,`Une marche digestive`,`Dodo à 21 h`]}]},

{d:25,type:'finale',noel:true,
 title:`La Trêve du Solstice`,
 body:`<p>25 cases ouvertes. Merci d'avoir joué le jeu, d'avoir voté, et d'avoir (peut-être) triché. Ce calendrier a été préparé pour la Table, et c'est maintenant à vous de décider quelle case était la meilleure. Plus bas : le palmarès de l'Avent, le classement de la Table et une idée de jeu pour la suite.</p>`,
 links:[],
 qs:[{id:'25a',kind:'select',text:`Quelle était la meilleure case ?`},{id:'25b',kind:'select',text:`Et la moins bonne ? (on ne le répétera pas à Mathilde)`}]}
];

const AWARDS=DAYS.flatMap(x=>x.qs.filter(q=>q.award).map(q=>({id:q.id,title:q.award})));


