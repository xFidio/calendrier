/* ---------- couche de jeu : points, série, badges, mini-jeux, surprises ---------- */
const GS=Object.assign({opened:{},games:{},bonus:{},eggs:0,flags:{},ev:{},sent:{},bseen:{},simon:0},store.get('ate_g',null)||{});
function gSave(){store.set('ate_g',GS);}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function parisHour(){try{return parseInt(new Intl.DateTimeFormat('fr-FR',{hour:'numeric',hour12:false,timeZone:TZ}).format(new Date()),10)%24;}catch(e){return new Date().getHours();}}
const WEEKEND_DAYS=[5,6,12,13,19,20,25]; // week-ends de décembre 2026 + Noël (vendredi férié)
const Game=(()=>{
  /* événements envoyés au Google Form (même format que les votes) */
  function emit(id,ans){GS.ev[id]=ans;gSave();flush();}
  function flush(){
    if(!me||!CONFIG.formUrl)return;
    Object.keys(GS.ev).forEach(id=>{if(!GS.sent[id]){GS.sent[id]=1;sendVote(me,id,GS.ev[id]);}});
    gSave();
  }
  /* récupération sur un autre appareil : on relit le tableur pour ce prénom */
  function snapshot(){
    const f=GS.flags||{};const keep={};
    ['flk','bub','bird','roll','blb','glo','sball','wish','gift','hit','sock','pull','uwu','tigre','devinko','devin','maudit','etoile','witch','dragon','lamp','lit','cheat','sulk','cat'].forEach(k=>{if(f[k])keep[k]=f[k];});
    if(f.cos)keep.cos=Object.keys(f.cos).join('.');
    return JSON.stringify({e:GS.eggs||0,f:keep});
  }
  let lastSnapT=0;
  function pushSnapshot(force){
    if(!me||!CONFIG.formUrl)return;
    const s=snapshot();if(s===GS.snap)return;
    if(!force&&Date.now()-lastSnapT<10*60*1000)return;
    lastSnapT=Date.now();GS.snap=s;gSave();sendVote(me,'s',s);
  }
  function restore(rows){
    if(!me||!rows)return 0;
    let n=0;const days=new Set();
    rows.filter(r=>r.name===me).forEach(r=>{
      const id=r.day,a=r.answer;let m;
      if((m=/^o(\d+)$/.exec(id))){const d=+m[1];if(!GS.opened[d]){GS.opened[d]={on:a==='jour',h:r.h};n++;days.add(d);}seen[d]=1;GS.ev[id]=GS.ev[id]||a;GS.sent[id]=1;}
      else if((m=/^j(\d+)$/.exec(id))){const d=+m[1];if(!GS.games[d]){GS.games[d]=a==='passé'?{pick:-1,ok:false,skip:true}:{pick:-1,ok:a==='ok'};n++;}GS.ev[id]=GS.ev[id]||a;GS.sent[id]=1;}
      else if((m=/^b(\d)$/.exec(id))){if(!GS.bonus[m[1]]){GS.bonus[m[1]]=1;n++;}GS.ev[id]=a;GS.sent[id]=1;}
      else if(/^\d+[ab]?$/.test(id)){if(!myVotes[id]){myVotes[id]=a;n++;}}
      else if(id==='s'){try{const o=JSON.parse(a);GS.eggs=Math.max(GS.eggs||0,o.e||0);const f=o.f||{};GS.flags=GS.flags||{};
        Object.keys(f).forEach(k=>{if(k==='cos'){GS.flags.cos=GS.flags.cos||{};String(f.cos).split('.').filter(Boolean).forEach(c=>GS.flags.cos[c]=1);}
          else if(typeof f[k]==='number')GS.flags[k]=Math.max(+GS.flags[k]||0,f[k]);else if(f[k])GS.flags[k]=f[k];});}catch(e){}}
    });
    gSave();store.set('ate_votes',myVotes);store.set('ate_seen',seen);
    return{n,days:days.size};
  }
  async function syncFromSheet(announce){
    if(!me||!CONFIG.statsCsvUrl)return;
    const before=points();
    const all=await getAllRows();if(!all)return;
    const res=restore(dedupe(all));if(!res||!res.n)return;
    const gained=points()-before;
    renderGbar();checkBadges(true);
    if(typeof renderGrid==='function')renderGrid();if(typeof renderStatus==='function')renderStatus();
    if(announce&&gained>0)toast(`Bon retour, ${me} ! J'ai récupéré tes points enregistrés à la Table : +${gained} pts.`);
  }
  document.addEventListener('visibilitychange',()=>{if(document.hidden)pushSnapshot(true);});
  addEventListener('pagehide',()=>pushSnapshot(true));
  setInterval(()=>pushSnapshot(false),60*1000);

  /* série */
  function streakInfo(){
    const days=Object.keys(GS.opened).filter(d=>GS.opened[d].on).map(Number).sort((a,b)=>a-b);
    let best=0,run=0,prev=-9,bonus=0,cur=0;
    days.forEach(d=>{run=(d===prev+1)?run+1:1;prev=d;best=Math.max(best,run);if(run>=3)bonus+=2;});
    const lim=Math.min(todayNum,25);
    if(days.length&&(prev===lim||prev===lim-1)){cur=run;}
    return{best,cur,bonus};
  }
  function stats(){
    const o=Object.values(GS.opened);
    const s=streakInfo();
    return{
      opened:o.length,onDay:o.filter(x=>x.on).length,early:o.some(x=>x.on&&x.h<8),late:o.some(x=>x.on&&x.h>=23),
      gamesOk:Object.values(GS.games).filter(g=>g.ok).length,flk:GS.flags.flk||0,etoile:GS.flags.etoile||0,uwu:!!GS.flags.uwu,tigre:GS.flags.tigre||0,devinko:!!GS.flags.devinko,sock:GS.flags.sock||0,pull:GS.flags.pull||0,wish:GS.flags.wish||0,gift:GS.flags.gift||0,hit:GS.flags.hit||0,bub:GS.flags.bub||0,bird:GS.flags.bird||0,roll:GS.flags.roll||0,glo:!!GS.flags.glo,sball:!!GS.flags.sball,
      found:Object.keys(GS.bonus).length,eggs:GS.eggs,streak:s.cur,best:s.best,streakBonus:s.bonus,
      we:Object.keys(GS.opened).filter(d=>GS.opened[d].on&&WEEKEND_DAYS.includes(+d)).length,
      votes:Object.keys(myVotes).length,cheat:!!GS.flags.cheat,sulk:!!GS.flags.sulk,cat:!!GS.flags.cat,chif:!!(GS.games[5]&&GS.games[5].ok),quizOk:FIRST_DAYS.filter(d=>GS.games[d]&&GS.games[d].ok).length,skips:Object.values(GS.games).filter(g=>g.skip).length,xmas:!!(GS.opened[25]&&GS.opened[25].on),cos:Object.keys(GS.flags.cos||{}).length,lit:!!GS.flags.lit
    };
  }
  function points(){
    const s=stats();let p=0;
    Object.keys(GS.opened).forEach(d=>{const x=GS.opened[d];p+=x.on?3:1;if(x.on&&WEEKEND_DAYS.includes(+d))p+=2;});
    p+=s.streakBonus+s.votes*2;
    Object.values(GS.games).forEach(g=>{if(!g.skip)p+=g.ok?3:1;});
    p+=s.found*5;
    return p;
  }
  const BADGES=[
    {id:'lt',n:'Lève-tôt',d:'Ouvrir la case du jour avant 8 h.',t:s=>s.early},
    {id:'noc',n:'Noctambule',d:'Ouvrir la case du jour après 23 h.',t:s=>s.late},
    {id:'we3',n:'Week-end studieux',d:'Ouvrir la case le jour J pendant 3 jours de week-end ou férié.',t:s=>s.we>=3},
    {id:'we7',n:'Jamais en vacances',d:'Ouvrir les 7 cases des week-ends et du 25 le jour J.',t:s=>s.we>=7},
    {id:'f3',n:'Étincelle',d:'3 jours de suite, ouverts le jour J.',t:s=>s.best>=3},
    {id:'f7',n:'Flamme',d:'7 jours de suite.',t:s=>s.best>=7},
    {id:'f15',n:'Brasier',d:'15 jours de suite.',t:s=>s.best>=15},
    {id:'g5',n:'Cerveau',d:'Réussir 4 quiz ou jeux.',t:s=>s.gamesOk>=4},
    {id:'g15',n:'Encyclopédie',d:'Réussir 8 quiz ou jeux.',t:s=>s.gamesOk>=8},
    {id:'qz',n:'Quiz sans filet',d:'Réussir 3 quiz avant l\'anecdote.',t:s=>s.quizOk>=3},
    {id:'sk',n:'Je lis directement',d:'Passer 3 quiz sans y répondre.',t:s=>s.skips>=3},
    {id:'chif',n:'Maître du chifoumi',d:'Battre le bonhomme de neige à la case 5.',t:s=>s.chif},
    {id:'fl10',n:'Attrape-flocons',d:'Attraper 10 gros flocons au vol.',t:s=>s.flk>=10},
    {id:'fl50',n:'Collection d\'hiver',d:'Attraper 50 gros flocons.',t:s=>s.flk>=50},
    {id:'bub',n:'Ramoneur·se',d:'La cheminée fait des bulles. Elles ne résistent pas longtemps.',h:1,t:s=>s.bub>=15},
    {id:'glo',n:'Décorateur·rice',d:'Une guirlande bien assortie.',h:1,t:s=>s.glo},
    {id:'wi',n:'Faiseur·se de vœux',d:'Quelque chose passe dans le ciel, la nuit.',h:1,t:s=>s.wish>=3},
    {id:'gi',n:'Lutin du 24',d:'Le 24, lève les yeux.',h:1,t:s=>s.gift>=1},
    {id:'hi',n:'Bataille de neige',d:'Lancer 5 flocons sur le bonhomme de neige.',t:s=>s.hit>=5},
    {id:'so',n:'Père Noël secret',d:'Glisser 3 mots dans les chaussettes de la Table.',t:s=>s.sock>=3},
    {id:'pu',n:'Styliste douteux·se',d:'Tricoter un pull moche pour le bonhomme.',t:s=>s.pull>=1},
    {id:'uw',n:'uwu',d:'(˶ᵔ ᵕ ᵔ˶)',h:1,t:s=>s.uwu},
    {id:'ti',n:'Tié un tigre',d:'Dire merci comme à Marseille.',t:s=>s.tigre>=1},
    {id:'dv',n:'Plus fort·e que le devin',d:'Le bonhomme a mis un turban. Fais-le douter.',h:1,t:s=>s.devinko},
    {id:'st',n:'Super étoile',d:'Tout en haut du palais de glace, quelque chose brille.',h:1,t:s=>s.etoile>=1},
    {id:'oi',n:'Ornithologue',d:'Faire s\'envoler le rouge-gorge 5 fois.',t:s=>s.bird>=5},
    {id:'sb',n:'Boule de neige géante',d:'Il suffit de la pousser. Beaucoup.',h:1,t:s=>s.sball},
    {id:'v10',n:'Citoyen·ne de la Table',d:'Voter sur 10 cases.',t:s=>s.votes>=10},
    {id:'v20',n:'Électeur·rice assidu·e',d:'Voter sur 20 cases.',t:s=>s.votes>=20},
    {id:'fd',n:'Chasseur·se d\'étoiles',d:'Trouver 3 trésors cachés.',t:s=>s.found>=3},
    {id:'fd5',n:'Tout trouvé',d:'Trouver les 5 trésors cachés.',t:s=>s.found>=5},
    {id:'sn',n:'Ami·e du bonhomme',d:'Un peu de patience et beaucoup de clics.',h:1,t:s=>s.eggs>=15},
    {id:'e50',n:'Tapoteur·se de neige',d:'Cliquer 50 fois sur les sapins et le bonhomme.',t:s=>s.eggs>=50},
    {id:'sul',n:'Bouderie',d:'Le bonhomme a des limites.',h:1,t:s=>s.sulk},
    {id:'cat',n:'Ami des chats',d:'Quelqu\'un te regarde, quelque part.',h:1,t:s=>s.cat},
    {id:'lit',n:'Guirlande',d:'Allumer un sapin.',t:s=>s.lit},
    {id:'gw',n:'Garde-robe complète',d:'Voir toutes les tenues du bonhomme de neige.',t:s=>s.cos>=Object.keys(OUTFITS).length},
    {id:'dd',n:'Dandy',d:'Voir 10 tenues différentes du bonhomme.',t:s=>s.cos>=10},
    {id:'ar',n:'Archiviste',d:'Ouvrir les 25 cases.',t:s=>s.opened>=25},
    {id:'xm',n:'Joyeux Noël',d:'Ouvrir la case 25 le jour J.',t:s=>s.xmas},
    {id:'ch',n:'Voyageur·se temporel·le',d:'Se faire démasquer par l\'anti-triche. On n\'en dira pas plus.',h:1,t:s=>s.cheat}
  ];
  function pointsBreakdown(){
    const st=stats();let open=0,we=0,miniP=0;
    Object.keys(GS.opened).forEach(d=>{const x=GS.opened[d];open+=x.on?3:1;if(x.on&&WEEKEND_DAYS.includes(+d))we+=2;});
    Object.values(GS.games).forEach(g=>{if(!g.skip)miniP+=g.ok?3:1;});
    return[['Ouvertures de cases',open],['Bonus week-end et 25',we],['Bonus de série',st.streakBonus],['Votes',st.votes*2],['Mini-jeux et quiz',miniP],['Trésors cachés',st.found*5]];
  }
  function demoFill(){
    for(let d=1;d<=25;d++){GS.opened[d]={on:true,h:d===1?7:23};GS.games[d]={pick:0,ok:true};}
    [1,2,3,4,5].forEach(n=>GS.bonus[n]=1);GS.eggs=20;GS.flags.lit=1;GS.flags.cheat=1;GS.flags.sulk=1;GS.flags.cat=1;GS.eggs=60;GS.flags.flk=60;GS.flags.etoile=1;GS.flags.uwu=1;GS.flags.tigre=1;GS.flags.devinko=1;GS.flags.sock=3;GS.flags.pull=1;GS.flags.wish=3;GS.flags.gift=1;GS.flags.hit=5;GS.flags.bub=20;GS.flags.bird=6;GS.flags.glo=1;GS.flags.sball=1;GS.flags.cos={};Object.values(OUTFITS).forEach(o=>GS.flags.cos[o.c]=1);
    for(let i=1;i<=12;i++)myVotes['demo'+i]='x';
    try{store.set('ate_votes',myVotes);}catch(e){}
    gSave();location.reload();
  }
  function checkBadges(silent){
    const s=stats();const fresh=BADGES.filter(b=>b.t(s)&&!GS.bseen[b.id]);
    fresh.forEach(b=>GS.bseen[b.id]=1);
    if(fresh.length){gSave();if(!silent)setTimeout(()=>{toast('Badge débloqué : '+fresh.map(b=>b.n).join(', '));confetti();},900);}
    renderGbar();
  }
  function missedDays(){const o=[];for(let d=1;d<Math.min(todayNum,25);d++)if(!GS.opened[d])o.push(d);return o;}
  function renderMissed(){
    const m=$('#missed');if(!m)return;m.innerHTML='';
    const l=missedDays();
    if(todayNum<2||!l.length){m.hidden=true;return;}
    m.hidden=false;m.appendChild(txt('span','',l.length===1?'À rattraper (1 pt) : ':'À rattraper (1 pt chacune) : '));
    l.slice(0,8).forEach((d,i)=>{const b=txt('button','','case '+d);b.type='button';b.addEventListener('click',()=>{const t=document.querySelector('.tile[data-day="'+d+'"]');if(t)t.click();});m.appendChild(b);if(i<Math.min(l.length,8)-1)m.appendChild(document.createTextNode(' · '));});
    if(l.length>8)m.appendChild(txt('span','',' et '+(l.length-8)+' autres'));
  }
  function renderGbar(){
    const g=$('#gbar');if(!g)return;g.innerHTML='';
    renderMissed();
    if(todayNum<1){g.hidden=true;return;}
    g.hidden=false;
    const st=stats();
    const who=txt('button','whochip',me?me:'Dis-nous qui tu es');who.type='button';who.title=me?'Changer de prénom':'Choisir ton prénom';
    who.addEventListener('click',()=>askWho(true));
    g.appendChild(who);
    g.appendChild(document.createTextNode(' · '));
    g.appendChild(txt('span','',points()+' pts'));
    if(st.streak>0){g.appendChild(txt('span','',' · série '+st.streak));}
    const b=txt('button','','Mon carnet');b.type='button';b.addEventListener('click',openCarnet);
    g.appendChild(document.createTextNode(' · '));g.appendChild(b);
  }
  function gain(msg){toast(msg);checkBadges();}

  /* ouverture d'une case */
  function onOpen(x){
    if(GS.opened[x.d])return;
    const on=todayNum===x.d;
    GS.opened[x.d]={on,h:parisHour()};gSave();
    emit('o'+x.d,on?'jour':'retard');
    const we=on&&WEEKEND_DAYS.includes(x.d);
    const pts=(on?3:1)+(we?2:0);
    gain(`+${pts} pt${pts>1?'s':''} pour l'ouverture${on?' le jour J':''}${we?' (bonus week-end/férié)':''}`);
  }
  function onVote(q){gain('+2 pts pour ton vote');}

  /* mini-jeu */
  function isFirst(x){return FIRST_DAYS.includes(x.d)&&!!GAMES[x.d];}
  function gameDone(x){return !!GS.games[x.d];}
  function gameBlock(x,opt){
    opt=opt||{};
    const g=GAMES[x.d];const frag=document.createDocumentFragment();if(!g)return frag;
    const box=el('div','mini'+(opt.first?' first':''));
    box.appendChild(txt('h3','',opt.first?'Quiz avant l\'anecdote':'Mini-jeu · 20 secondes'));
    if(opt.first&&!GS.games[x.d])box.appendChild(txt('p','note','Réponds d\'abord. L\'histoire se révèle juste après.'));
    box.appendChild(txt('p','qtext',g.q));
    const opts=el('div','opts');opts.setAttribute('role','group');
    const res=txt('p','note','');
    let skip=null;
    const btns=g.o.map((o,i)=>{
      const b=txt('button','opt',o);b.type='button';
      b.addEventListener('click',()=>{
        if(GS.games[x.d])return;
        const ok=i===g.a;GS.games[x.d]={pick:i,ok};gSave();emit('j'+x.d,ok?'ok':'ko');
        paint();gain(ok?'Bien joué ! +3 pts':'Raté, mais +1 pt pour avoir essayé');
        if(opt.onDone)opt.onDone();
      });
      opts.appendChild(b);return b;
    });
    function paint(){
      const st=GS.games[x.d];if(!st)return;
      btns.forEach((b,i)=>{b.disabled=true;if(i===g.a)b.classList.add('good');else if(i===st.pick)b.classList.add('bad');});
      res.textContent=st.skip?('Réponse : '+g.o[g.a]+'. '+g.e):((st.ok?'Exact. ':'Pas tout à fait. ')+g.e);
      if(skip)skip.hidden=true;
    }
    box.appendChild(opts);box.appendChild(res);
    if(opt.first){
      skip=txt('button','btn ghost','Je lis directement (0 pt)');skip.type='button';
      skip.addEventListener('click',()=>{
        if(GS.games[x.d])return;
        GS.games[x.d]={pick:-1,ok:false,skip:true};gSave();emit('j'+x.d,'passé');paint();
        if(opt.onDone)opt.onDone();
      });
      box.appendChild(skip);
    }
    paint();
    frag.appendChild(box);return frag;
  }
  function teaserBlock(x){
    const frag=document.createDocumentFragment();
    if(x.d!==todayNum||x.d>=25||!TEASERS[x.d-1])return frag;
    const t=el('div','teaser');
    t.appendChild(txt('b','','À demain ? '));
    {const tx=TEASERS[x.d-1].replace(/^Demain : /,'');t.appendChild(document.createTextNode(tx.charAt(0).toUpperCase()+tx.slice(1)));}
    frag.appendChild(t);return frag;
  }

  /* classement à partir du CSV */
  function ranking(rows){
    const by={};MEMBERS.forEach(n=>by[n]={n,p:0,days:new Set()});
    rows.forEach(r=>{
      const u=by[r.name];if(!u)return;const id=r.day;
      if(/^\d+[ab]?$/.test(id))u.p+=2;
      else if(/^o\d+$/.test(id)){if(r.answer==='jour'){u.p+=3;u.days.add(parseInt(id.slice(1),10));if(WEEKEND_DAYS.includes(parseInt(id.slice(1),10)))u.p+=2;}else u.p+=1;}
      else if(/^[jp]\d+$/.test(id))u.p+=r.answer==='ok'?3:1;
      else if(/^b\d$/.test(id))u.p+=5;
    });
    Object.values(by).forEach(u=>{const ds=[...u.days].sort((a,b)=>a-b);let run=0,prev=-9;ds.forEach(d=>{run=d===prev+1?run+1:1;prev=d;if(run>=3)u.p+=2;});});
    return Object.values(by).sort((a,b)=>b.p-a.p);
  }
  function rankingEl(rows){
    const wrap=el('div','pal');
    const r=ranking(rows);const top=r[0]?r[0].p:0;
    if(!top){return txt('p','note','Pas encore de points enregistrés.');}
    r.forEach((u,i)=>{const d=el('div','');d.appendChild(txt('span','',(i+1)+'. '+u.n));d.appendChild(txt('b','',u.p+' pts'));wrap.appendChild(d);});
    return wrap;
  }

  /* carnet */
  function openSheet(node){
    const ov=$('#carnet'),box=$('#carnetBox');box.innerHTML='';
    const close=txt('button','close','×');close.type='button';close.setAttribute('aria-label','Fermer');close.addEventListener('click',()=>ov.classList.remove('open'));
    box.appendChild(close);box.appendChild(node);
    ov.classList.add('open');ov.scrollTop=0;close.focus();
  }
  function openCarnet(){
    const s=stats();const n=el('div','');
    n.appendChild(txt('span','badge','Carnet de la Table'));
    n.appendChild(txt('h2','',points()+' points'));
    const meta=el('div','cmeta');
    [['Série en cours',s.streak+' j'],['Meilleure série',s.best+' j'],['Cases ouvertes',s.opened+' / 25'],['Mini-jeux',s.gamesOk+' réussis'],['Trésors trouvés',s.found+' / 5']].forEach(([a,b])=>{const d=el('div','cm');d.appendChild(txt('b','',b));d.appendChild(txt('span','',a));meta.appendChild(d);});
    n.appendChild(meta);
    n.appendChild(txt('h3','sect','D\'où viennent mes points'));
    const bd=el('div','pbreak');pointsBreakdown().forEach(([a,b])=>{const r=el('div','pb');r.appendChild(txt('span','',a));r.appendChild(txt('b','',b));bd.appendChild(r);});n.appendChild(bd);
    n.appendChild(txt('h3','sect','Badges ('+BADGES.filter(b=>b.t(s)).length+' / '+BADGES.length+')'));
    const grid=el('div','bdgs');
    BADGES.forEach(b=>{const on=b.t(s);const d=el('div','bdg'+(on?' on':''));d.appendChild(txt('b','',(on||b.id!=='ch')?b.n:'???'));d.appendChild(txt('span','',(b.h&&!on)?'???':b.d));grid.appendChild(d);});
    n.appendChild(grid);
    const ic=gcalLink('Ajouter un rappel quotidien à 9 h dans Google Agenda');ic.style.display='inline-block';ic.style.marginTop='14px';n.appendChild(ic);
    const fnd=BONUS.filter(b=>GS.bonus[b.n]);
    n.appendChild(txt('h3','sect','Trésors cachés'));
    if(fnd.length){fnd.forEach(b=>{const m=el('div','msg');m.appendChild(txt('b','',b.title+' : '));m.appendChild(document.createTextNode(b.text));n.appendChild(m);});}
    else n.appendChild(txt('p','note','Rien trouvé pour l\'instant. Le bonhomme de neige donne des indices.'));
    n.appendChild(txt('h3','sect','Classement de la Table'));
    const lb=txt('p','note','Chargement…');n.appendChild(lb);
    getRows().then(rows=>{if(!rows){lb.textContent=CONFIG.statsCsvUrl?'Le classement ne se charge pas pour le moment.':'Le classement arrive bientôt.';return;}lb.replaceWith(rankingEl(rows));});
    n.appendChild(txt('p','note','Les points : ouverture le jour J 3 pts (1 pt en retard), vote 2 pts, mini-jeu 3 pts, trésor 5 pts, bonus de 2 pts pour une ouverture le jour J un week-end ou le 25, bonus de série à partir de 3 jours.'));
    openSheet(n);
  }

  /* trésors cachés */
  function tryBonus(n){
    const b=BONUS.find(x=>x.n===n);if(!b||todayNum<b.day||GS.bonus[n])return false;
    GS.bonus[n]=1;gSave();emit('b'+n,'trouvé');
    const c=el('div','');c.appendChild(txt('span','badge','Trésor caché '+n+' / 5'));c.appendChild(txt('h2','',b.title));
    c.appendChild(txt('p','',b.text));c.appendChild(txt('p','note','+5 points. Les autres trésors sont ailleurs.'));
    openSheet(c);Music.arp([72,76,79,84,88]);
    document.querySelectorAll('.glint[data-bonus="'+n+'"]').forEach(e=>e.classList.remove('glint'));
    checkBadges();return true;
  }
  function setupBonus(){
    const targets={
      moon:$('.moon'),chimney:$('#chimHit'),title:$('#bTitle'),legend:$('.legend span'),lock:null
    };
    BONUS.forEach(b=>{
      const t=targets[b.target];
      if(t){
        t.dataset.bonus=b.n;
        t.addEventListener('click',()=>tryBonus(b.n));
        if(todayNum>=b.day&&!GS.bonus[b.n])t.classList.add('glint');
      }
    });
    const legend=$('.legend');if(legend){legend.removeAttribute('aria-hidden');}
  }
  function lockClick(x,ev){
    if(x.d!==25||!ev||!ev.target.closest||!ev.target.closest('.lock'))return false;
    return tryBonus(5);
  }
  function markLock(){
    const b=BONUS[4];
    const t=document.querySelector('.tile.locked[data-day="25"] .lock');
    if(t&&todayNum>=b.day&&!GS.bonus[5])t.classList.add('glint');
  }

  function seenCos(c){GS.flags.cos=GS.flags.cos||{};if(!GS.flags.cos[c]){GS.flags.cos[c]=1;gSave();checkBadges();}}
  function nextCostume(cur){
    const d=Math.max(0,Math.min(todayNum,25));
    const pool=Object.keys(OUTFITS).filter(k=>+k<=d&&OUTFITS[k].c!==cur).map(k=>OUTFITS[k]);
    if(!pool.length)return{cos:'',line:'Rebonjour ! Retour à ma tenue d\'origine : le chapeau haut de forme.'};
    const o=pool[Math.floor(Math.random()*pool.length)];seenCos(o.c);return{cos:o.c,line:o.l};
  }
  /* bonhomme de neige qui évolue */
  function snowmanSetup(){
    const h=$('.egg.snowman');if(!h)return;
    const d=Math.max(0,Math.min(todayNum,25));
    const acc=[];if(d>=7)acc.push('a2');if(d>=11)acc.push('a3');if(d>=16)acc.push('a4');if(d>=25)acc.push('a5');
    h.dataset.acc=acc.join(' ');
    h.style.setProperty('--pos',String(d?(d-1)/24:0.5));
    const o=OUTFITS[d];if(o){h.dataset.cos=o.c;seenCos(o.c);}
    Music.setTrack(TRACK_BY_DAY[d]||'base');
    if(d===18)setTimeout(()=>placeCat(h),600);
    trainSync(h);
    new MutationObserver(()=>trainSync(h)).observe(h,{attributes:true,attributeFilter:['data-cos']});
    if(d>=1&&d<=25&&store.get('ate_snowday',0)!==d){
      setTimeout(()=>{
        const ground=$('.ground');if(!ground)return;
        bubble(h,ground,SNOW_DAILY[d-1]+(o?' Tenue du jour : '+o.n+'.':''));store.set('ate_snowday',d);
      },1800);
    }
  }
  const CAT_LINES=['Miaou. (Traduction : tu as ouvert la case 18, tu es maudit·e.)','Acédia te regarde. Elle n\'a aucune envie de se lever.','Prrr… Je note ton nom dans le carnet des pénalités.','Je ne suis pas un mimic. Quoique, ça dépend de l\'heure.','Elle a dit « flemme ». Je répète juste.'];
  function placeCat(h){
    const ground=$('.ground');if(!ground||ground.querySelector('.cat'))return;
    const c=el('button','cat');c.type='button';c.setAttribute('aria-label','Un chat noir aux yeux rouges');
    let ci=Math.floor(Math.random()*CAT_IMGS.length);
    const im=document.createElement('img');im.alt='';im.src=CAT_IMGS[ci];c.appendChild(im);
    const right=h.offsetLeft+h.offsetWidth+60<ground.clientWidth;
    c.style.left=(right?h.offsetLeft+h.offsetWidth-4:Math.max(0,h.offsetLeft-54))+'px';
    c.style.top=(h.offsetTop+h.offsetHeight-60)+'px';
    c.addEventListener('click',()=>{
      if(!GS.flags.cat){GS.flags.cat=1;gSave();checkBadges();}
      ci=(ci+1)%CAT_IMGS.length;im.src=CAT_IMGS[ci];bubble(c,ground,pick(CAT_LINES));
    });
    ground.appendChild(c);
  }
  function trainSync(h){
    const box=document.querySelector('.railbox');if(!box)return;
    const on=h.dataset.cos==='c3';
    if(on&&!box.firstChild){
      box.innerHTML='<div class="rails"></div>';
      const tr=document.createElement('button');tr.type='button';tr.className='train';tr.setAttribute('aria-label','Un petit train qui roule sur ses rails');
      tr.innerHTML='<svg viewBox="0 0 150 34" aria-hidden="true"><g stroke="#2b1b3d" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"><rect x="96" y="12" width="40" height="13" rx="2" fill="#e5484d"/><rect x="118" y="3" width="18" height="11" rx="2" fill="#e5484d"/><rect x="100" y="5" width="7" height="9" fill="#2b1b3d"/><path d="M136 25h8v-4h-8z" fill="#ffcf5c"/><circle cx="106" cy="27" r="5" fill="#fff"/><circle cx="126" cy="27" r="5" fill="#fff"/><rect x="52" y="10" width="38" height="15" rx="2" fill="#3d6fe0"/><circle cx="62" cy="27" r="5" fill="#fff"/><circle cx="80" cy="27" r="5" fill="#fff"/><rect x="8" y="10" width="38" height="15" rx="2" fill="#f2a900"/><circle cx="18" cy="27" r="5" fill="#fff"/><circle cx="36" cy="27" r="5" fill="#fff"/><path d="M46 20h6M90 20h6" fill="none"/></g></svg><span class="puff"></span><span class="puff p2"></span>';
      tr.addEventListener('click',()=>{const g=$('.ground');Music.arp([79,84,79,84]);bubble(tr,g,'Tchou tchou ! Prochain arrêt : la case de demain.');});
      box.appendChild(tr);
    }
    box.classList.toggle('on',on);
  }
  function toy(k){GS.flags[k]=(GS.flags[k]||0)+1;gSave();checkBadges();return GS.flags[k];}
  function flag(k,v){if(v===undefined)return GS.flags[k];GS.flags[k]=v;gSave();checkBadges();return v;}
  function eggClick(h){GS.eggs++;gSave();if(h&&h.classList.contains('lit')){GS.flags.lit=1;gSave();}checkBadges();}
  function setSulk(){if(GS.flags.sulk)return;GS.flags.sulk=1;gSave();checkBadges();}
  function setLit(){GS.flags.lit=1;gSave();checkBadges();}
  function setCheat(){GS.flags.cheat=1;gSave();checkBadges();}

  /* formats spéciaux */
  function special(x){
    const f={5:chifoumi,10:simon,13:bike,18:torch,20:tasting}[x.d];
    return f?f():document.createDocumentFragment();
  }
  function chifoumi(){
    const box=el('div','special');
    box.appendChild(txt('h3','','Case spéciale · Chifoumi contre le bonhomme de neige'));
    box.appendChild(txt('p','note','Au meilleur des trois manches. Il joue au hasard, mais il est de mauvaise foi.'));
    const names=['Pierre','Feuille','Ciseaux'],emo=['✊','✋','✌️'];
    const duel=el('div','duel');const you=txt('span','dhand','✊'),sep=txt('span','dvs','contre'),bot=txt('span','dhand bot','✊');
    const lab=el('div','dlab');lab.appendChild(txt('span','','Toi'));lab.appendChild(txt('span','','Bonhomme'));
    duel.appendChild(you);duel.appendChild(sep);duel.appendChild(bot);
    const row=el('div','row');const msg=txt('p','qtext','Prêt ?');const score=txt('p','note','Toi 0 · Bonhomme 0');
    let me_=0,bo=0,over=false,busy=false;
    const done=GS.games[5];
    if(done){msg.textContent=done.ok?'Déjà gagné. Bien joué.':'Déjà joué. Le bonhomme t\'a eu.';}
    names.forEach((nm,i)=>{
      const b=txt('button','btn chifb',emo[i]+' '+nm);b.type='button';b.setAttribute('aria-label',nm);
      b.addEventListener('click',()=>{
        if(over||done||busy)return;busy=true;
        const c=Math.floor(Math.random()*3);
        you.textContent='✊';bot.textContent='✊';duel.classList.remove('shake');void duel.offsetWidth;duel.classList.add('shake');
        msg.textContent='Chi… fou… mi !';
        setTimeout(()=>{
          busy=false;duel.classList.remove('shake');you.textContent=emo[i];bot.textContent=emo[c];
          let r='Égalité';
          if(c!==i){if((i+1)%3===c){r='Perdu';bo++;}else{r='Gagné';me_++;}}
          you.classList.toggle('win',r==='Gagné');bot.classList.toggle('win',r==='Perdu');
          msg.textContent=nm+' contre '+names[c]+' : '+r+'.';
          score.textContent='Toi '+me_+' · Bonhomme '+bo;
          if(me_===2||bo===2){
            over=true;const ok=me_===2;
            GS.games[5]={pick:i,ok};gSave();emit('j5',ok?'ok':'ko');
            msg.textContent+=ok?' Tu as battu le bonhomme !':' Le bonhomme gagne. Il est insupportable.';
            gain(ok?'Victoire ! +3 pts':'Perdu, mais +1 pt pour avoir joué');
          }
        },RM()?50:900);
      });
      row.appendChild(b);
    });
    box.appendChild(duel);box.appendChild(lab);box.appendChild(row);box.appendChild(msg);box.appendChild(score);return box;
  }
  function simon(){
    const box=el('div','special');
    box.appendChild(txt('h3','','Case spéciale · Simon 8-bit'));
    box.appendChild(txt('p','note','Mémorise la suite de sons et de couleurs, puis répète-la. Combien de tours tiens-tu ? (Le son joue même si la musique est coupée.)'));
    const notes=[262,330,392,523],cols=['#e5484d','#3d6fe0','#f2a900','#2f8a62'];
    const pads=el('div','pads');const pb=[];
    let seq=[],pos=0,busy=false;
    const msg=txt('p','qtext','Prêt ?');
    const best=txt('p','note','Meilleur score : '+(GS.simon||0));
    async function flash(i){pb[i].classList.add('lit');Music.beep(notes[i],.28,'square',.08);await sleep(280);pb[i].classList.remove('lit');}
    async function playSeq(){busy=true;msg.textContent='Écoute…';for(const i of seq){await sleep(250);await flash(i);}busy=false;msg.textContent='À toi : '+seq.length+' son'+(seq.length>1?'s':'');}
    cols.forEach((c,i)=>{const b=el('button','pad');b.type='button';b.style.background=c;b.setAttribute('aria-label','Pad '+(i+1));
      b.addEventListener('click',async()=>{
        if(busy||!seq.length)return;await flash(i);
        if(i!==seq[pos]){const sc=seq.length-1;if(sc>(GS.simon||0)){GS.simon=sc;gSave();}best.textContent='Meilleur score : '+GS.simon;msg.textContent='Raté ! Score : '+sc+'. Rejoue ?';seq=[];start.textContent='Rejouer';start.hidden=false;Music.beep(110,.4,'sawtooth',.07);return;}
        pos++;if(pos===seq.length){pos=0;seq.push(Math.floor(Math.random()*4));busy=true;await sleep(500);playSeq();}
      });pads.appendChild(b);pb.push(b);});
    const start=txt('button','btn','Commencer');start.type='button';
    start.addEventListener('click',()=>{seq=[Math.floor(Math.random()*4)];pos=0;start.hidden=true;playSeq();});
    box.appendChild(pads);box.appendChild(msg);box.appendChild(start);box.appendChild(best);return box;
  }
  function bike(){
    const box=el('div','special');
    box.appendChild(txt('h3','','Case spéciale · Dessine ton vélo'));
    box.appendChild(txt('p','note','Dessine un vélo de mémoire, sans tricher, avec le doigt ou la souris. Puis appuie sur « Révéler » pour comparer.'));
    const wrap=el('div','bikewrap');
    wrap.innerHTML='<svg class="bikesvg" viewBox="0 0 320 240" aria-hidden="true"><g fill="none" stroke="#2b1b3d" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"><circle cx="80" cy="160" r="50"/><circle cx="240" cy="160" r="50"/><path d="M80 160L130 100L215 100L240 160M130 100L150 165L215 100M150 165L80 160M215 100L212 78L238 74M122 94h28M150 165l16 22M150 165l-16-22"/><circle cx="150" cy="165" r="9" fill="#ffcf5c"/></g></svg>';
    const cv=document.createElement('canvas');cv.width=640;cv.height=480;cv.className='bikecv';
    const cx=cv.getContext('2d');cx.lineWidth=7;cx.lineCap='round';cx.lineJoin='round';cx.strokeStyle='#e5484d';
    let dr=false;
    const pt=e=>{const r=cv.getBoundingClientRect();return[(e.clientX-r.left)*cv.width/r.width,(e.clientY-r.top)*cv.height/r.height];};
    cv.addEventListener('pointerdown',e=>{dr=true;cv.setPointerCapture(e.pointerId);const[x,y]=pt(e);cx.beginPath();cx.moveTo(x,y);cx.lineTo(x+.1,y+.1);cx.stroke();});
    cv.addEventListener('pointermove',e=>{if(!dr)return;const[x,y]=pt(e);cx.lineTo(x,y);cx.stroke();});
    ['pointerup','pointercancel'].forEach(ev=>cv.addEventListener(ev,()=>{dr=false;}));
    wrap.appendChild(cv);box.appendChild(wrap);
    const row=el('div','row');
    const rev=txt('button','btn','Révéler le vrai vélo');rev.type='button';rev.addEventListener('click',()=>{wrap.classList.toggle('reveal');rev.textContent=wrap.classList.contains('reveal')?'Cacher le vrai vélo':'Révéler le vrai vélo';});
    const clr=txt('button','btn ghost','Effacer');clr.type='button';clr.addEventListener('click',()=>cx.clearRect(0,0,cv.width,cv.height));
    row.appendChild(rev);row.appendChild(clr);box.appendChild(row);return box;
  }
  function torch(){
    const box=el('div','special');
    box.appendChild(txt('h3','','Case spéciale · Lampe torche'));
    box.appendChild(txt('p','note','Il fait noir. Bouge ta lampe torche (souris ou doigt) pour lire le dossier. Il est fictif et sans danger.'));
    const t=el('div','torch');t.style.setProperty('--x','50%');t.style.setProperty('--y','50%');
    t.innerHTML='<div class="tt"><b>DOSSIER SCP-FLEMME-0001</b><br>Classe : Canapé.<br>Procédures de confinement : l\'objet doit être maintenu à moins de deux mètres d\'une couverture et d\'un chocolat chaud.<br>Description : un fauteuil en apparence ordinaire, d\'où personne n\'est jamais revenu avant le soir. Tout sujet qui s\'y assoit déclare « cinq minutes » et sort quatre heures plus tard.<br>Addendum : le 24 décembre, l\'objet est classé « Réveillon ». Il devient inoffensif.<br><i>[Les autres lignes ont été expurgées par la Table des Enfants.]</i></div>';
    const mv=e=>{const r=t.getBoundingClientRect();t.style.setProperty('--x',(e.clientX-r.left)+'px');t.style.setProperty('--y',(e.clientY-r.top)+'px');};
    t.addEventListener('pointermove',mv);t.addEventListener('pointerdown',mv);
    box.appendChild(t);return box;
  }
  function tasting(){
    const box=el('div','special');
    box.appendChild(txt('h3','','Case spéciale · Dégustation à l\'aveugle (par écrit)'));
    box.appendChild(txt('p','note','Associe chaque indice à la bonne recette. Chaque recette sert une seule fois.'));
    const R=['Chocolat viennois','Chocolat à l\'espagnole','Chocolat chaud mexicain','Chocolat chaud blanc'];
    const CL=[
      ['Si épais que la cuillère tient debout. On y trempe des churros.',1],
      ['On le fouette avec un moulinet en bois et il peut piquer un peu, avec cannelle et parfois piment.',2],
      ['Il porte un nuage de crème fouettée.',0],
      ['Pas de pâte de cacao : du beurre de cacao, du sucre, du lait. Couleur ivoire.',3]
    ];
    const done=GS.games[20];
    const sels=[];
    CL.forEach(([c,a],i)=>{
      const row=el('div','trow');row.appendChild(txt('span','',(i+1)+'. '+c));
      const sel=document.createElement('select');sel.setAttribute('aria-label','Indice '+(i+1));
      sel.appendChild(txt('option','','Choisis une recette…')).value='';
      R.forEach((r,k)=>{const o=txt('option','',r);o.value=String(k);sel.appendChild(o);});
      if(done){sel.value=String(a);sel.disabled=true;}
      sels.push(sel);row.appendChild(sel);box.appendChild(row);
    });
    const out=txt('p','note',done?(done.ok?'Déjà trouvé : quatre sur quatre.':'Déjà joué. La bonne réponse est affichée ci-dessus.'):'');
    const btn=txt('button','btn','Goûter les réponses');btn.type='button';btn.hidden=!!done;
    btn.addEventListener('click',()=>{
      if(sels.some(x=>!x.value)){out.textContent='Choisis une recette pour chaque indice.';return;}
      const used=new Set(sels.map(x=>x.value));
      if(used.size<4){out.textContent='Chaque recette ne sert qu\'une fois.';return;}
      const n=CL.filter((c,i)=>+sels[i].value===c[1]).length;const ok=n===4;
      GS.games[20]={pick:n,ok};gSave();emit('j20',ok?'ok':'ko');
      sels.forEach((x,i)=>{x.disabled=true;x.value=String(CL[i][1]);});
      btn.hidden=true;
      out.textContent=ok?'Quatre sur quatre. Palais d\'or.':n+' sur 4. Les bonnes réponses sont affichées.';
      gain(ok?'Bravo ! +3 pts':'Perdu, mais +1 pt pour avoir goûté');
    });
    box.appendChild(btn);box.appendChild(out);return box;
  }
  function init(){testPanel();setupBonus();snowmanSetup();renderGbar();flush();setTimeout(markLock,0);}
  function isWE(d){return WEEKEND_DAYS.includes(d);}
  function testPanel(){
    if(!TEST_MODE)return;
    const p=el('div','testpanel');
    p.appendChild(txt('b','','MODE TEST'));
    p.appendChild(txt('span','',' · tes points restent à part, tes votes partent dans le tableur marqués [test]'));
    const sel=document.createElement('select');sel.setAttribute('aria-label','Date simulée');
    const cur=new URLSearchParams(location.search).get(CONFIG.testParam);
    const opts=[['2026-11-30','Avant décembre']];for(let d=1;d<=25;d++)opts.push(['2026-12-'+String(d).padStart(2,'0'),d+' décembre']);opts.push(['2026-12-26','Après le 25']);
    opts.forEach(([v,l])=>{const o=txt('option','',l);o.value=v;if(v===cur)o.selected=true;sel.appendChild(o);});
    sel.addEventListener('change',()=>{location.search='?'+CONFIG.testParam+'='+sel.value;});
    const rs=txt('button','btn ghost','Remettre le test à zéro');rs.type='button';
    rs.addEventListener('click',()=>{try{Object.keys(localStorage).filter(k=>k.startsWith('test_')).forEach(k=>localStorage.removeItem(k));}catch(e){}location.reload();});
    const dm=txt('button','btn ghost','Démo : tout débloquer');dm.type='button';dm.title='Remplit points, badges et tenues (mode test seulement)';dm.addEventListener('click',demoFill);
    const bb=txt('button','btn ghost','Voir les 5 bonus');bb.type='button';
    bb.addEventListener('click',()=>{alert(BONUS.map(b=>'Case '+b.day+' ('+b.title+') : '+b.text).join('\n\n'));});
    p.appendChild(sel);p.appendChild(dm);p.appendChild(bb);p.appendChild(rs);document.body.appendChild(p);
  }
  return{openSheet,streakNow:()=>streakInfo().cur,syncFromSheet,pushSnapshot,toy,flag,isWE,testPanel,init,emit,flush,onOpen,onVote,gameBlock,teaserBlock,special,rankingEl,tryBonus,lockClick,eggClick,setSulk,nextCostume,setCheat,setLit,isFirst,gameDone,demoFill,renderGbar,markLock,checkBadges};
})();
