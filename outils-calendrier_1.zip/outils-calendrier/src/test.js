// Test de bout en bout. Usage : node test.js [chemin/index.html]
const {chromium}=require('playwright');
const path=require('path');
const FILE=path.resolve(process.argv[2]||'../testsite/index.html');
const U=d=>'file://'+FILE+'?scribe=2026-12-'+String(d).padStart(2,'0');
let fails=0;const ok=(c,m)=>{if(!c){fails++;console.log('  ÉCHEC :',m);}else console.log('  ok :',m);};
(async()=>{
const b=await chromium.launch();const errs=[];
const mk=async(w=430)=>{const c=await b.newContext({viewport:{width:w,height:900}});const p=await c.newPage();p.on('pageerror',x=>errs.push(x.message));p.on('console',m=>{if(m.type()==='error'&&!/file:\/\/.*stats\.csv|URL scheme/.test(m.text()))errs.push(m.text());});return p;};
const quiet=p=>p.evaluate(()=>{['who','welcome'].forEach(i=>document.getElementById(i)?.classList.remove('open','gate'));document.body.classList.remove('locked');document.querySelectorAll('[inert]').forEach(e=>e.removeAttribute('inert'));try{localStorage.setItem('test_ate_welcome','1')}catch(e){}});
const reset=async(p,d)=>{await p.goto(U(d)+'&effacer=1');await p.goto(U(d));await quiet(p);};
const click=(p,sel)=>p.evaluate(s=>document.querySelector(s).click(),sel);
const p=await mk();
console.log('1. Connexion puis bienvenue (première visite)');
await p.goto(U(5)+'&effacer=1');await p.goto(U(5));await p.waitForTimeout(300);
ok(await p.evaluate(()=>{const w=document.getElementById('who');return w.classList.contains('open')&&w.classList.contains('gate')&&document.querySelector('.wrap').inert&&!document.getElementById('welcome').classList.contains('open');}),'la porte d\'entrée s\'affiche seule, fond inerte');
await p.keyboard.press('Escape');await p.mouse.click(5,5);await p.waitForTimeout(150);
ok(await p.evaluate(()=>document.getElementById('who').classList.contains('open')),'Échap et clic dehors ne ferment pas');
ok(await p.locator('#whoBox .btn.ghost').count()===0,'pas de bouton pour passer');
await p.locator('#whoBox .opt').first().click();await p.waitForTimeout(600);
ok(await p.evaluate(()=>!document.querySelector('.wrap').inert&&document.getElementById('welcome').classList.contains('open')),'après le prénom : fond libéré, puis la bienvenue');
await p.locator('#welcomeBox .btn').first().click();await p.waitForTimeout(200);
console.log('2. Les 25 cases');
for(let d=1;d<=25;d++){
  await reset(p,d);await p.evaluate(d=>document.querySelector('.tile[data-day="'+d+'"]').click(),d);await p.waitForTimeout(250);
  const first=await p.locator('.mini.first').count();
  const hidden=first?await p.locator('.rest').evaluate(e=>e.hidden):false;
  const minis=await p.locator('#sheet .mini:not(.first)').count();
  if(first){await p.locator('.mini.first .opt').first().click();await p.waitForTimeout(500);}
  const shown=await p.locator('.rest').evaluate(e=>!e.hidden);
  if(!shown||minis||(first&&!hidden))ok(false,'case '+d+' : quiz '+first+', masqué '+hidden+', révélé '+shown+', mini-jeux parasites '+minis);
}
ok(true,'25 cases ouvertes, quiz avant anecdote cohérents');
console.log('3. Cases spéciales');
await reset(p,5);await click(p,'.tile[data-day="5"]');await p.waitForTimeout(200);
for(let i=0;i<12;i++){if(await p.locator('.special .btn').first().isDisabled().catch(()=>true))break;await p.locator('.special .btn').first().click().catch(()=>{});}
ok(/Toi \d · Bonhomme \d/.test(await p.locator('.special').innerText()),'chifoumi joue');
await reset(p,20);await click(p,'.tile[data-day="20"]');await p.waitForTimeout(200);
const sels=p.locator('.special select');for(let i=0;i<4;i++)await sels.nth(i).selectOption(['1','2','0','3'][i]);
await p.locator('.special .btn').click();
ok(/Quatre sur quatre/.test(await p.locator('.special').innerText()),'dégustation écrite : 4 sur 4');
console.log('4. Sapins');
await reset(p,10);
const log=[];for(let i=0;i<14;i++){await click(p,'.egg.pl');await p.waitForTimeout(40);log.push(await p.evaluate(()=>({n:document.querySelectorAll('.egg.pl .bauble').length,lit:document.querySelector('.egg.pl').classList.contains('lit'),t:document.querySelector('.bubble')?.textContent}))); }
ok(log.some(x=>x.lit),'le sapin finit par s\'allumer');
ok(log[3].t.startsWith('Arrête.')&&log[4].t.startsWith('Je boude.'),'« Arrête. » puis « Je boude. » avant l\'allumage');
const lit=log.findIndex(x=>x.lit);ok(lit>0&&log[lit].t&&!/Arrête|boude/.test(log[lit].t),'phrase d\'allumage non vide');
ok(log.every((x,i)=>i===0||x.t!==log[i-1].t||/boude/.test(x.t)),'pas de phrase répétée à la suite');
console.log('5. Bonhomme de neige');
await reset(p,18);await p.waitForTimeout(2500);
const say=[];for(let i=0;i<9;i++){await click(p,'.egg.snowman');await p.waitForTimeout(i===2?4300:150);say.push(await p.evaluate(()=>{const e=document.querySelector('.bubble');return e&&e.classList.contains('show')?e.textContent:''}));}
ok(/gorge|Aïe|Ouille|neige, pas/.test(say[5]),'6e réplique : le bonhomme râle');
ok(/envie de parler|tête|Chut|silence/.test(say[6]),'7e réplique : il se tait');
ok(say[5]!==say[6],'répliques 6 et 7 différentes');
ok(await p.locator('.cat').count()===1,'le chat d\'Acédia est là le 18');
ok(await p.evaluate(()=>document.querySelector('.cat img').naturalWidth>0),'l\'image du chat charge');
console.log('6. Train, carnet, démo');
await reset(p,4);await p.waitForTimeout(500);
ok(await p.evaluate(()=>document.querySelector('.railbox').classList.contains('on')),'le train roule avec la tenue de chef de gare');
await reset(p,10);
await p.evaluate(()=>[...document.querySelectorAll('.testpanel button')].find(b=>/Démo/.test(b.textContent)).click());await p.waitForTimeout(600);await quiet(p);
await p.evaluate(()=>[...document.querySelectorAll('#gbar button')].pop().click());await p.waitForTimeout(200);
const car=await p.locator('#carnet').innerText();
ok(/D'OÙ VIENNENT MES POINTS/i.test(car)&&/BADGES \(\d+ \/ \d+\)/i.test(car),'carnet : détail des points et badges');
console.log('7. Rattrapage et agenda');
await reset(p,6);
ok(await p.evaluate(()=>!document.getElementById('missed').hidden),'cases à rattraper affichées');
{const u=await p.evaluate(()=>gcalUrl());const q=new URL(u).searchParams;ok(u.startsWith('https://calendar.google.com/')&&q.get('recur')==='RRULE:FREQ=DAILY;COUNT=25'&&q.get('ctz')==='Europe/Paris'&&q.get('dates').startsWith('20261201T090000'),'lien Google Agenda (9 h, 25 jours)');}
console.log('8. Bureau : décor latéral');
const pd=await mk(1280);await pd.goto(U(4)+'&effacer=1');await pd.goto(U(4));await quiet(pd);
ok(await pd.locator('#sideL .lamp').isVisible()&&await pd.locator('#mailBtn').isVisible(),'lampadaire et boîte aux lettres visibles');
await pd.locator('#mailBtn').click();ok((await pd.locator('#mailLetter').innerText()).length>10,'la boîte aux lettres affiche l\'aperçu');
console.log('9. Messages des cases fermées');
await reset(p,3);await click(p,'.tile[data-day="9"]');await p.waitForTimeout(5500);
ok(await p.evaluate(()=>document.getElementById('toast').classList.contains('show')),'le message reste plus de 5 s');
console.log('10. Musique (une piste par jour)');
const pm=await mk();await reset(pm,1);
const bad=await pm.evaluate(async()=>{const out=[];for(let d=1;d<=26;d++){try{Music.setTrack(TRACK_BY_DAY[d]||'base');}catch(e){out.push(d)}}return out;}).catch(e=>['eval']);
ok(!bad.length,'pistes accessibles pour chaque jour');
ok(errs.length===0,'aucune erreur JavaScript '+(errs.length?JSON.stringify(errs.slice(0,3)):''));
await b.close();
console.log(fails?('\n'+fails+' échec(s)'):'\nTout est vert.');process.exit(fails?1:0);
})();
